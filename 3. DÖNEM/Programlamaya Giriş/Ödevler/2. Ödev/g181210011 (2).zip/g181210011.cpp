﻿/****************************************************************************
**
**				ÖĞRENCİ ADI.......: Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI..: G181210011
**				DERS GRUBU........: 2-C	
****************************************************************************/

#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <conio.h>

using namespace std;


int eleman = 0;
int matris[25][25];
int b = 0;
void matris_yap() //istenilen matrise rastgele sayılar yerlestirip olusturan fonksiyon
{
	int i = 0;
	while (i < eleman) {
		for (int j = 0; j < eleman; j++)
		{
			matris[i][j] = 1 + rand() % 9;
		}
		i++;
	}
}

void matris_yaz() // olusan matrisi ekrana yazdıran fonksiyon

{	
	
	for (int i = 0; i < eleman; i++) {
		for (int j = 0; j < eleman; j++) {
			cout << " " << matris[i][j];
			
		}
		cout << endl;
	}
	
}

void satir_sutun_cevir(int satir, int sutun) //satır ve sutunu ceviren fonksiyon
{
	satir--;
	sutun--;
	int gecici[25];
	int gecici2[25];
	int a = 0;
	while (a < eleman) {
		gecici[a] = matris[satir][a];
		gecici2[a] = matris[a][sutun];
		a++;
	}
	
	while (b<eleman)
	{
		matris[satir][b] = gecici2[b];
		matris[b][sutun] = gecici[b];
		b++;
	}
	
	matris[satir][sutun] = gecici[sutun] + gecici2[sutun];
}

void satir_tek(int satir) //tek sayıları bulmak icin kullanılan fonksiyon
{
	satir--;
	int gecici = 0;
	int c = 0;
	while (c < eleman) {
		if (matris[satir][c] % 2 == 1 && satir != 0)
		{
			gecici = matris[satir][c - 1];
			matris[satir][c - 1] = matris[satir][c];
			matris[satir][c] = gecici;
			c= 0;
		}
		c++;
	}
	
}

void sutun_ters_cevir(int sutun) //sutunu ters ceviren fonksiyon
{
	sutun--;
	int gecici[25] = { 0 };
	int j = 0;
	for (int i = 0; i < eleman; i++)
	{
		gecici[i] = matris[i][sutun];
	}
	for (int i = eleman - 1; i >= 0; i--)
	{
		matris[j][sutun] = gecici[i];
		j++;
	}
}

void toplam_yaz() //toplamları yazan fonksiyon
{
	int toplam = 0;
	for (int i = 0; i < eleman; i++)
	{
		for (int j = 0; j < eleman; j++)
		{
			toplam += matris[i][j];
		}
	}
	for (int i = 0; i < eleman; i++)
	{
		for (int j = 0; j < eleman; j++)
		{
			toplam -= matris[i][j];
			matris[i][j] = toplam;
		}
	}
}
int main()
{
	setlocale(LC_ALL, "Turkish");
	srand(time(NULL));
	int secim = 0;
	bool dogruluk = true;
	while (dogruluk)
	{
		cout << "Matris Boyutu:";
		cin >> eleman;
		if (eleman < 5 || eleman > 25) //istenilen deger aralıgı
		{
			cout << "Matris boyutu 25'den Kucuk 5'den Buyuk Olmalidir." << endl;
		}
		else
		{
			break;
		}
	}
	matris_yap();
	while (dogruluk)
	{
		matris_yaz();
		cout << "1.Sutun Satir Degistir:" << endl;
		cout << "2.Tekleri Basa Al(Satir)" << endl;
		cout << "3.Ters Cevir(Sutun)" << endl;
		cout << "4.Toplamlari Yazdir" << endl;
		cin >> secim;

		if (secim == 1) //1. secim için
		{
			int satir;
			int sutun;
			cout << "satir :"; cin >> satir;
			cout << "sutun :"; cin >> sutun;
			if (sutun > eleman || satir > eleman)
			{
				cout << "satir ve sutun matris boyutundan buyuk olamaz." << endl;
				continue;
			}
			satir_sutun_cevir(satir, sutun);
			continue;
		}
		if (secim == 2) //2. secim için
		{
			int satir;
			cout << "satir:"; cin >> satir;
			if (satir > eleman)
			{
				cout << "satir matris boyutundan buyuk olamaz." << endl;
				continue;
			}
			satir_tek(satir);
			continue;
		}
		if (secim == 3) //3. secim için
		{
			int sutun;
			cout << "sutun:"; cin >> sutun;
			if (sutun > eleman
				)
			{
				cout << "sutun matris boyutundan buyuk olamaz." << endl;
				continue;
			}
			sutun_ters_cevir(sutun);
			continue;
		}
		 if (secim == 4) //4. secim için
		{
			 toplam_yaz();
			continue;
		}

	}
	return 0;
}