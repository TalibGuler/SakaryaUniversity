﻿/****************************************************************************
**
**				ÖĞRENCİ ADI.......:Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI..:G181210011	
**				DERS GRUBU………………….:2-C
****************************************************************************/

#include<iostream>
#include<Windows.h>
#include<ctime>
using namespace std;

struct Sahne //sahne yapısı olusturuldu
{
	int yukseklik = 0;
	int genislik = 0;
	char karakter = 0;
};

Sahne sahneOlustur() //sahneyi olusturmak icin yapılan fonksiyon
{
	srand(time(NULL));
	int gen1, kar1;
	Sahne sahne;
	int rastgele_genislik[] = { 30,40,50 }; // genislik degerine 30 40 50 degerlerinden birinin atanaması için
	int rastgele_yukseklik = 20 + rand() % 11; // yukseklik degerine istenilen aralıkta deger atanması için
	char rastgele_karakter[] = { '*','#','$','+','@' }; //verilen karekterlerden birinin atanması için
	gen1 = rand() % 3; 
	kar1 = rand() % 5;
	
	
	sahne.genislik = rastgele_genislik[gen1]; //sahnenin genıslıgıne deger atanır
	sahne.yukseklik = rastgele_yukseklik; //sahnenin yuksekligine deger atanır
	sahne.karakter = rastgele_karakter[kar1];// sahnenin karakterine deger atanır

	return sahne; //olusturdugu sahne yapısını donduruyor
}
void koordinatAta(int x, int y) //Ekranda istediğimiz koordinata karakter çıkarmak için kullanılan fonksiyon
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void sahneCiz(int genislik, int yukseklik, char karakter) //sahneyi cizen fonksiyon
{
	int a=0;
	while (a < genislik-1 )
	{
		cout << karakter;
		a++;
	}
	a= 0;
	while (a< yukseklik)
	{
		koordinatAta(genislik - 1, a);
		cout << karakter;
		a++;
	}
	a= 0;
	while (a< genislik)
	{
		koordinatAta(genislik - a- 1, yukseklik - 1);
		cout << karakter;
		a++;
	}
	a = 0;
	while (a < yukseklik)
	{
		koordinatAta(0, yukseklik - 1 - a);
		cout << karakter;
		a++;
	}
}


struct LSekli //istenilen LSekli yapısı
{
	int x = 0;
	int y = 0;
	int boyut = 0;
	char karakter_L = 0;
};

LSekli  lSekliOlustur() //Sekli olusturan fonksiyon
{
	int kar2;	
	LSekli  sekil;
	sekil.x = 5 + rand() % 21;
	sekil.y = 3;
	sekil.boyut = 2 + rand() % 6;
	int rastgele_karakter[] = { '*','#','$','+','@' };//verilen karekterlerden birinin atanması için
	kar2 = rand() % 5;
	sekil.karakter_L = rastgele_karakter[kar2];
	return sekil;
}
void lSekliCiz(int x, int y, int boyut, char karakter) //sekli cizen fonksiyon
{
	int a = 0;
	while ( a < boyut)
	{
		koordinatAta(x + a, y);
		cout << karakter;
		a++;
	}
	a= 0;
	while (a < (2 * boyut) + 1)
	{
		koordinatAta(x, y + a);
		cout << karakter;
		a++;
	}
	a = 0;
	while (a< (2 * boyut))
	{
		koordinatAta(x + a, y + (2 * boyut));
		cout << karakter;
		a++;
	}
	a= 0;
	while (a< boyut + 1)
	{
		koordinatAta(x + (2 * boyut) - 1, y + (2 * boyut) - a);
		cout << karakter;
		a++;
	}
	a= 0;
	while (a < boyut + 1)
	{
		koordinatAta(x + (2 * boyut) - 1 - a, y + boyut);
		cout << karakter;
		a++;
	}
	a= 0;
	while (a < boyut + 1)
	{
		koordinatAta(x + boyut - 1, y + boyut - a);
		cout << karakter;
		a++;
	}
}

LSekli  lSekliAsagıGotur(LSekli  asagi) //sekli asagıya goturen fonksiyon
{
	asagi.y = asagi.y + 1;
	return asagi;
}

int main()
{
	Sahne sahne;
	sahne = sahneOlustur();
	LSekli  sekil;
	sekil = lSekliOlustur();

	while (true)
	{

		system("cls"); //ekranı temizlemek için
		srand(time(NULL));

		sahneCiz( sahne.genislik, sahne.yukseklik, sahne.karakter); //sahneCiz fonksiyonu cagırılmıstır


		lSekliCiz(sekil.x, sekil.y, sekil.boyut, sekil.karakter_L); //sekili cizen fonksiyon cagırılmıstır

		if (sekil.y + (2 * sekil.boyut) + 1 == sahne.yukseklik - 1)
		{
			sekil = lSekliOlustur();
		}
		else
		{
			sekil = lSekliAsagıGotur(sekil);
		}

		koordinatAta(sahne.genislik, sahne.yukseklik - 1);

		Sleep(200); 
	}
}