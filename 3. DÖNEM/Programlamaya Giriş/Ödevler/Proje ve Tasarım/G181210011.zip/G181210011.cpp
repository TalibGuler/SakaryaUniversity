/****************************************************************************
**
**				��RENC� ADI.......:Abd�lmuttalib G�LER
**				��RENC� NUMARASI..: G181210011
**				DERS GRUBU������� : 2.��RET�M C GRUBU
****************************************************************************/

#include <iostream>
#include <fstream>
#include <ctime>
#include <string>
#include <iomanip>
#include <conio.h>
#include <Windows.h>
#include <stdio.h>

using namespace std;

class Ogrenci
{
private:
	string isim;
	string soyisim;
	int numara;
	

public:
	void IsimEkle(string isim)
	{
		this->isim = isim;
	}
	void SoyadEkle(string Soyad)
	{
		soyisim = Soyad;
	}
	void NumaraEkle(int numara)
	{
		this->numara = numara;
	}

	string Isim()
	{
		return isim;
	}
	string Soyisim()
	{
		return soyisim;
	}
	int Numara()
	{
		return numara;
	}
};

class Sinif
{
public:
	string sinifAdi;
	int ogrenciSayisi;
	Ogrenci ogrenciler[100];

	char IsimOlustur()
	{
		char harf = rand() % 65 + 35;
		return harf;
	}

	void OgrenciEkle(Ogrenci yeniOgrenci)
	{
		if (ogrenciSayisi < 100)
		{
			ogrenciler[ogrenciSayisi] = yeniOgrenci;
			ogrenciSayisi++;
		}
		else
		{
			cout << "Sinif Kapasitesi Doldu!" << endl;
		}
	}

	void OgrenciSil(int n)
	{

		for (int i = 0; i < ogrenciSayisi; i++)
		{
			if (ogrenciler[i].Numara() == n)
			{
				for (int k = i; k < ogrenciSayisi; k++)
					ogrenciler[k] = ogrenciler[k + 1];
				ogrenciSayisi--;
				break;
			}
		}
	}
};

class Okul
{
public:
	int snfSayisi;
	Sinif siniflar[10];
	char solUstKose = 201;
	char duz = 205;
	char sagUstKose = 187;
	char solAltKose = 200;
	char sagAltKose = 188;
	char dikey = 186;
	void ustYazdir(int elemanSayisi)
	{
		cout << solUstKose;
		for (int i = 0; i < elemanSayisi; i++)
			cout << duz;

		cout << sagUstKose;
	}
	void altYazdir(int elemanSayisi)
	{
		cout << solAltKose;
		for (int i = 0; i < elemanSayisi; i++)
			cout << duz;
		cout << sagAltKose;
	}
	void Sinifyazdir(int elemanSayisi)
	{
		int max = 0;
		for (int a = 0; a< snfSayisi; a++)
			if (siniflar[a].ogrenciSayisi > max)
				max = siniflar[a].ogrenciSayisi;
		for (int b = 0; b< max; b++)
		{
			for (int x = 0; x < snfSayisi; x++)
				if (siniflar[x].ogrenciSayisi > b)
					ustYazdir(elemanSayisi);
				else
					cout << setw(elemanSayisi + 2) << " ";

			cout << endl;

			for (int y = 0; y < snfSayisi; y++)
				if (siniflar[y].ogrenciSayisi > b)
					cout << dikey << setw(elemanSayisi) << siniflar[y].ogrenciler[b].Isim() << dikey;
				else
					cout << setw(elemanSayisi + 2) << " ";

			cout << endl;
			for (int y = 0, t = 0; y < snfSayisi; y++)
				if (siniflar[y].ogrenciSayisi > b)
					cout << dikey << setw(elemanSayisi) << siniflar[y].ogrenciler[b].Soyisim() << dikey;
				else
					cout << setw(elemanSayisi + 2) << " ";
			cout << endl;
			for (int y = 0, t = 0; y < snfSayisi; y++)
				if (siniflar[y].ogrenciSayisi > b)
					cout << dikey << setw(elemanSayisi) << siniflar[y].ogrenciler[b].Numara() << dikey;
				else
					cout << setw(elemanSayisi + 2) << " ";

			cout << endl;
			for (int x = 0; x < snfSayisi; x++)
				if (siniflar[x].ogrenciSayisi > b)
					altYazdir(elemanSayisi);
				else
					cout << setw(elemanSayisi + 2) << " ";
			cout << endl;
		}
	}

	void SinifSubeYazdir(int DonguSayi)
	{
		for (int a = 0; a < snfSayisi; a++)
		{
			ustYazdir(DonguSayi);
		}
		cout << "\n";
		for (int a = 0; a< snfSayisi; a++)
			cout << dikey << setw((DonguSayi / 2) + 1) << siniflar[a].sinifAdi << setw((DonguSayi / 2)) << dikey;
		cout << endl;
		for (int a = 0; a< snfSayisi; a++)
		{
			altYazdir(DonguSayi);
		}
	}

	void Sinifekle(Sinif s)
	{
		siniflar[snfSayisi] = s;
		snfSayisi++;
	}

	void SinifSil(int sayi)
	{
		sayi--;
	}
};

class DosyaYonetim
{
public:
	string isim[100];
	string soyisim[100];
	Okul okul;

	Okul okulOku(string dosyaIsmi)
	{

		Ogrenci ogrenci;

		fstream dosya(dosyaIsmi);

		int sinifSayisi = 0;

		while (dosya.eof() != true)
		{
			string sinifIsmi;
			int ogrenciSayisi;
			dosya >> sinifIsmi >> ogrenciSayisi;

			okul.siniflar[sinifSayisi].sinifAdi = sinifIsmi;
			okul.siniflar[sinifSayisi].ogrenciSayisi = ogrenciSayisi;

			for (int i = 0; i < ogrenciSayisi; i++)
			{
				string isim, soyisim;
				int numara;

				dosya >> isim >> soyisim >> numara;
				okul.siniflar[sinifSayisi].ogrenciler[i].IsimEkle(isim);
				okul.siniflar[sinifSayisi].ogrenciler[i].SoyadEkle(soyisim);
				okul.siniflar[sinifSayisi].ogrenciler[i].NumaraEkle(numara);
			}

			sinifSayisi++;
		}
		okul.snfSayisi = sinifSayisi;
		dosya.close();
		return okul;
	}

	Ogrenci ogrenciGetir()
	{
		isimOku();
		SoyisimOku();
		Ogrenci ogrenci;

		srand(time(0));
		int RandomSayi1 = rand() % 100;
		int RandomSayi2 = rand() % 100 + 50;
		ogrenci.IsimEkle(isim[RandomSayi1]);
		ogrenci.SoyadEkle(soyisim[RandomSayi1]);
		ogrenci.NumaraEkle(RandomSayi2);

		return ogrenci;
	}
	void isimOku()
	{
		fstream isimlerD("isimler.txt");
		string temp;
		int i = 0;
		if (isimlerD.is_open())
		{
			while (isimlerD >> temp && i != 100)
			{
				isim[i] = temp;
				i++;
			}
		}

		isimlerD.close();
	}
	void SoyisimOku()
	{
		fstream soyisimD("soyisimler.txt");
		string temp;
		int i = 0;
		if (soyisimD.is_open())
			while (soyisimD >> temp && i != 100)
			{
				soyisim[i] = temp;
				i++;
			}
		soyisimD.close();
	}
};

class Program
{
public:
	DosyaYonetim dosyaYonetim;

	Okul okulNesne;
	Sinif sinif;

	void ProgramCalistir()
	{
		int islem_sayisi = 20;
		bool Durum = true;
		okulNesne = dosyaYonetim.okulOku("kayitlar.txt");
		do
		{
			okulNesne.SinifSubeYazdir(islem_sayisi);
			cout << endl;
			okulNesne.Sinifyazdir(islem_sayisi);
			cout << "1.Ogrenci ekle" << endl
				<< "2.Sinif ekle" << endl
				<< "3.Ogrenci degistir" << endl
				<< "4.Ogrenci sil" << endl
				<< "5.Sinif sil" << endl
				<< "6.Cikis" << endl;
			int secim = 0;
			cout << "Yapmak istediginiz islemi secin:";
			Ogrenci ogrDegisken;
			Sinif sinif;
			string sa;
			int a = 0;
			bool oyun = true;
			cin >> secim;

			if (secim == 1)
			{
				ogrDegisken = dosyaYonetim.ogrenciGetir();
				a= 0;
				cout << "Lutfen Sinif Adini Giriniz" << endl;
				cout << "Sinif adi : ";
				cin >> sa;
				while (a< okulNesne.snfSayisi)
				{
					if (okulNesne.siniflar[a].sinifAdi == sa)
					{
						okulNesne.siniflar[a].OgrenciEkle(ogrDegisken);
						break;
					}
					a++;
				}
			}
			else if (secim == 2)
			{
				sinif.sinifAdi = to_string(okulNesne.snfSayisi + 1) + sinif.IsimOlustur();
				okulNesne.Sinifekle(sinif);
			}

			else if (secim == 3)
			{
				cout << "Su anlik ogrenci degistirememektedir" << endl;
			}
			else if (secim == 4)
			{
				cout << "ogrenci numarasi: ";
				cin >> a;
				for (int i = 0; i < okulNesne.snfSayisi; i++)
					okulNesne.siniflar[i].OgrenciSil(a);
			}
			else if (secim == 5)
			{
				okulNesne.SinifSil(okulNesne.snfSayisi);
			}
			else
			{
				Durum = false;
			}
		} while (Durum);
	}
};

int main()
{
	Program program;
	program.ProgramCalistir();
	return 0;
}