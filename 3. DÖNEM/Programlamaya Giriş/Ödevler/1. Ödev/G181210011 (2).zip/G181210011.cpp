﻿/****************************************************************************
**
**				ÖĞRENCİ ADI:Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI:G181210011
**				DERS GRUBU:2-C
****************************************************************************/
#include <iostream>
#include <iomanip>
#include<Windows.h>

using namespace std;

int main()
{
	int satir; //kullanılacak degiskenler tanimlandi
	int sutun; //kullanılacak degiskenler tanimlandi
	
	while (true) // hata ciktiginda tekrardan istenilen degerlerin alinmasi icin olusturulan sonsuz dongu
	{  
	
		cout << "satir:";
		cin >> satir; //kullanicidan alinan satir degeri

	 if (satir <= 15 & satir >= 5){ //satir icin istenilen deger araligi
		
		while (true) { // hata ciktiginda tekrardan istenilen degerlerin alinmasi icin olusturulan sonsuz dongu
			cout << "sutun:";
			cin >> sutun; //kullanicidan alinan sutun degeri
			if (sutun <= 40 & sutun >= 5) //sutun icin istenilen deger araligi
			{

				if (sutun == 2 * satir) // sutun degerinin satirin iki kati oldugunu gosteriyor
				{ 
					
					for (int i = 0; i < satir; i++) //girilen satir kadar dondurur
					{
						Sleep(100); //ekrana gelen yıldızların yavas yavas cikmasi icin kullanilan fonksiyon
						for (int j = 0; j < sutun; j++)  //girilen sutun kadar dondurur
						{
							if ((j == 0) || (i == 0) || (i == satir - 1) || (j == sutun - 1)) // istenilen koşulları kontrol eder
							{
								cout << "*";
							}


							else if (i + j == satir - 1)// istenilen koşulları kontrol eder
							{
								cout << "*";
							}
							else if (j == i + satir)// istenilen koşulları kontrol eder
							{
								cout << "*";
							}
							else
								cout << " ";

						}cout << endl;
					}

					cout << endl;

					for (int i = 0; i < satir; i++) // girilen satir kadar dondurur
					{
						Sleep(100);
						for (int j = 0; j < sutun; j++)
						{
							if ((j == 0) || (i == 0) || (i == satir - 1) || (j == sutun - 1)) // istenilen koşulları kontrol eder
							{
								cout << "*";
							}
							else if (i == j) // istenilen koşulları kontrol eder
							{
								cout << "*";
							}
							else if (i + j == sutun - 1) // istenilen koşulları kontrol eder
							{
								cout << "*";
							}
							else 
								cout << " ";
						}cout << endl;
					}
					break; // donguden cıkmmayı saglar
				}
				else {
					cout << "Sutun degeri satir degerinin iki kati olmalidir....Tekrar deneyiniz"<<endl; // sartlara gore ekrana cikan mesaj
				}

			}
			else {
				cout << "Deger araligi disi....Tekrar deneyiniz"<<endl; // sartlara gore ekrana cikan mesaj
			}
		}
		break;
	 }
	 
	
		else
		{
		cout << "Deger araligi disi....Tekrar deneyiniz"<<endl; // sartlara gore ekrana cikan mesaj
		}
	}

}