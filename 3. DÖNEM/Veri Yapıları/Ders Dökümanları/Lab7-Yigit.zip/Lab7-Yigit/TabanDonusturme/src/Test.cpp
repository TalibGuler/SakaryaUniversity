#include "Sayi.hpp"

int main(){
	Sayi *s = new Sayi();
	cout<<*s;
	delete s;
	return 0;
}