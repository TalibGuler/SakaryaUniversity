#include "Hata.hpp"

string Hata::Mesaj(){
	return mesaj;
}