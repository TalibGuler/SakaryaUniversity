#include<stdio.h>

void bsort(int *a, int size)
{
  int i, j, tmp;

  for (i = size-1; i > 0; i--) {
    for (j = 0; j < i; j++) {
      if (a[j] > a[j+1]) {
        tmp = a[j];
        a[j] = a[j+1];
        a[j+1] = tmp;
      }
    }
  }
}
      
int main()
{
  int array[4];
  array[0] = 6;
  array[1] = 1;
  array[2] = 4;
  array[3] = 2;

  for(int i = 0; i < 4; i++)
    printf("%d, ", array[i]);
  printf("\n");
  bsort(array, 4);

  for(int i = 0; i < 4; i++)
    printf("%d, ", array[i]);
  printf("\n");
  return 0;
}
