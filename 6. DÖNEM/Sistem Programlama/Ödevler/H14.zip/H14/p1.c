#include<stdio.h>

int a(int i, int j)
{
  int k;

  if (i < j) {
    k = i;
  } else {
    k = j;
  }
  return k;
}

int main()
{
  printf("a = %d\n", a(3, 4)); 
  //return a(3, 4);
}
