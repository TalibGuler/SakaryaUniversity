#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
  int fd;

  fd = open("txt/out1.txt", O_WRONLY);
  if (fd < 0) {
    perror("txt/out1.txt");
    exit(1);
  }
  return 0;
}
