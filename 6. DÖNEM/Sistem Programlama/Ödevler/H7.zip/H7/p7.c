#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main()
{
  int fd, sz;

  fd = open("txt/out3.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd < 0) { perror("txt/out3.txt"); exit(1); }

  sz = write(fd, "Hello\n", strlen("Hello\n"));

  printf("called write(%d, \"Hello\\n\", %ld).  it returned %d\n",
         fd, strlen("cs360\n"), sz);

  close(fd);
  return 0;
}
