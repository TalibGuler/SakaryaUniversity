#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
  int fd;

  fd = open("txt/in1.txt", O_RDONLY);
  printf("%d\n", fd);
  return 0;
}
