// Alarm
#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include <unistd.h>

void foo(int a)
{
  printf("Merhaba\n");
  alarm(1);
}

void foo1(int a)
{
  printf("Tamam nazikçe çıkıyorum\n");
  exit(1);
}

int main()
{
  signal(SIGALRM, foo); // Installer
  signal(SIGINT, foo1); // Installer
  raise(SIGALRM);       // Sentetik signal oluşturucu

  while(1)  ;
  return 0;
}
