#include <stdio.h>
#include <errno.h>

int main()
{
  FILE *f;

  f = fopen("noexist", "r");
  if (f == NULL) {
    printf("f = null.  errno = %d\n", errno);
    perror("noexist");
  }
  return 0;
}
