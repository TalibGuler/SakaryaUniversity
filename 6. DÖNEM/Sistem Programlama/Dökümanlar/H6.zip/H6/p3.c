// Pointer to func
#include<stdio.h>
#include<stdlib.h>

void kaydet(int a)
{
  printf("\n--- Kaydet işlemi : %d\n\n", a);
}

void getir(int a)
{
  printf("\n--- Sorgu, getir işlemi\n\n");
}

void guncelle(int a)
{
  printf("\n--- Güncelle işlemi\n\n");
}

void cikis(int a)
{
  printf("\n--- Çıkış işlemi\n\n");
}


int main()
{
  void (*fpt)(int);
  int s;
  char c;
  do {
    do {
      printf("------MENÜ-------\n");
      printf("[1] Kaydet\n");
      printf("[2] Sorgu\n");
      printf("[3] Güncelle\n");
      printf("[4] Çıkış\n");
      printf("Seçiminiz: ");
      scanf("%d", &s);
    } while((s < 1) || (s > 4));
    
    switch(s)
      {
      case 1:
	fpt = &kaydet;
	break;
      case 2:
	fpt = &getir;
	break;
      case 3:
	fpt = &guncelle;
	break;
      case 4:
	fpt = &cikis;
	printf("\n--- Teşekkürler! ---\n\n");
	exit(1);
	break;
      }
    
    (*fpt)(3);

  } while(1);
  

  return 0;
}
