// Alarm
#include<stdio.h>
#include<signal.h>
#include <unistd.h>

void foo(int a)
{
  printf("Merhaba\n");
  alarm(1);
}

int main()
{
  signal(SIGALRM, foo); // Installer
  raise(SIGALRM);       // Sentetik signal oluşturucu

  while(1)  ;
  return 0;
}
