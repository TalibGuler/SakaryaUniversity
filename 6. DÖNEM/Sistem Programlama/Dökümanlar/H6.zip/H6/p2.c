// Pointer to function
// VERI --> 1) TİP, 2) AD, 3) DEĞERİ, 4) ADRESİ
// FUNCTION ?

#include<stdio.h>

void foo(int a)
{
  printf("Burası foo, değer: %d\n", a);
}

int main()
{
  //foo(3);
  void (*ftr)(int);

  fpr = &foo;

  fpr(5);
  
  return 0;
}
