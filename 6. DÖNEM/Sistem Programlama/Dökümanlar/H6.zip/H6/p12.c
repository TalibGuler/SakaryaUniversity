// Signal
#include<stdio.h>
#include<signal.h>


void foo(int a){
  printf("CTRL-C ye basıldı\n");
}


int main()
{
  signal(SIGINT, foo);
  
  while(1) {
  }
  return 0;
}
