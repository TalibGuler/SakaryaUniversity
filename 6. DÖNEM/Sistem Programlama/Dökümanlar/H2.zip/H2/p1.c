#include <stdio.h>
#include <stdlib.h>

// Global skop
int a;

int main()
{
  int i;
  char j[14];
  int *ip, *ap, *hp;
  char *jp;

  hp = (int *) malloc(sizeof(int));
  
  ip = &i;
  jp = j;
  ap = &a;

  printf("Global değ. ap = 0x%lx.\nDinamik değ. hp = 0x%lx.\nLokal değ. ip = 0x%lx. jp = 0x%lx\n", ap, hp, ip, jp);
  return 0;
}
