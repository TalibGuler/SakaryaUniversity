#include <stdio.h>
#include <stdlib.h>

int main()
{
  char *s;

  s = NULL;

  printf("%d\n", s[0]);   /* Seg fault here */
  return 0;
}
