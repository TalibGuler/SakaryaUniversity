package cc.ders10.srp.uygulama2;

public class FaturaDepolama {

    public void faturaDepola(Fatura fatura){

        System.out.println("PostgreSQL veritabanına bağlandı");
        System.out.println(fatura);
        System.out.println("faturayı sakla");
        System.out.println("bağlantıyı sonlandır");

    }

}
