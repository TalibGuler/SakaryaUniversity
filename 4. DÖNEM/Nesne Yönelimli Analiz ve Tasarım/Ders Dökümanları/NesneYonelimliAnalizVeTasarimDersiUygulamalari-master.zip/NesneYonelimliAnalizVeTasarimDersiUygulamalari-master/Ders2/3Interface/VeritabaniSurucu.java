/*
* Bir sınıfın yapmasını istediklerimizi belirtmek için kullanırız. Ne yapması gerektiği belirtilir, nasıl ile ilgilenilmez.
*
*
* */

package cc.ders2.arayuz;

interface VeritabaniSurucu {

    public void baglan();
    public void sorguCalistir();
    public void baglantiSonlandir();
}

