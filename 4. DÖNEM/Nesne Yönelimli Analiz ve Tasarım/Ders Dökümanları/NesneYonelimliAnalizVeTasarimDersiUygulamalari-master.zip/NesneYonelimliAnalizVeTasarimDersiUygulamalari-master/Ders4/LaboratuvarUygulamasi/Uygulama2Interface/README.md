## İstenenler:

* Kaynak kodları verilen uygulamayı gerçekleyiniz.


* Aşağıdaki sınıf şemasında yer alan diğer yazıcı türlerini de gerçekleyerek uygulama içerisinde kullanınız.

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/02/UygulamaInterface.png)

* Geçtiğimiz derste oluşturulan daire nesnesine ait; konum, yarıçap ve alan bilgilerinin yazdırılması isteniyor. Bu ders kapsamında oluşturulan YaziciSurucu modülünü kullanarak bu işlemin farklı farklı yazıcılar tarafından gerçekleştirilmesini sağlayınız.
