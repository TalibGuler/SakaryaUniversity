package ders2.uygulama1;

public interface YaziciArayuzu {
    public void ac();
    public void yazdir(String mesaj);
    public void kapat();
}
