## İstenenler:

* Kaynak kodları ve sınıf şeması (aşağıda) verilen uygulamayı gerçekleyiniz.

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/02/UygulamaInterface2.png)
