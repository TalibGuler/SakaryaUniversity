package ders2.uygulama2;

interface Interface{
   public void goster1();
   public void goster2();
}