package ders2.uygulama2;

class AltSinif extends AnaSinif
{
    public void goster2() {
        System.out.println("AltSinif interface fonksiyon goster2()'i implement ediyor.");
    }
}