package ders2.uygulama2;

class InterfaceUygulamasi {

    public static void main(String[] args) {
        System.out.println("***Interface Uygulamasi.***\n");
        AltSinif nesne = new AltSinif();
        nesne.goster1();
        nesne.goster2();
    }
}

