package ders2.uygulama2;

abstract class AnaSinif implements Interface
{
    public void goster1() {
        System.out.println("AnaSinif interface fonksiyon goster1()'i implement ediyor.");
    }
    // public abstract void goster2();

}
