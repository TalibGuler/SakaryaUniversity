
# Laboratuvar Uygulaması


```console

nurbanu@nurbanu-N552VW:~/IntellijIDEA/LabUygulamalari/src/ders1$ javac -d . KadroluCalisan.java KalitimUygulamasi.java Kisi.java Yonetici.java 
 

nurbanu@nurbanu-N552VW:~/IntellijIDEA/LabUygulamalari/src/ders1$ java ders1.uygulama2.KalitimUygulamasi 
 

İsim : Ali
Maaş : 2500
Bölüm : IT
Çalışanlara 500 TL Zam Yapıldı.
3000
İsim : Ayse
Maaş : 2000
Bölüm : muhasebe
2000


```


## Uygulama geliştirme ortamının oluşturulması
  * https://www.youtube.com/watch?v=XpJElFJdQb0
