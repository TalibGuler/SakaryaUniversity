package cc.ders12.factory.uygulama1;

public interface ISekil {
    public double alanHesapla();
}
