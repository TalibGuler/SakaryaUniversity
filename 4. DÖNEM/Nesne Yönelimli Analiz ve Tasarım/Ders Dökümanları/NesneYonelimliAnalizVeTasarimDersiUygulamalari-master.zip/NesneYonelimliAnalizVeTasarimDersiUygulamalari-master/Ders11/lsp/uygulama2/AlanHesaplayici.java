package cc.ders10.lsp.uygulama2;


public class AlanHesaplayici {

    public double alanHesapla(ISekil sekil){

        return sekil.alanHesapla();
    }
}
