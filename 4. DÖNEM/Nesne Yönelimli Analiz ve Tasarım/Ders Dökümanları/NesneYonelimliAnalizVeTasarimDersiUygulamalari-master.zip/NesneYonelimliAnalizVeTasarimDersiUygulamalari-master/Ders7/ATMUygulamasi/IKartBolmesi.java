package cc.ders7.atm;

public interface IKartBolmesi {
    public void kartAl();
    public boolean kartDogrula();
    public void kartCikart();
}
