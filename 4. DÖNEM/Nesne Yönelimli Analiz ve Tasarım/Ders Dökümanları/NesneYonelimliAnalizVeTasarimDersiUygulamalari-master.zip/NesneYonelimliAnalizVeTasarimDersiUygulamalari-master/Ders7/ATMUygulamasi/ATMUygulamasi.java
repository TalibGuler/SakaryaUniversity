package cc.ders7.atm;


public class ATMUygulamasi {
    public static void main(String args[]){

        ATM atm=new ATM();
        atm.basla();

    }
}
