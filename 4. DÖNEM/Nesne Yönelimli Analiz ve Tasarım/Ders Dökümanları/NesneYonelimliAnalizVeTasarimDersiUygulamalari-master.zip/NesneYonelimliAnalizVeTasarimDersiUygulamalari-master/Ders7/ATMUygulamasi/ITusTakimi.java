package cc.ders7.atm;

public interface ITusTakimi {
    public int veriAl();
}
