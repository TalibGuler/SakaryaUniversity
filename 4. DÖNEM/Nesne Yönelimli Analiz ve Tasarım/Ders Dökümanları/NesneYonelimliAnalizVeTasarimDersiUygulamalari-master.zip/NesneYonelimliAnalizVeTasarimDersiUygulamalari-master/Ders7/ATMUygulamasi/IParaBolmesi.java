package cc.ders7.atm;

public interface IParaBolmesi {
    public void paraVer();
    public void paraAl();
    public boolean paraVarmi();
}
