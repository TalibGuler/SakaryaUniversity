package cc.ders7.atm;

public class Ekran implements IEkran {
    public void mesajGoruntule(String mesaj) {
        System.out.println(mesaj);
    }
}
