## İstenenler:

* Aşağıda sınıf şeması verilen uygulamayı geliştirmeniz istenmektedir. Bu uygulama içerisinde, 5. ve 6. hafta laboratuvar çalışmalarında geliştirilen modülleri kullanmalısınız. 

* Uygulama içerisinde önce müşteri, sonrasında sipariş nesneleri oluşturulmalıdır. Sipariş nesnesi içerisine sipariş kalemleri (ürünler) eklenmelidir. 


![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/07/LaboratuvarUygulamasi7.png)
