package cc.ders9.nesnelerindepolanmasi.siparis;

import java.util.List;

public interface IUrunVeritabaniServisi {
    public List<Urun> urunListele();

    //Urun urunBul();
}
