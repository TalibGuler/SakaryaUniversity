package cc.ders9.nesnelerindepolanmasi.siparis;

public interface ISiparisVeritabaniServisi {

    public void siparisiKaydet(Siparis siparis);


}
