## İstenenler:

* Siparis, SiparisKalemi, Urun ve Uygulama sınıflarını oluşturunuz.
* Uygulama sınıfında yer alan main() içerisinde 1 adet sipariş nesnesi oluşturunuz ( Sipariş bilgilerini klavyeden alınız. Siparişler içerisinde çok sayıda ürün (sipariş kalemi) bulunabilmelidir).
* Sipariş kalemleri, sipariş sınıfında yer alan sepeteEkle yöntemi yardımıyla sipariş içerisine eklenmelidir.
* Sipariş bilgilerini ekrana yazdırınız.


![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/06/LaboratuvarUygulamasi6.png)


