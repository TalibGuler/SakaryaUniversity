﻿/****************************************************************************
**					      SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					    2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: 2   
**				ÖĞRENCİ ADI............: Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI.......: G181210011
**              DERSİN ALINDIĞI GRUP...: 2.Öğretim C Grubu
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        public int CarpanTopla(int sayi) //Bulunan çarpanları toplayan fonksiyonumuz...
        {
            if (sayi < 1)
            {
                return -1;
            }

            int toplam = 0;
            for (int b = 1; b < sayi; b++)
            {
                if (sayi % b == 0)
                {
                    toplam = toplam + b;
                }
            }
            return toplam;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Width = 700; //Form ekranımızı genişletmek için...
            Height = 500;//Form ekranımızın yüksekliğini arttırmak için...

            Label lbl3 = new Label();//label nesnesinden label oluşturduk
            Point lbl3konum = new Point(400, 40);//oluşan labelin konumunu ayarladık
            lbl3.Location = lbl3konum;//bu konumu labelımıza atadık
            lbl3.Text = "X";//labelımız textinde ne yazacağını belirledik
            lbl3.Name = "lbl3";//labelın adını belırledık
            Controls.Add(lbl3);//labelımızı ekledık

            Label lbl4 = new Label();//label nesnesinden label oluşturduk
            Point lbl4konum = new Point(525, 40);//oluşan labelin konumunu ayarladık
            lbl4.Location = lbl4konum;//bu konumu labelımıza atadık
            lbl4.Text = "Y";//labelımız textinde ne yazacağını belirledik
            lbl4.Name = "lb4";//labelın adını belırledık
            Controls.Add(lbl4);//labelımızı ekledık

            Label lbl5 = new Label();//label nesnesinden label oluşturduk
            Point lbl5konum = new Point(250, 270);//oluşan labelin konumunu ayarladık
            lbl5.Location = lbl5konum;//bu konumu labelımıza atadık
            lbl5.Text = "TOPLAMLAR";//labelımız textinde ne yazacağını belirledik
            lbl5.Name = "lbl5";//labelın adını belırledık
            Controls.Add(lbl5);//labelımızı ekledık

            ListBox listbx1 = new ListBox();//listbox nesnesinden listbox oluşturduk
            Point listbx1konum = new Point(350, 65);//oluşan listboxun konumunu ayarladık
            listbx1.Location = listbx1konum;//bu konumu listboxımıza atadık
            Size listbxsize = new Size(110, 175);//listboxun boyutunu ayarladık
            listbx1.Size = listbxsize;//bu boyutu lıstboxımıza atadık
            listbx1.Name = "listbx1";//lıstboxın adını belırledık
            Controls.Add(listbx1);//listboxımızı ekledık

            ListBox listbx2 = new ListBox();//listbox nesnesinden listbox oluşturduk
            Point listbx2konum = new Point(475, 65);//oluşan listboxun konumunu ayarladık
            listbx2.Location = listbx2konum;//bu konumu listboxımıza atadık
            Size listbx2size = new Size(110, 175);//listboxun boyutunu ayarladık
            listbx2.Size = listbx2size;//bu boyutu lıstboxımıza atadık
            listbx2.Name = "listbx2";//lıstboxın adını belırledık
            Controls.Add(listbx2);//listboxımızı ekledık

            TextBox txtbx1 = new TextBox();//textbox nesnesinden textbox oluşturduk
            Point txtbx1konum = new Point(350, 265);//oluşan textboxun konumunu ayarladık
            txtbx1.Location = txtbx1konum;//bu konumu textboxumuza atadık
            Size txtbxsize = new Size(110, 175);//textboxun boyutunu ayarladık
            txtbx1.Size = txtbxsize;//bu boyutu textboxumuza atadık
            txtbx1.Name = "txtbx1";//textboxun adını belırledık
            Controls.Add(txtbx1);//textboxumuza ekledık

            TextBox txtbx2 = new TextBox();//textbox nesnesinden textbox oluşturduk
            Point txtbx2konum = new Point(475, 265);//oluşan textboxun konumunu ayarladık
            txtbx2.Location = txtbx2konum;//bu konumu textboxumuza atadık
            txtbx2.Size = txtbxsize;//bu boyutu textboxumuza atadık
            txtbx2.Name = "txtbx2";//textboxun adını belırledık
            Controls.Add(txtbx2);//textboxumuza ekledık



            int sayı1 = Convert.ToInt32(textBox1.Text);//oluşturdugumuz sayı1 değişkenıne textbox1e girilen değeri atadık
            int sayı2 = Convert.ToInt32(textBox2.Text);//oluşturdugumuz sayı2 değişkenıne textbox2e girilen değeri atadık


            for (int b = 1; b < sayı1; b++)//bu dongude sayı1 in carpanlarını listbx1e ekledık
            {
                if (sayı1 % b == 0)
                {
                    listbx1.Items.Add(b);
                }

            }

            for (int b = 1; b < sayı2; b++)//bu dongude sayı2 in carpanlarını listbx2ye ekledık
            {
                if (sayı2 % b == 0)
                {
                    listbx2.Items.Add(b);
                }

            }

            txtbx1.Text = Convert.ToString(CarpanTopla(sayı1));//txtbx1e sayı1in carpanlarını toplayıp buldugumuz sonucu yazdırdık
            txtbx2.Text = Convert.ToString(CarpanTopla(sayı2));//txtbx2e sayı2in carpanlarını toplayıp buldugumuz sonucu yazdırdık

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //butona basınca uygulamayı kapatsın dıye yazdık
            this.Close();
            Application.Exit();
        }
    }
}
