﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev2
{
    class Class1
    {
        Label lbl3 = new Label();
        Point lbl3konum = new Point(400, 40);
        lbl3.Location = lbl3konum;
            lbl3.Text = "X";
            lbl3.Name = "lbl3";
    }
}
