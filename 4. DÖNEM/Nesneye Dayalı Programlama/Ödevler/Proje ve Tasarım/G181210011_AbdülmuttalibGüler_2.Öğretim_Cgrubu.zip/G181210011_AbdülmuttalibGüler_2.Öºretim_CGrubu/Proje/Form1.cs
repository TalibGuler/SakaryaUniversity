﻿/****************************************************************************
**				    	SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**			       NESNEYE DAYALI PROGRAMLAMA DERSİ
**					    2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE ÖDEVİ
**				ÖĞRENCİ ADI............: ABDÜLMUTTALİB GÜLER
**				ÖĞRENCİ NUMARASI.......: G181210011
**              DERSİN ALINDIĞI GRUP...: 2. ÖĞRETİM C GRUBU
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proje
{
    public partial class Form1 : Form
    {
        private int _saniye =60; //saniyeyi tutması için saniye değişkeni tanımlandı ve değeri atandı.
        private int _puan = 0; //puanı tutması için puan değişkeni tanımlandı ve ilk başta hiç puanımız olmadığından 0 değeri atandı.
       
        List<Atik> atiklar = new List<Atik>(); //atık classımızdan bir atıklar listesi oluşturuldu.

        Atik CamSise = new Atik(600, Image.FromFile("camSise.jpg")); //Atik classımızdan CamSise nesnesi oluşturuldu ve özellikleri eklendi.
        Atik Bardak = new Atik(250, Image.FromFile("bardak.jpg")); //Atik classımızdan Bardak nesnesi oluşturuldu ve özellikleri eklendi.
        Atik Gazete = new Atik(250, Image.FromFile("gazete.jpg")); //Atik classımızdan Gazete nesnesi oluşturuldu ve özellikleri eklendi.
        Atik Dergi = new Atik(200, Image.FromFile("dergi.jpg")); //Atik classımızdan Dergi nesnesi oluşturuldu ve özellikleri eklendi.
        Atik Domates = new Atik(150, Image.FromFile("domates.jpg")); //Atik classımızdan Domates nesnesi oluşturuldu ve özellikleri eklendi.
        Atik Salatalik = new Atik(120, Image.FromFile("salatalik.jpg")); //Atik classımızdan Salatalik nesnesi oluşturuldu ve özellikleri eklendi.
        Atik KolaKutusu = new Atik(350, Image.FromFile("kolaKutusu.jpg")); //Atik classımızdan KolaKutusu nesnesi oluşturuldu ve özellikleri eklendi.
        Atik SalcaKutusu = new Atik(550, Image.FromFile("salcaKutusu.jpg")); //Atik classımızdan SalcaKutusu nesnesi oluşturuldu ve özellikleri eklendi.

        AtikKutusu OrganikAtikKutusu = new AtikKutusu(700, 0, 0, 0); //AtikKutusu classımızdan OrganikAtikKutusu nesnesi oluşturuldu ve özellikleri eklendi.
        AtikKutusu KagitKutusu = new AtikKutusu(1200, 0, 0, 1000); //AtikKutusu classımızdan KagitKutusu nesnesi oluşturuldu ve özellikleri eklendi.
        AtikKutusu CamKutusu = new AtikKutusu(2200, 0, 0, 600); //AtikKutusu classımızdan CamKutusu nesnesi oluşturuldu ve özellikleri eklendi.
        AtikKutusu MetalKutusu = new AtikKutusu(2300, 0, 0, 800); //AtikKutusu classımızdan MetalKutusu nesnesi oluşturuldu ve özellikleri eklendi.


        private void Resim() //Resimleri rastgele ekleyen method.
        {
            Random Rastgele = new Random(); //Rastgele nesnesi oluşturuldu.
            pictureBox1.Image = atiklar[Rastgele.Next(0, atiklar.Count)].Image; //pictureBox1 e atiklar listemizden rastgele aldğı resimleri ekler.         

        }
        private int BosaltmaPuani(AtikKutusu atikKutusu) //Hangi kutunun bosaltma sonrası ne kadar puan ekleyeceğini döndüren method.
        {
            return atikKutusu.BosaltmaPuani;
        }
       
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          
            atiklar.Add(CamSise); //atiklar listesine CamSise ekledik.
            atiklar.Add(Bardak); //atiklar listesine Bardak ekledik.
            atiklar.Add(Gazete); //atiklar listesine Gazete ekledik.
            atiklar.Add(Dergi); //atiklar listesine Dergi ekledik.
            atiklar.Add(Domates); //atiklar listesine Domates ekledik.
            atiklar.Add(Salatalik); //atiklar listesine Salatalik ekledik.
            atiklar.Add(KolaKutusu); //atiklar listesine KolaKutusu ekledik.
            atiklar.Add(SalcaKutusu); //atiklar listesine SalcaKutusu ekledik.

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 1000; //timerı 1 saniye yavaşlığına göre ayarladık.
            _saniye--; //geri sayım olması için _saniye değeri her seferinde 1 azaltıldı.
            textBox9.Text = _saniye.ToString(); //_saniye değerimizi textBox9 a yazdırdık.
            
            if (_saniye == 0) //eğer _saniye 0 a gelirse
            {
                timer1.Stop(); // timerı durdurduk.
                
                //ekleme ve bosaltma yapılmaması için butonlarımızı pasif hale getirdik.
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                button10.Enabled = false;

                button1.ForeColor = Color.White; //butonda bulunan yeni oyun yazısının rengini değiştirdik.

                //sure ve puanlarımızın bulundugu textboxların rengini değiştirdik.
                textBox7.BackColor = Color.White; 
                textBox9.BackColor = Color.White;
            }
        }
        private void button1_Click(object sender, EventArgs e) //yeni oyun butonumuz
        {
            _saniye = 60; //oynanan oyunun ardından yeni bir oyuna başlanırsa _saniyenin tekrardan 60 tan başlaması için eklendi.
            _puan = 0; //oynanan oyunun ardından yeni bir oyuna başlanırsa _puanın tekrardan sıfırlanması için eklendi.

            textBox9.Text = _saniye.ToString(); //textBox9 a _saniye değerimiz yadırıldı.
            textBox7.Text = _puan.ToString(); //textBox7 e _puan değerimiz yadırıldı.

            timer1.Start(); //geri sayım için timer başlatıldı.

            //ekleme ve bosaltma yapılması için butonlarımızı aktif hale getirdik.
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;

            //yeni oyuna başlandığında lisboxlarımız temizlendi.
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();

            //yeni oyuna başlandığında progressbarlarımız sıfırlandı.
            progressBar1.Value = 0;
            progressBar2.Value = 0;
            progressBar3.Value = 0;
            progressBar4.Value = 0;

            button1.ForeColor = Color.Black; //butonda bulunan yeni oyun yazısının rengini değiştirdik.

            //sure ve puanlarımızın bulundugu textboxların rengini değiştirdik.
            textBox7.BackColor = Color.Cyan;
            textBox9.BackColor = Color.Cyan;
            Resim(); //yeni oyuna başlandığında resim eklendi.

        }
        private void button2_Click(object sender, EventArgs e) //çıkış butonumuz
        {
            this.Close(); //pencere kapatıldı.
            Application.Exit(); //uygulama kapatıldı.
        }
        private void button3_Click(object sender, EventArgs e)//Organik Atık butonumuz
        {
            OrganikAtikKutusu.DoluHacim =progressBar1.Value; //OrganikAtikKutusunun DoluHacimine progressBar1 in valuesi atandı. Çünkü valuemiz eklenen hacim kadar artış sağlıyor.
            if (pictureBox1.Image == Domates.Image) //eger pictureBox1 imize gelen resim Domatesin resmi ise
            {
                if (OrganikAtikKutusu.Ekle(Domates) == true) //eger OrganikAtikKutusu için Ekle methodumuz true ise yani kutumuzda Domatesin hacmi kadar yer varsa
                {
                    listBox1.Items.Add("Domates (" + Domates.Hacim + ")"); //listbox1 e Domates yazısı ve Hacmi yazdırıldı.
                    progressBar1.Value += Domates.Hacim; //progressBar1 in artısı Domatesin hacmi kadar arttırıldı.
                   _puan += Domates.Hacim; //puanımız Domatesin hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
                    
            }

            else if (pictureBox1.Image == Salatalik.Image) //eger pictureBox1 imize gelen resim Salatalik resmi ise
            {
                if (OrganikAtikKutusu.Ekle(Salatalik)==true) //eger OrganikAtikKutusu için Ekle methodumuz true ise yani kutumuzda Salatalik hacmi kadar yer varsa
                {
                    listBox1.Items.Add("Salatalık (" + Salatalik.Hacim + ")"); //listbox1 e Salatalık yazısı ve Hacmi yazdırıldı.
                    progressBar1.Value += Salatalik.Hacim; //progressBar1 in artısı Salatalik hacmi kadar arttırıldı.
                    _puan += Salatalik.Hacim; //puanımız Salatalik hacmi kadar arttırıldı
                    Resim(); //yeni resim eklendi.
                }
                
            }
            textBox7.Text = _puan.ToString(); //textbox7 ye _puan yazdırıldı.
        }
        private void button7_Click(object sender, EventArgs e)//Organik Atık için kullanılan Boşalt butonu
        {
            OrganikAtikKutusu.DolulukOrani = progressBar1.Value; //OrganikAtikKutusunun DolulukOranına progressBar1 in valuesi atandı. 
            if (OrganikAtikKutusu.Bosalt()==true) //eger OrganikAtikKutusu için bosalt methodumuz true ise yani kutumuzun %75 i dolu ise
            {
                listBox1.Items.Clear(); //listbox1 in içindekiler temizlendi.
                progressBar1.Value = 0; //progressbarımız sıfırlandı.
                _saniye = _saniye + 3; // süremize 3 saniye daha eklendi.
                _puan += BosaltmaPuani(OrganikAtikKutusu); //organik atık kutumuzu bosalttıgımızda kazanacagımız puan puanımıza eklendi.
                textBox7.Text = _puan.ToString(); //textbox7 ye puanımız yazdırıldı.
               
            }
                
        }
        private void button4_Click(object sender, EventArgs e)//Kağıt butonumuz
        {
            KagitKutusu.DoluHacim = progressBar2.Value; //KagitKutusunun DoluHacimine progressBar2 nin valuesi atandı. Çünkü valuemiz eklenen hacim kadar artış sağlıyor.
            if (pictureBox1.Image == Dergi.Image) //eger pictureBox1 imize gelen resim Dergi resmi ise
            {
                if (KagitKutusu.Ekle(Dergi)==true) //eger KagitKutusu için Ekle methodumuz true ise yani kutumuzda Derginin hacmi kadar yer varsa
                {
                    listBox2.Items.Add("Dergi (" + Dergi.Hacim + ")");//listbox2 ye Dergi yazısı ve Hacmi yazdırıldı.
                    progressBar2.Value += Dergi.Hacim; //progressBar2 nin artışı Derginin hacmi kadar arttırıldı.
                    _puan += Dergi.Hacim; //puanımız Derginin hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
              
            }

            else if (pictureBox1.Image == Gazete.Image) //eger pictureBox1 imize gelen resim Gazete resmi ise
            {
                if (KagitKutusu.Ekle(Gazete) == true) //eger KagitKutusu için Ekle methodumuz true ise yani kutumuzda Gazete hacmi kadar yer varsa
                {
                    listBox2.Items.Add("Gazete (" + Gazete.Hacim + ")"); //listbox2 ye Gazete yazısı ve Hacmi yazdırıldı.
                    progressBar2.Value += Gazete.Hacim; //progressBar2 nin artışı Gazetenin hacmi kadar arttırıldı.
                    _puan += Gazete.Hacim; //puanımız Gazetenin hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
             
            }
            textBox7.Text =_puan.ToString(); //textbox7 ye _puan yazdırıldı.
        }
        private void button8_Click(object sender, EventArgs e)//Kağıt için kullanılan Boşalt butonu
        {
            KagitKutusu.DolulukOrani = progressBar2.Value; //KagitKutusunun DolulukOranına progressBar2 in valuesi atandı. 

            if (KagitKutusu.Bosalt() == true) //eger KagitKutusu için bosalt methodumuz true ise yani kutumuzun %75 i dolu ise bosaltabilecek
            {
                listBox2.Items.Clear(); //listbox2 in içindekiler temizlendi.
                progressBar2.Value = 0; //progressbarımız sıfırlandı.
                _saniye = _saniye + 3; // süremize 3 saniye daha eklendi.
                _puan += BosaltmaPuani(KagitKutusu); //kagıt kutumuzu bosalttıgımızda kazanacagımız puan puanımıza eklendi.
                textBox7.Text = _puan.ToString(); //textbox7 ye puanımız yazdırıldı.
            }

        }
        private void button5_Click(object sender, EventArgs e)//Cam Kutusu butonumuz
        {
            CamKutusu.DoluHacim = progressBar3.Value; //CamKutusunun DoluHacimine progressBar3 ün valuesi atandı. Çünkü valuemiz eklenen hacim kadar artış sağlıyor.
            
            if (pictureBox1.Image == Bardak.Image) //eger pictureBox1 imize gelen resim Bardak resmi ise
            {
                if (CamKutusu.Ekle(Bardak) == true) //eger CamKutusu için Ekle methodumuz true ise yani kutumuzda Bardak hacmi kadar yer varsa
                {
                    listBox3.Items.Add("Bardak (" + Bardak.Hacim + ")"); //listbox3 ye Bardak yazısı ve Hacmi yazdırıldı.
                    progressBar3.Value += Bardak.Hacim; //progressBar3 nin artışı Gazetenin hacmi kadar arttırıldı.
                    _puan += Bardak.Hacim; //puanımız Bardagın hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
            }

            else if (pictureBox1.Image == CamSise.Image) //eger pictureBox1 imize gelen resim Cam resmi ise
            {
                if (CamKutusu.Ekle(CamSise)==true) //eger CamKutusu için Ekle methodumuz true ise yani kutumuzda CamSise hacmi kadar yer varsa
                {
                    listBox3.Items.Add("CamSise (" + CamSise.Hacim + ")"); //listbox3 ye CamSise yazısı ve Hacmi yazdırıldı.
                    progressBar3.Value += CamSise.Hacim; //progressBar3 nin artışı CamSisenin hacmi kadar arttırıldı.
                    _puan += CamSise.Hacim; //puanımız CamSisenin hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
            }
            textBox7.Text = _puan.ToString(); //textbox7 ye _puan yazdırıldı.
        }
        private void button9_Click(object sender, EventArgs e)//Cam Kutusu için kullanılan Boşalt butonu
        {
            CamKutusu.DolulukOrani = progressBar3.Value; //CamKutusunun DolulukOranına progressBar3 ün valuesi atandı.

            if (CamKutusu.Bosalt()==true) //eger CamKutusu için bosalt methodumuz true ise yani kutumuzun %75 i dolu ise bosaltabilecek.
            {
                listBox3.Items.Clear(); //listbox3 in içindekiler temizlendi.
                progressBar3.Value = 0; //progressbarımız sıfırlandı.
                _saniye = _saniye + 3; // süremize 3 saniye daha eklendi.
                _puan += BosaltmaPuani(CamKutusu); //cam kutumuzu bosalttıgımızda kazanacagımız puan puanımıza eklendi.
                textBox7.Text = _puan.ToString(); //textbox7 ye puanımız yazdırıldı.
            }
            
        }
        private void button6_Click(object sender, EventArgs e)//Metal Kutusu butonumuz
        {
            MetalKutusu.DoluHacim = progressBar4.Value; //MetalKutusunun DoluHacimine progressBar4 ün valuesi atandı. Çünkü valuemiz eklenen hacim kadar artış sağlıyor.

            if (pictureBox1.Image == KolaKutusu.Image) //eger pictureBox1 imize gelen resim KolaKutusu resmi ise
            {
                if (MetalKutusu.Ekle(KolaKutusu)==true) //eger MetalKutusunun için Ekle methodumuz true ise yani kutumuzda KolaKutusu hacmi kadar yer varsa
                {
                    listBox4.Items.Add("KolaKutusu (" + KolaKutusu.Hacim + ")"); //listbox4 ye KolaKutusu yazısı ve Hacmi yazdırıldı.
                    progressBar4.Value += KolaKutusu.Hacim; //progressBar4 nin artışı KolaKutusunun hacmi kadar arttırıldı.
                    _puan += KolaKutusu.Hacim; //puanımız KolaKutusunun hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
            }

            else if (pictureBox1.Image == SalcaKutusu.Image) //eger pictureBox1 imize gelen resim SalcaKutusu resmi ise
            { 
                if (MetalKutusu.Ekle(SalcaKutusu)==true) //eger MetalKutusunun için Ekle methodumuz true ise yani kutumuzda SalcaKutusu hacmi kadar yer varsa
                {
                    listBox4.Items.Add("SalcaKutusu (" + SalcaKutusu.Hacim + ")"); //listbox4 ye SalcaKutusu yazısı ve Hacmi yazdırıldı.
                    progressBar4.Value += SalcaKutusu.Hacim; //progressBar4 nin artışı SalcaKutusunun hacmi kadar arttırıldı.
                    _puan += SalcaKutusu.Hacim;  //puanımız SalcaKutusunun hacmi kadar arttırıldı.
                    Resim(); //yeni resim eklendi.
                }
                
            }
            textBox7.Text = _puan.ToString(); //textbox7 ye _puan yazdırıldı.
        }
        private void button10_Click(object sender, EventArgs e)//Metal Kutusu için kullanılan Boşalt butonu
        {
            MetalKutusu.DolulukOrani = progressBar4.Value; //MetalKutusunun DolulukOranına progressBar4 ün valuesi atandı.

            if (MetalKutusu.Bosalt()==true) //eger MetalKutusunun için bosalt methodumuz true ise yani kutumuzun %75 i dolu ise bosaltabilecek.
            {
                listBox4.Items.Clear(); //listbox3 in içindekiler temizlendi.
                progressBar4.Value = 0; //progressbarımız sıfırlandı.
                _saniye = _saniye + 3; // süremize 3 saniye daha eklendi.
                _puan += BosaltmaPuani(MetalKutusu); //metal kutumuzu bosalttıgımızda kazanacagımız puan puanımıza eklendi.
                textBox7.Text = _puan.ToString(); //textbox7 ye puanımız yazdırıldı.
            }
           
        }      
    }
}
