﻿/****************************************************************************
**				    	SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**			       NESNEYE DAYALI PROGRAMLAMA DERSİ
**					    2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE ÖDEVİ
**				ÖĞRENCİ ADI............: ABDÜLMUTTALİB GÜLER
**				ÖĞRENCİ NUMARASI.......: G181210011
**              DERSİN ALINDIĞI GRUP...: 2. ÖĞRETİM C GRUBU
****************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje
{
    class AtikKutusu : IAtikKutusu
    {
        private int _bosaltmaPuani;
        private int _kapasite;
        private int _doluHacim;
        private int _dolulukOrani;
        private int _kalanHacim;
        public AtikKutusu(int _kapasite,int _doluHacim,int _dolulukOrani, int _bosaltmaPuani)
        {
            this.Kapasite = _kapasite;
            this.DoluHacim = _doluHacim;
            this.DolulukOrani = _dolulukOrani;
            this.BosaltmaPuani = _bosaltmaPuani;
        }
        public int Kapasite //Kapasite için özellik oluşturuldu
        {
            get
            {
                return _kapasite;
            }
            set
            {
                _kapasite = value;
            }

        }
        public int DoluHacim //DoluHacim için özellik oluşturuldu
        {
            get
            {
                return _doluHacim;
            }
            set
            {
                _doluHacim = value;
            }
        }
        public int DolulukOrani //DolulukOranı için özellik oluşturuldu
        {
            get
            {
                return _dolulukOrani;
            }
            set
            {
                _dolulukOrani = value;
            }

        }

     
        public int BosaltmaPuani //BosaltmaPuani için özellik oluşturuldu
        {
            get
            {
                return _bosaltmaPuani;
            }
            set
            {
                _bosaltmaPuani = value;
            }
        }

        public bool Ekle(Atik atik) // Eger atıgı alabılecek bır alana sahıpse ekleme yapabılmek için true dondurur. Eger degılse eklemenın olmaması ıcın false dondurur
        {
             _kalanHacim = Kapasite-DoluHacim;
            if (atik.Hacim<_kalanHacim)
            {
                return true;
            }
            else
            {
                return false;
            }
          
        }

        
        public bool Bosalt() //  Eger %75 inden fazlası dolu ıse bosaltabılmesı ıcın true dondurur. Eger %75 ten fazla degılse bosaltamaması ıcın false dondururlur
        {
            
            int _yuzde = (Kapasite * 75) / 100;
            if (DolulukOrani >= _yuzde )
            {   
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
