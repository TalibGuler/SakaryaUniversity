﻿/****************************************************************************
**				    	SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**			       NESNEYE DAYALI PROGRAMLAMA DERSİ
**					    2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE ÖDEVİ
**				ÖĞRENCİ ADI............: ABDÜLMUTTALİB GÜLER
**				ÖĞRENCİ NUMARASI.......: G181210011
**              DERSİN ALINDIĞI GRUP...: 2. ÖĞRETİM C GRUBU
****************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje
{
    public class Atik : IAtik //IAtikrtan kalıtım aldırıldı
    {
     
        private int _hacim;
        private System.Drawing.Image _image;
      
        public Atik(int _hacim, Image _image) 
        {
            this.Hacim = _hacim;
            this.Image = _image;
        }

            
        public int Hacim //Hacim için özellik oluşturuldu
        {
            get
            {
                return _hacim;
            }
            set
            {
                _hacim = value;
            }
        }

        public System.Drawing.Image Image  //Image için özellik oluşturuldu
        {
            get
            {
                return _image;
            }
            set
            {
                _image = value;
            }
        }
    }
}
