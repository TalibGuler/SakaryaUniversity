﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: G181210011     
**				ÖĞRENCİ ADI............: Abdülmuttalib
**				ÖĞRENCİ NUMARASI.......: GÜLER
**              DERSİN ALINDIĞI GRUP...: 2. Öğretim C Grubu
****************************************************************************/

using System;
using System.IO;

namespace g181210011
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = System.IO.File.ReadAllText("../../../File.txt"); //text dosyasını .csnin proje dosyasına atmalısınız.



            string[] liste = text.Split('\n'); 
            double odev1 = 0;
            double odev2 = 0;
            double final = 0;
            double vize = 0;
            double ort = 0;
            string[] hfNotlari = new string[10000];
            string[] hn = { "AA", "BA", "BB", "CB", "CC", "DC", "DD", "FD", "FF" };
            int ogrenciSayisi = 0;

            foreach (string parca in liste)
            {
                string[] ogr = parca.Split(',');
                odev1 = double.Parse(ogr[3]);
                odev2 = double.Parse(ogr[4]);
                vize = double.Parse(ogr[5]);
                final = double.Parse(ogr[6]);
                ort = (odev1 * 0.1) + (odev2 * 0.1) + (vize * 0.3) + (final * 0.5);
                hfNotlari[ogrenciSayisi] = HarfNot(ort);
                ogrenciSayisi++;

            }

            
            string strr = "";
            int cc = 0;
            
            foreach (var item in hn)
            {
              
                strr += item + " " + HarfNotCount(hfNotlari, item) + " %" + Convert.ToDouble(HarfNotCount(hfNotlari, item) * 100 / ogrenciSayisi) + " \n";
                cc++;
            }
            Console.WriteLine(strr);
            File.WriteAllText("../../../sonuc.txt", strr);
            
        }
        public static string HarfNot(double d)
        {
            if (d > 90)
                return "AA";
            else if (d > 85)
                return "BA";
            else if (d > 80)
                return "BB";
            else if (d > 75)
                return "CB";
            else if (d > 65)
                return "CC";
            else if (d > 58)
                return "DC";
            else if (d > 50)
                return "DD";
            else if (d > 40)
                return "FD";
            else
                return "FF";
        }
        public static int HarfNotCount(string[] hn, string h)
        {
            int ct = 0;
            foreach (var item in hn)
            {
                if (item == h)
                    ct++;
            }
            return ct;
        }
    }
}