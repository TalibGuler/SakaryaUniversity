﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje1
{
    //Kalıtım alınmıştır.
    class INEK : HAYVAN, ICiftlik
    {
        public int inek_sutu = 0;

        //ses çal fonksiyonu ile medya oluşturulmuştur.
        public void SesCal()
        {
            System.Media.SoundPlayer hayvan_sesleri = new System.Media.SoundPlayer();
            hayvan_sesleri.SoundLocation = "inek.wav";
            hayvan_sesleri.Play();
        }
    }
}
