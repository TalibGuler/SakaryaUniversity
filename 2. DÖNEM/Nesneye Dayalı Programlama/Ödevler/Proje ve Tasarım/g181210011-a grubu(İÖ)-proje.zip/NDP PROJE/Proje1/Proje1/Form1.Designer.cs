﻿namespace Proje1
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.Tavukcan = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Tyumurtasayı = new System.Windows.Forms.Label();
            this.Isutsayı = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Oyumurtasayı = new System.Windows.Forms.Label();
            this.Ksutsayı = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.Kasa = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Gecensure = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Ksutbutton = new System.Windows.Forms.Button();
            this.Isutbutton = new System.Windows.Forms.Button();
            this.Oyumurtabutton = new System.Windows.Forms.Button();
            this.Tyumurtabutton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Kyembutton = new System.Windows.Forms.Button();
            this.Kecican = new System.Windows.Forms.ProgressBar();
            this.label20 = new System.Windows.Forms.Label();
            this.Iyembutton = new System.Windows.Forms.Button();
            this.Inekcan = new System.Windows.Forms.ProgressBar();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Öyembutton = new System.Windows.Forms.Button();
            this.Ördekcan = new System.Windows.Forms.ProgressBar();
            this.label17 = new System.Windows.Forms.Label();
            this.Tyembutton = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "ÜRÜN DEPOSU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tavukcan
            // 
            this.Tavukcan.Location = new System.Drawing.Point(92, 63);
            this.Tavukcan.Name = "Tavukcan";
            this.Tavukcan.Size = new System.Drawing.Size(202, 26);
            this.Tavukcan.TabIndex = 1;
            this.Tavukcan.Value = 100;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(3, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "TAVUK YUMURTASI";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(144, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "İNEK SÜTÜ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tyumurtasayı
            // 
            this.Tyumurtasayı.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Tyumurtasayı.Location = new System.Drawing.Point(3, 80);
            this.Tyumurtasayı.Name = "Tyumurtasayı";
            this.Tyumurtasayı.Size = new System.Drawing.Size(135, 23);
            this.Tyumurtasayı.TabIndex = 4;
            this.Tyumurtasayı.Text = "0 ADET";
            this.Tyumurtasayı.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Isutsayı
            // 
            this.Isutsayı.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Isutsayı.Location = new System.Drawing.Point(144, 80);
            this.Isutsayı.Name = "Isutsayı";
            this.Isutsayı.Size = new System.Drawing.Size(119, 23);
            this.Isutsayı.TabIndex = 5;
            this.Isutsayı.Text = "0 KG";
            this.Isutsayı.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(3, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 23);
            this.label6.TabIndex = 6;
            this.label6.Text = "ÖRDEK YUMURTASI";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(144, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 23);
            this.label7.TabIndex = 7;
            this.label7.Text = "KEÇİ SÜTÜ";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Oyumurtasayı
            // 
            this.Oyumurtasayı.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Oyumurtasayı.Location = new System.Drawing.Point(3, 148);
            this.Oyumurtasayı.Name = "Oyumurtasayı";
            this.Oyumurtasayı.Size = new System.Drawing.Size(135, 23);
            this.Oyumurtasayı.TabIndex = 8;
            this.Oyumurtasayı.Text = "0 ADET";
            this.Oyumurtasayı.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Ksutsayı
            // 
            this.Ksutsayı.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Ksutsayı.Location = new System.Drawing.Point(144, 148);
            this.Ksutsayı.Name = "Ksutsayı";
            this.Ksutsayı.Size = new System.Drawing.Size(119, 23);
            this.Ksutsayı.TabIndex = 9;
            this.Ksutsayı.Text = "0 KG";
            this.Ksutsayı.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Ksutsayı);
            this.panel1.Controls.Add(this.Tyumurtasayı);
            this.panel1.Controls.Add(this.Oyumurtasayı);
            this.panel1.Controls.Add(this.Isutsayı);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(14, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(266, 192);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(627, 220);
            this.panel2.TabIndex = 11;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel9.Controls.Add(this.Kasa);
            this.panel9.Controls.Add(this.label13);
            this.panel9.Location = new System.Drawing.Point(503, 121);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(121, 86);
            this.panel9.TabIndex = 2;
            // 
            // Kasa
            // 
            this.Kasa.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Kasa.Location = new System.Drawing.Point(14, 42);
            this.Kasa.Name = "Kasa";
            this.Kasa.Size = new System.Drawing.Size(92, 31);
            this.Kasa.TabIndex = 7;
            this.Kasa.Text = "0 TL";
            this.Kasa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(14, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 23);
            this.label13.TabIndex = 3;
            this.label13.Text = "KASA";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel8.Controls.Add(this.Gecensure);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Location = new System.Drawing.Point(503, 15);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(121, 100);
            this.panel8.TabIndex = 1;
            // 
            // Gecensure
            // 
            this.Gecensure.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gecensure.Location = new System.Drawing.Point(14, 39);
            this.Gecensure.Name = "Gecensure";
            this.Gecensure.Size = new System.Drawing.Size(92, 50);
            this.Gecensure.TabIndex = 6;
            this.Gecensure.Text = "0 SN";
            this.Gecensure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(14, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 23);
            this.label11.TabIndex = 2;
            this.label11.Text = "GEÇEN SÜRE";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel7.Controls.Add(this.Ksutbutton);
            this.panel7.Controls.Add(this.Isutbutton);
            this.panel7.Controls.Add(this.Oyumurtabutton);
            this.panel7.Controls.Add(this.Tyumurtabutton);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(311, 15);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(175, 192);
            this.panel7.TabIndex = 0;
            // 
            // Ksutbutton
            // 
            this.Ksutbutton.Location = new System.Drawing.Point(3, 131);
            this.Ksutbutton.Name = "Ksutbutton";
            this.Ksutbutton.Size = new System.Drawing.Size(169, 23);
            this.Ksutbutton.TabIndex = 5;
            this.Ksutbutton.Text = "KEÇİ SÜTÜ SAT";
            this.Ksutbutton.UseVisualStyleBackColor = true;
            this.Ksutbutton.Click += new System.EventHandler(this.Ksütbutton_Click);
            // 
            // Isutbutton
            // 
            this.Isutbutton.Location = new System.Drawing.Point(3, 102);
            this.Isutbutton.Name = "Isutbutton";
            this.Isutbutton.Size = new System.Drawing.Size(169, 23);
            this.Isutbutton.TabIndex = 4;
            this.Isutbutton.Text = "İNEK SÜTÜ SAT";
            this.Isutbutton.UseVisualStyleBackColor = true;
            this.Isutbutton.Click += new System.EventHandler(this.İsütbutton_Click);
            // 
            // Oyumurtabutton
            // 
            this.Oyumurtabutton.Location = new System.Drawing.Point(3, 73);
            this.Oyumurtabutton.Name = "Oyumurtabutton";
            this.Oyumurtabutton.Size = new System.Drawing.Size(169, 23);
            this.Oyumurtabutton.TabIndex = 3;
            this.Oyumurtabutton.Text = "ÖRDEK YUMURTASI SAT";
            this.Oyumurtabutton.UseVisualStyleBackColor = true;
            this.Oyumurtabutton.Click += new System.EventHandler(this.Öyumurtabutton_Click);
            // 
            // Tyumurtabutton
            // 
            this.Tyumurtabutton.Location = new System.Drawing.Point(3, 44);
            this.Tyumurtabutton.Name = "Tyumurtabutton";
            this.Tyumurtabutton.Size = new System.Drawing.Size(169, 23);
            this.Tyumurtabutton.TabIndex = 2;
            this.Tyumurtabutton.Text = "TAVUK YUMURTASI SAT";
            this.Tyumurtabutton.UseVisualStyleBackColor = true;
            this.Tyumurtabutton.Click += new System.EventHandler(this.Tyumurtabutton_Click);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(3, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 23);
            this.label10.TabIndex = 1;
            this.label10.Text = "GIDA FABRİKASI";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(12, 238);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(627, 213);
            this.panel4.TabIndex = 12;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Kyembutton);
            this.panel6.Controls.Add(this.Kecican);
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.Iyembutton);
            this.panel6.Controls.Add(this.Inekcan);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Location = new System.Drawing.Point(317, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(307, 210);
            this.panel6.TabIndex = 1;
            // 
            // Kyembutton
            // 
            this.Kyembutton.Location = new System.Drawing.Point(95, 181);
            this.Kyembutton.Name = "Kyembutton";
            this.Kyembutton.Size = new System.Drawing.Size(209, 26);
            this.Kyembutton.TabIndex = 10;
            this.Kyembutton.Text = "YEM VER";
            this.Kyembutton.UseVisualStyleBackColor = true;
            this.Kyembutton.Click += new System.EventHandler(this.Kyembutton_Click);
            // 
            // Kecican
            // 
            this.Kecican.Location = new System.Drawing.Point(95, 153);
            this.Kecican.Name = "Kecican";
            this.Kecican.Size = new System.Drawing.Size(209, 26);
            this.Kecican.TabIndex = 9;
            this.Kecican.Value = 100;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label20.Location = new System.Drawing.Point(95, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(209, 23);
            this.label20.TabIndex = 8;
            this.label20.Text = "CANLI";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Iyembutton
            // 
            this.Iyembutton.Location = new System.Drawing.Point(95, 95);
            this.Iyembutton.Name = "Iyembutton";
            this.Iyembutton.Size = new System.Drawing.Size(209, 26);
            this.Iyembutton.TabIndex = 7;
            this.Iyembutton.Text = "YEM VER";
            this.Iyembutton.UseVisualStyleBackColor = true;
            this.Iyembutton.Click += new System.EventHandler(this.İyembutton_Click);
            // 
            // Inekcan
            // 
            this.Inekcan.Location = new System.Drawing.Point(95, 63);
            this.Inekcan.Name = "Inekcan";
            this.Inekcan.Size = new System.Drawing.Size(209, 26);
            this.Inekcan.TabIndex = 6;
            this.Inekcan.Value = 100;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label19.Location = new System.Drawing.Point(95, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(209, 23);
            this.label19.TabIndex = 5;
            this.label19.Text = "CANLI";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(6, 127);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(83, 77);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(6, 37);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(83, 84);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label18.Location = new System.Drawing.Point(6, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(298, 23);
            this.label18.TabIndex = 2;
            this.label18.Text = "AHIR";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Öyembutton);
            this.panel5.Controls.Add(this.Ördekcan);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.Tyembutton);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Controls.Add(this.Tavukcan);
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Location = new System.Drawing.Point(14, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(297, 210);
            this.panel5.TabIndex = 0;
            // 
            // Öyembutton
            // 
            this.Öyembutton.Location = new System.Drawing.Point(92, 181);
            this.Öyembutton.Name = "Öyembutton";
            this.Öyembutton.Size = new System.Drawing.Size(202, 26);
            this.Öyembutton.TabIndex = 9;
            this.Öyembutton.Text = "YEM VER";
            this.Öyembutton.UseVisualStyleBackColor = true;
            this.Öyembutton.Click += new System.EventHandler(this.Öyembutton_Click);
            // 
            // Ördekcan
            // 
            this.Ördekcan.Location = new System.Drawing.Point(92, 153);
            this.Ördekcan.Name = "Ördekcan";
            this.Ördekcan.Size = new System.Drawing.Size(202, 26);
            this.Ördekcan.TabIndex = 8;
            this.Ördekcan.Value = 100;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label17.Location = new System.Drawing.Point(92, 127);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(202, 23);
            this.label17.TabIndex = 7;
            this.label17.Text = "CANLI";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tyembutton
            // 
            this.Tyembutton.Location = new System.Drawing.Point(92, 95);
            this.Tyembutton.Name = "Tyembutton";
            this.Tyembutton.Size = new System.Drawing.Size(202, 26);
            this.Tyembutton.TabIndex = 6;
            this.Tyembutton.Text = "YEM VER";
            this.Tyembutton.UseVisualStyleBackColor = true;
            this.Tyembutton.Click += new System.EventHandler(this.Tyembutton_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Location = new System.Drawing.Point(92, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(202, 23);
            this.label16.TabIndex = 4;
            this.label16.Text = "CANLI";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 127);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(83, 77);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(83, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(3, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(291, 23);
            this.label15.TabIndex = 1;
            this.label15.Text = "KÜMES";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(652, 463);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Name = "Form1";
            this.Text = "HAYVAN ÇİFTLİĞİ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar Tavukcan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Tyumurtasayı;
        private System.Windows.Forms.Label Isutsayı;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Oyumurtasayı;
        private System.Windows.Forms.Label Ksutsayı;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label Kasa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label Gecensure;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button Ksutbutton;
        private System.Windows.Forms.Button Isutbutton;
        private System.Windows.Forms.Button Oyumurtabutton;
        private System.Windows.Forms.Button Tyumurtabutton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button Tyembutton;
        private System.Windows.Forms.Button Kyembutton;
        private System.Windows.Forms.ProgressBar Kecican;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button Iyembutton;
        private System.Windows.Forms.ProgressBar Inekcan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button Öyembutton;
        private System.Windows.Forms.ProgressBar Ördekcan;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
    }
}

