﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje1
{
    //Kalıtım alınmıştır.
    class KECİ : HAYVAN, ICiftlik
    {
        //ses çal fonksiyonu ile medya oluşturulmuştur.
        public void SesCal()
        {
            System.Media.SoundPlayer hayvan_sesleri = new System.Media.SoundPlayer();
            hayvan_sesleri.SoundLocation = "keci.wav";
            hayvan_sesleri.Play();
        }
        public int keci_sutu = 0;
    }
}
