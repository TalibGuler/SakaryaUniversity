﻿/**************************************************************
***
***                  SAKARYA ÜNİVERSİTESİ
***         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
***              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
***             NESNEYE DAYALI PROGRAMLAMA DERSİ
***
***			ÖDEV NUMARASI....: PROJE
***			ÖĞRENCİ ADI......:Abdülmuttalib GÜLER
***			ÖĞRENCİ NUMARASI.:G181210011
***			DERS GRUBU.......:A Grubu (İÖ)
***
**************************************************************/

using System;
using System.Windows.Forms;

namespace Proje1
{
    public partial class Form1 : Form
    {
        //Gerekli değişkenler tanımlandı ve nesneler çağırıldı.
        public int mangır = 0;
        public int gecen_sure = 0;
        ORDEK oRDEK = new ORDEK();
        KECİ kECİ = new KECİ();
        INEK inek = new INEK();
        TAVUK tAVUK = new TAVUK();
        
        
     

        

       

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Gerekli timer atamları yapıldı.
            timer1.Interval = 1000;
            timer1.Enabled = true;
            timer1.Start();

            timer2.Interval = 1000;
            timer2.Enabled = true;
            timer2.Start();

            timer3.Interval = 1000;
            timer3.Enabled = true;
            timer3.Start();

            timer4.Interval = 1000;
            timer4.Enabled = true;
            timer4.Start();

            timer5.Interval = 1000;
            timer5.Enabled = true;
            timer5.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Ekrana geçen süre yazdırıldı.
            gecen_sure = gecen_sure + 1;
            Gecensure.Text = Convert.ToString(gecen_sure)+" "+"SN";

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //tavuğun canı 0 dan büyük olduğu sürece çalışan kontrol.
            if (Tavukcan.Value > 0)
            {
                 Tavukcan.Value = Tavukcan.Value - 2;
                 if (Tavukcan.Value == 0)
                 {
                   timer2.Enabled = false;
                   label16.Text = "ÖLDÜ";
                   Tyembutton.Enabled = false;

                    tAVUK.SesCal();
                 }
            }
            //3 saniyede bir kontrolün satırlarını işleyen kod parçası.
            if (gecen_sure % 3 == 0 && gecen_sure != 0)
            {
                tAVUK.tavuk_yumurtası = tAVUK.tavuk_yumurtası + tAVUK.yumurta_artması;
                Tyumurtasayı.Text = Convert.ToString(tAVUK.tavuk_yumurtası)+" "+"ADET";
                
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            //Gecen süre sıfırdan büyükse alt satırları işleyen  kontrol.
            if (gecen_sure > 0)
            {

                Ördekcan.Value = Ördekcan.Value - 3;
                if (Ördekcan.Value == 1)
                {
                    Ördekcan.Value = Ördekcan.Value - 1;
                }
                if (Ördekcan.Value == 0)
                {
                    timer3.Enabled = false;
                    label17.Text = "ÖLDÜ";
                    Öyembutton.Enabled = false;

                    oRDEK.SesCal();
                }
            }

            //5 saniyede bir kontrolün satırlarını işleyen kod parçası.
            if (gecen_sure % 5 == 0 && gecen_sure != 0)
                 {
                    oRDEK.ordek_yumurtası = oRDEK.ordek_yumurtası + oRDEK.yumurta_artması;
                    Oyumurtasayı.Text = Convert.ToString(oRDEK.ordek_yumurtası)+" "+"ADET";
                    
                 }
           
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            //Gecen süre sıfırdan büyükse alt satırları işleyen  kontrol.
            if (gecen_sure > 0 )
            {
                Inekcan.Value = Inekcan.Value - 8;

                if (Inekcan.Value == 4)
                {
                    Inekcan.Value = Inekcan.Value - 4;
                }
                if (Inekcan.Value == 0)
                {
                    timer4.Enabled = false;
                    label19.Text = "ÖLDÜ";
                    Iyembutton.Enabled = false;

                    inek.SesCal();
                }
            }

            //8 saniyede bir kontrolün satırlarını işleyen kod parçası.
            if (gecen_sure % 8 == 0 && gecen_sure != 0)
            {
                inek.inek_sutu = inek.inek_sutu + inek.sut_artması;
                Isutsayı.Text = Convert.ToString(inek.inek_sutu)+" "+"KG";
                

            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            //Gecen süre sıfırdan büyükse alt satırları işleyen  kontrol.
            if (gecen_sure > 0)
            {
                Kecican.Value = Kecican.Value - 6;
                if (Kecican.Value == 4)
                {
                    Kecican.Value = Kecican.Value - 4;
                }
                if (Kecican.Value == 0)
                {
                    timer5.Enabled = false;
                    label20.Text = "ÖLDÜ";
                    Kyembutton.Enabled = false;

                    kECİ.SesCal();
                }
            }

            //7 saniyede bir kontrolün satırlarını işleyen kod parçası.
            if (gecen_sure % 7 ==0 && gecen_sure != 0)
            {
                kECİ.keci_sutu = kECİ.keci_sutu + kECİ.sut_artması;
                Ksutsayı.Text = Convert.ToString(kECİ.keci_sutu)+" "+"KG";
                

            }
        }
        //Can veren buton.
        private void Tyembutton_Click(object sender, EventArgs e)
        {
            Tavukcan.Value = 100;
           
        }
        //Can veren buton.
        private void Öyembutton_Click(object sender, EventArgs e)
        {
            Ördekcan.Value = 100;
            
        }
        //Can veren buton.
        private void İyembutton_Click(object sender, EventArgs e)
        {
            Inekcan.Value = 100;
           
        }
        //Can veren buton.
        private void Kyembutton_Click(object sender, EventArgs e)
        {
            Kecican.Value = 100;
        }
        //Satan buton.
        private void Tyumurtabutton_Click(object sender, EventArgs e)
        {
            mangır = mangır + tAVUK.tavuk_yumurtası;
           
            Kasa.Text = Convert.ToString(mangır) + " " + "TL";
            tAVUK.tavuk_yumurtası = 0;
            Tyumurtasayı.Text = Convert.ToString(tAVUK.tavuk_yumurtası)+" "+"ADET";
        }
        //Satan buton.

        private void Öyumurtabutton_Click(object sender, EventArgs e)
        {
            mangır = mangır + (oRDEK.ordek_yumurtası * 3);
            Kasa.Text = Convert.ToString(mangır + " " + "TL");
            oRDEK.ordek_yumurtası = 0;
            Oyumurtasayı.Text = Convert.ToString(oRDEK.ordek_yumurtası)+" "+"ADET";
        }
        //Satan buton.
        private void İsütbutton_Click(object sender, EventArgs e)
        {
            mangır = mangır + (inek.inek_sutu * 5);
            Kasa.Text = Convert.ToString(mangır) + " " + "TL";
           inek.inek_sutu = 0;
            Isutsayı.Text = Convert.ToString(inek.inek_sutu)+" "+"KG";
        }
        //Satan buton.
        private void Ksütbutton_Click(object sender, EventArgs e)
        {
            mangır = mangır + (kECİ.keci_sutu* 8);
            Kasa.Text = Convert.ToString(mangır)+" "+"TL";
            kECİ.keci_sutu = 0;
            Ksutsayı.Text = Convert.ToString(kECİ.keci_sutu)+" "+"KG";
        }
    }
}