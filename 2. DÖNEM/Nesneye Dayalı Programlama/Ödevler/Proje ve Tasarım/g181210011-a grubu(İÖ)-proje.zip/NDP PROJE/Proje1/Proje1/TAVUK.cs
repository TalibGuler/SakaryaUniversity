﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje1
{
    //Kalıtım alınmıştır.
    class TAVUK : HAYVAN,ICiftlik
    {
        //ses çal fonksiyonu ile medya oluşturulmuştur.
        public void SesCal()
        {
            System.Media.SoundPlayer hayvan_sesleri = new System.Media.SoundPlayer();
            hayvan_sesleri.SoundLocation = "tavuk.wav";
            hayvan_sesleri.Play();
        }
        public int tavuk_yumurtası = 0;
    }
}
