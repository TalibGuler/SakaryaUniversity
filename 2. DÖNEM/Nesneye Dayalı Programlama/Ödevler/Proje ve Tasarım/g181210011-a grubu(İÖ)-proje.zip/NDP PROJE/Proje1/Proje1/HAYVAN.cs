﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje1
{
    abstract class HAYVAN
    {
        //tüm projede kullanılan değişkenler.
        public int yumurta_artması = 1;
        public int sut_artması = 1;
        

        

        

    }
}
