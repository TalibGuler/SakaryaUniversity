﻿/**************************************************************
***
***                  SAKARYA ÜNİVERSİTESİ
***         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
***              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
***             NESNEYE DAYALI PROGRAMLAMA DERSİ
***
***			ÖDEV NUMARASI....:2
***			ÖĞRENCİ ADI......:Abdülmuttalib GÜLER
***			ÖĞRENCİ NUMARASI.:G181210011
***			DERS GRUBU.......:A Grubu (İÖ)
***
**************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev2
{
    class defans:Futbolcu
    {
                private int pozisyon_alma;
                private int kafa;
                private int sicrama;

            public defans(string ad_soyad, int forma_no): base(ad_soyad,forma_no)
            {
                this.ad_soyad = ad_soyad;
                this.forma_no = forma_no;
            
                pozisyon_alma = rstsayi.Next(50, 90);
                kafa = rstsayi.Next(50, 90);
                sicrama = rstsayi.Next(50, 90);
            }

            public override Boolean pas_ver()
            {
                int PasSkor = Convert.ToInt32(pas * 0.3 + yetenek * 0.3 + dayaniklilik * 0.1 + dogal_form * 0.1 + pozisyon_alma * 0.1 + sans * 0.2);
                if (PasSkor > 60)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public override bool gol_vurusu()
            {
                int GolSkor = Convert.ToInt32(yetenek * 0.3 + sut * 0.2 + kararlilik * 0.1 + dogal_form * 0.1 + kafa * 0.1 + sicrama * 0.1 + sans * 0.1);
                if (GolSkor > 70)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
    }
}
