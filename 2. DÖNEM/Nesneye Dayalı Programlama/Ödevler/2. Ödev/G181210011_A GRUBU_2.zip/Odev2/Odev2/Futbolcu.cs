﻿/**************************************************************
***
***                  SAKARYA ÜNİVERSİTESİ
***         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
***              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
***             NESNEYE DAYALI PROGRAMLAMA DERSİ
***
***			ÖDEV NUMARASI....:2
***			ÖĞRENCİ ADI......:Abdülmuttalib GÜLER
***			ÖĞRENCİ NUMARASI.:G181210011
***			DERS GRUBU.......:A Grubu (İÖ)
***
**************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev2
{
    class Futbolcu
    {
        public Random rstsayi = new Random();

        public string ad_soyad;
        public int forma_no;
        protected int hiz;
        protected int dayaniklilik;
        protected int pas;
        protected int sut;
        protected int yetenek;
        protected int kararlilik;
        protected int dogal_form;
        protected int sans;

        public Futbolcu(string ad_soyad,int forma_no)
        {
            hiz = rstsayi.Next(50, 100);
            dayaniklilik = rstsayi.Next(50, 100);
            pas = rstsayi.Next(50, 100);
            sut = rstsayi.Next(50, 100);
            yetenek = rstsayi.Next(50, 100);
            kararlilik = rstsayi.Next(50, 100);
            dogal_form = rstsayi.Next(50, 100);
            sans = rstsayi.Next(50, 100);
        }
      
        public virtual Boolean pas_ver()
        {
            int PasSkor =Convert.ToInt32(pas * 0.3 + yetenek * 0.3 + dayaniklilik * 0.1 + dogal_form * 0.1 +sans * 0.2);
            if(PasSkor>60)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public virtual Boolean gol_vurusu()
        {
            int GolSkor =Convert.ToInt32(yetenek * 0.3 + sut * 0.2 + kararlilik * 0.1 + dogal_form * 0.1 + hiz * 0.1 + sans * 0.2);
            if (GolSkor > 70)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
