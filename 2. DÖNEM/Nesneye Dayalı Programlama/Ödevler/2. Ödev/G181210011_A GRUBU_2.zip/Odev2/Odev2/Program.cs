﻿/**************************************************************
***
***                  SAKARYA ÜNİVERSİTESİ
***         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
***              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
***             NESNEYE DAYALI PROGRAMLAMA DERSİ
***
***			ÖDEV NUMARASI....:2
***			ÖĞRENCİ ADI......:Abdülmuttalib GÜLER
***			ÖĞRENCİ NUMARASI.:G181210011
***			DERS GRUBU.......:A Grubu (İÖ)
***
**************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Futbolcu> kadro = new List<Futbolcu>();
            kadro.Add(new Futbolcu("DİDA", 1));
            kadro.Add(new defans("NESTA", 2));
            kadro.Add(new defans("STAM", 3));
            kadro.Add(new defans("CAFU", 4));
            kadro.Add(new defans("MALDİNİ", 5));
            kadro.Add(new orta_saha("PİRLO", 6));
            kadro.Add(new orta_saha("GATTUSO", 7));
            kadro.Add(new orta_saha("SEEDORF", 8));
            kadro.Add(new orta_saha("KAKA", 9));
            kadro.Add(new forvet("SHEVCHENKO", 10));
            kadro.Add(new forvet("INZAGHI", 11));

            Random rst = new Random();
            int forma_no;
            int pas_kontrol=12  ;
            Boolean gol_olabilir = true;
            forma_no = rst.Next(1, 11);

            for (int i=1; i<=3; i++)
            {
                while(pas_kontrol==forma_no)
                {
                  forma_no = rst.Next(1, 11);
                }
                pas_kontrol = forma_no;
               
                if (!kadro[forma_no].pas_ver())
                {
                    Console.WriteLine(kadro[forma_no].ad_soyad + " pası hedefi bulmadı");
                    gol_olabilir = false;
                    break;
                }
                else
                {
                    Console.WriteLine(kadro[forma_no].ad_soyad + " mükemmel bir pas atıyor");
                    
                }
            }

            forma_no = rst.Next(1, 11);

           
            if (gol_olabilir == true)
            {
                if (kadro[forma_no].gol_vurusu())
                {
                    Console.WriteLine("topla bulusan " + kadro[forma_no].ad_soyad);
                    Console.WriteLine(kadro[forma_no].ad_soyad + " harika çalımlar atıyorrr");
                    Console.WriteLine(kadro[forma_no].ad_soyad + "  kaleciyle karsı karsıya");
                    Console.WriteLine(kadro[forma_no].ad_soyad + " vuruyorrr veee Golllllll top aglarla bulusuyor");
                }
                else
                {
                    Console.WriteLine("topla bulusan " + kadro[forma_no].ad_soyad);
                    Console.WriteLine(kadro[forma_no].ad_soyad + " harika çalımlar atıyorrr");
                    Console.WriteLine(kadro[forma_no].ad_soyad + "  kaleciyle karsı karsıya");
                    Console.WriteLine(kadro[forma_no].ad_soyad + " sutunu cekti ve top dısarıda");
                }
            }

            Console.ReadLine(); 
        }
    }
}
