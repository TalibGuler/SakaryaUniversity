﻿/**************************************************************
***
***                  SAKARYA ÜNİVERSİTESİ
***         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
***              BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
***             NESNEYE DAYALI PROGRAMLAMA DERSİ
***
***			ÖDEV NUMARASI....:2
***			ÖĞRENCİ ADI......:Abdülmuttalib GÜLER
***			ÖĞRENCİ NUMARASI.:G181210011
***			DERS GRUBU.......:A Grubu (İÖ)
***
**************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev2
{
    class orta_saha:Futbolcu
    {
        private int uzun_top;
        private int ilk_dokunus;
        private int uretkenlik;
        private int top_surme;
        private int ozel_yetenek;

        public orta_saha(string ad_soyad, int forma_no) : base(ad_soyad, forma_no)
        {
            this.ad_soyad = ad_soyad;
            this.forma_no = forma_no;
            

            uzun_top = rstsayi.Next(60, 100);
            ilk_dokunus = rstsayi.Next(60, 100);
            uretkenlik = rstsayi.Next(60, 100);
            top_surme = rstsayi.Next(60, 100);
            ozel_yetenek = rstsayi.Next(60, 100);
        }

        public override Boolean pas_ver()
        {
            int PasSkor = Convert.ToInt32(pas * 0.3 + yetenek * 0.2 + ozel_yetenek * 0.2 + dayaniklilik * 0.1 + dogal_form * 0.1 + uzun_top * 0.1 + top_surme * 0.1 + sans * 0.1);
            if (PasSkor > 60)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override Boolean gol_vurusu()
        {
            int GolSkor = Convert.ToInt32(yetenek * 0.3 + ozel_yetenek * 0.2 + sut * 0.2 + ilk_dokunus * 0.1 + kararlilik * 0.1 + dogal_form * 0.1 + sans * 0.1);
            if (GolSkor > 70)
            {
                return true;
            }
            else
            {
                return false;
            }
        }   
    }
}
