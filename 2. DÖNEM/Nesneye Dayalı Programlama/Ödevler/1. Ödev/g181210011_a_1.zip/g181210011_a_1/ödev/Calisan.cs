﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödev
{
    class Calisan
    {
        public string _Tc, _Ad, _Soyad,_personelResmiYol;
        public int _yas, _cocukSayisi;
        public double _calismaSuresi, _tabanMaas, _idariGorevTazminati, _makamTazminati, _fazlaMesaiSaati, _fazlaMesaiUcreti, _vergiMatrahi;
        public bool _evlilikDurumu, _esCalis;
        public double _BurutMaas = 0;
        public double _DamgaVergisi = 0;
        public double _GelirVergisi;
        public double _EmekliKesintisi = 0;
        public double _netMaas = 0;

        public bool es_calisma_durumu { get; internal set; }
        public bool evlilik_durumu { get; internal set; }

        public double BurutMaasHesapla()
        {
            if (_evlilikDurumu == false)
            {
                _BurutMaas = _tabanMaas + _makamTazminati + _idariGorevTazminati + (_cocukSayisi * 30) + (_fazlaMesaiSaati * _fazlaMesaiUcreti);
                
                
            }
            else if(_evlilikDurumu==true && _esCalis == true)
            {
                _BurutMaas = _tabanMaas + _makamTazminati + _idariGorevTazminati + (_cocukSayisi * 30) + (_fazlaMesaiSaati * _fazlaMesaiUcreti);
            }
            else if(_evlilikDurumu==true && _esCalis == false)
            {
                _BurutMaas = _tabanMaas + _makamTazminati + _idariGorevTazminati + (_cocukSayisi * 30) + (_fazlaMesaiSaati * _fazlaMesaiUcreti)+200;
            }
            return _BurutMaas;
        }

        public double DamgaVergisi()
        {
            _DamgaVergisi = _BurutMaas * 10 / 100;
            return _DamgaVergisi;
        }

        public double GelirVergisi()
        {
            if (_vergiMatrahi < 10000)
            {
                _GelirVergisi = _BurutMaas * 3/20;
            }
            else if(_vergiMatrahi>=10000 && _vergiMatrahi < 20000)
            {
                _GelirVergisi = _BurutMaas * 1/5;
            }
            else if(_vergiMatrahi>=20000 && _vergiMatrahi < 30000)
            {
                _GelirVergisi = _BurutMaas * 1/4;
            }
            else if (_vergiMatrahi >= 30000)
            {
                _GelirVergisi = _BurutMaas * 3 / 10;
            }
            return _GelirVergisi;
        }
        public double EmekliKesintisi()
        {
            _EmekliKesintisi = _BurutMaas * 3 / 20;
            return _EmekliKesintisi;
        }
        public double NetMaas()
        {
            _netMaas = _BurutMaas - (_EmekliKesintisi + _GelirVergisi + _DamgaVergisi);
            return _netMaas;

        }
       
    }
}
