﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI.......:G181210011
**                         DERSİN ALINDIĞI GRUP...:A(İ.Ö)
****************************************************************************/




using System;
using System.Windows.Forms;

namespace ödev
{
    public partial class Form1 : Form
    {
        //obje cağırıldı
        Calisan calisan = new Calisan();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //split metodu
            string[] satirlar;
            string hepsi = richTextBox1.Text;
            satirlar = hepsi.Split('\n'); //dosya satırlara ayrılabilir.
            foreach (string s in satirlar) // personel bilgileri(satırlar) ayrıştırılabilir.
            {
                string[] kelimeler = s.Split(' ');
                foreach(var items in kelimeler)
                {
                    var i = 0;
                    if (textBox1.Text == "")
                    {
                        MessageBox.Show("Boş Bırakılamaz!");
                        break;
                    }
                    else if(textBox1.Text !=kelimeler[i] && textBox1.TextLength != kelimeler[i].Length)
                    {
                        MessageBox.Show("Bulunamadı!");
                        break;
                    }
                    else if(textBox1.Text==kelimeler[i] && textBox1.TextLength == kelimeler[i].Length)
                    {
                        if (kelimeler[i + 5] == "E")
                        {
                            calisan._evlilikDurumu = true;
                        }
                        else if (kelimeler[i + 5] == "H")
                        {
                            calisan._evlilikDurumu = false;
                        }
                        
                        if (kelimeler[i + 6] == "E")
                        {
                            calisan._esCalis = true;
                        }
                        else if (kelimeler[i + 6] == "H")
                        {
                            calisan._esCalis = false;
                        }
                        //değişken atamaları yapıldı
                        calisan._Tc = Convert.ToString(kelimeler[i]);
                        calisan._Ad = Convert.ToString(kelimeler[i + 1]);
                        calisan._Soyad = Convert.ToString(kelimeler[i + 2]);
                        calisan._yas = Convert.ToInt32(kelimeler[i + 3]);
                        calisan._calismaSuresi = Convert.ToInt32(kelimeler[i + 4]);
                        calisan._cocukSayisi = Convert.ToInt32(kelimeler[i + 7]);
                        calisan._tabanMaas = Convert.ToInt32(kelimeler[i + 8]);
                        calisan._makamTazminati = Convert.ToInt32(kelimeler[i + 9]);
                        calisan._idariGorevTazminati = Convert.ToInt32(kelimeler[i + 10]);
                        calisan._fazlaMesaiSaati = Convert.ToInt32(kelimeler[i + 11]);
                        calisan._fazlaMesaiUcreti = Convert.ToInt32(kelimeler[i + 12]);
                        calisan._vergiMatrahi = Convert.ToInt32(kelimeler[i+13]);
                        calisan._personelResmiYol = kelimeler[i + 1];
                        i++;
                    }
                    
                }              
            }
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox2.Text = "Bürüt Maaşı:" + calisan._BurutMaas + "TL" + "\n" + "Damga Vergisi:" + calisan._DamgaVergisi + "TL" + "\n" + "Emekli Kesintisi:" + calisan._EmekliKesintisi + "TL" + "\n" + "Gelir Vergisi:" + calisan._GelirVergisi + "\n" + "Net Maas:" + calisan._netMaas;
        }
    }
}
