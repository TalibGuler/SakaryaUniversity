﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2018-2019 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:3
**				ÖĞRENCİ ADI............:Abdülmuttalib GÜLER
**				ÖĞRENCİ NUMARASI.......:G181210011
**              DERSİN ALINDIĞI GRUP...:2A(İ.Ö)
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable Tablo_Islem = new DataTable();
            DataRow row = Tablo_Islem.NewRow();
            int Sayac1 = 0, SilinenSayac = 0, Sayac2 = 0, sayac3 = 0, sayac_carpim = 0, sayac_bolum = 0, sayac_arti = 0, sayac_eksi = 0;
            int sayac = 0;
            double sonuc = 0;
            string islem;
            islem = textBox1.Text;

            //İslem uzunlugunu kontrol eder.
            while (Sayac1 < islem.Length)
            {
                //islem turunu kontrol eder.
                if (islem[Sayac1] == '*')
                {

                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = islem.Substring(SilinenSayac, Sayac1 - SilinenSayac);
                    
                    sayac3++;
                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = "*";
                    
                    Sayac1++;
                    SilinenSayac = Sayac1;

                    sayac3++;
                    sayac = Sayac1;

                }
                //islem turunu kontrol eder.
                else if (islem[Sayac1] == '/')
                {

                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = islem.Substring(SilinenSayac, Sayac1 - SilinenSayac);
                    
                    sayac3++;
                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = "/";
                    
                    Sayac1++;
                    SilinenSayac = Sayac1;

                    sayac3++;
                    sayac = Sayac1;
                }
                //islem turunu kontrol eder.
                else if (islem[Sayac1] == '+')
                {

                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = islem.Substring(SilinenSayac, Sayac1 - SilinenSayac);
                    
                    sayac3++;
                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    row[sayac3] = "+";
                   
                    Sayac1++;
                    SilinenSayac = Sayac1;

                    sayac3++;
                    sayac = Sayac1;
                }
                //islem turunu kontrol eder.
                else if (islem[Sayac1] == '-')
                {

                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));

                    row[sayac3] = islem.Substring(SilinenSayac, Sayac1 - SilinenSayac);
                    
                    sayac3++;
                    Tablo_Islem.Columns.Add(Convert.ToString(sayac3));
                    
                    row[sayac3] = "-";
                    
                    
                    Sayac1++;
                    SilinenSayac = Sayac1;

                    sayac3++;
                    sayac = Sayac1;
                }
                //diğer durumları kontrol eder
                else
                {

                    Sayac1++;

                }


            }

            //yeni tablo olusturur.
            Tablo_Islem.Columns.Add(Convert.ToString(Tablo_Islem.Columns.Count));
            row[Tablo_Islem.Columns.Count - 1] = islem.Substring(sayac);


            Sayac1 = 0; SilinenSayac = 0; Sayac2 = 0; sayac3 = 0;
            string islem_sag, islem_sol;
            double carpim_sonuc = 0, bolum_sonuc = 0, arti_sonuc = 0, eksi_sonuc = 0, sonuc_sayac_eksi = 0, sonuc_sayac_arti = 0, sonuc_sayac_carpim = 0, sonuc_sayac_bolum = 0;
            while (Sayac2 <= Tablo_Islem.Columns.Count)
            {
                //islem onceligini kontrol eder.
                while (sayac_carpim < Tablo_Islem.Columns.Count)
                {
                    //islem onceligini kontrol eder.
                    if (row[sayac_carpim] == "*")
                    {
                        islem_sag = Convert.ToString(row[sayac_carpim - 1]);
                        islem_sol = Convert.ToString(row[sayac_carpim + 1]);
                        carpim_sonuc = Convert.ToDouble(islem_sag) * Convert.ToDouble(islem_sol);
                        row[sayac_carpim - 1] = '0';
                        row[sayac_carpim + 1] = carpim_sonuc;
                        sayac_carpim++;
                        sonuc_sayac_carpim++;
                    }
                    //islem onceligini kontrol eder.
                    else
                    {
                        sayac_carpim++;
                    }
                }
                //islem onceligini kontrol eder.
                while (sayac_bolum < Tablo_Islem.Columns.Count)
                {
                    //islem onceligini kontrol eder.
                    if (row[sayac_bolum] == "/")
                    {

                        islem_sag = Convert.ToString(row[sayac_bolum - 1]);
                        islem_sol = Convert.ToString(row[sayac_bolum + 1]);
                        bolum_sonuc = Convert.ToDouble(islem_sag) / Convert.ToDouble(islem_sol);
                        row[sayac_bolum - 1] = '0';
                        row[sayac_bolum + 1] = bolum_sonuc;
                        sayac_bolum++;
                        sonuc_sayac_bolum++;
                    }
                    else
                    {
                        sayac_bolum++;
                    }
                }
                //islem onceligini kontrol eder.
                while (sayac_arti < Tablo_Islem.Columns.Count)
                {
                    //islem onceligini kontrol eder.
                    if (row[sayac_arti] == "+")
                    {

                        islem_sag = Convert.ToString(row[sayac_arti - 1]);
                        islem_sol = Convert.ToString(row[sayac_arti + 1]);
                        arti_sonuc = Convert.ToDouble(islem_sag) + Convert.ToDouble(islem_sol);
                        row[sayac_arti - 1] = '0';
                        row[sayac_arti + 1] = arti_sonuc;
                        sayac_arti++;
                        sonuc_sayac_arti++;




                    }
                    else
                    {
                        sayac_arti++;
                    }
                }
                //islem onceligini kontrol eder.
                while (sayac_eksi < Tablo_Islem.Columns.Count)
                {
                    if (row[sayac_eksi] == "-")
                    {
                        islem_sag = Convert.ToString(row[sayac_eksi - 1]);
                        islem_sol = Convert.ToString(row[sayac_eksi + 1]);
                        eksi_sonuc = Convert.ToDouble(islem_sag) - Convert.ToDouble(islem_sol);
                        row[sayac_eksi - 1] = '0';
                        row[sayac_eksi + 1] = eksi_sonuc;
                        sayac_eksi++;
                        sonuc_sayac_eksi++;
                    }
                    else
                    {
                        sayac_eksi++;
                    }
                }
                Sayac2++;
            }

            int sayac5 = 0, sayac20 = 0;
            //İslem ifadelerini tabloya ekler.
            while (sayac5 < Tablo_Islem.Columns.Count)
            {
                //İslem ifadelerini tabloya ekler.
                if (row[sayac20] == "+")
                {
                    sonuc = arti_sonuc;
                    sayac20++;
                    sayac5++;
                }
                //İslem ifadelerini tabloya ekler.
                else if (row[sayac20] == "-")
                {
                    sonuc = eksi_sonuc;
                    sayac20++;
                    sayac5++;
                }
                //İslem ifadelerini tabloya ekler.
                else if (row[sayac20] == "/")
                {
                    sonuc = bolum_sonuc;
                    sayac20++;
                    sayac5++;
                }
                //İslem ifadelerini tabloya ekler.
                else if (row[sayac20] == "*")
                {
                    sonuc = carpim_sonuc;
                    sayac20++;
                    sayac5++;
                }
                //İslem ifadelerini tabloya ekler.
                else
                {
                    sayac20++;
                    sayac5++;
                }
            }
            
            //sonucu textboxa yazdırır.
            textBox2.Text = Convert.ToString(sonuc);
        }
    }
}