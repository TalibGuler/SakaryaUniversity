var i=0;
var resimler=["https://www.nenerede.com.tr/wp-content/uploads/2017/04/Ardahan-Kalesi.jpg","https://gezilecekyerler.com/wp-content/uploads/2016/12/2784163-seytan-kalesi-2.jpg","https://lh3.googleusercontent.com/p/AF1QipNakPIQv_-bahwf9lHKoZz_zJ6vfb5CURyay3Ve=s1600-w1000","https://www.otelcenneti.com/uploads/blog/ardahanin-dogal-harikalari.jpg","http://icsmd2018.org/images/1220.jpg"]

var bekleme_Suresi=3000;

function slideImg(){
    document.slide.src=resimler[i];
    if(i<resimler.length-1){
        i++;
    }
    else{
        i=0;
    }
    setTimeout("slideImg()",bekleme_Suresi)
}

window.onload=slideImg;