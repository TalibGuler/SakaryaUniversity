/**
* @file Dugum
* @description saga sola ekleme
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef DUGUM_HPP
#define DUGUM_HPP

#include <iostream>
#include <Kisi.hpp>
using namespace std;

class Dugum
{
public:
    //Kisi
    Kisi *kisi;
    //sag dugum
    Dugum *sag;
    // sol dugum
    Dugum *sol;
    // dugum agirlik
    int yukseklik=0;
    //dugum onceki agirlik
    int eskiYukseklik=-1 ;

    Dugum(Kisi* , Dugum *, Dugum *);
   
};

#endif
