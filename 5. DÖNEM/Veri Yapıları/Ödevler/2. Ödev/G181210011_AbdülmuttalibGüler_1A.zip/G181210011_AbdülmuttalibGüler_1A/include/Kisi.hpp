/**
* @file Kisi
* @description kisi �zelliklerini bar�nd�r�yor
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef KISI_HPP
#define KISI_HPP
#include <iostream>
#include <string>
using namespace std;

class Kisi
{ // dosyadan okunacak kisi sinifi
private:
    //kisinin ismi
    string isim;
	string isAdi;
    //Kisinin dogum yili
    int yil;
    //kisinin yasi

public:
    //Bos kurucu
    Kisi() {}
    /*
    * ilk parametre isim degeri
    * ikinci parametre Dogum yili
    * ucuncu parametre kilo
    */
    Kisi(string, string, int);
    //isim belirleme fonksiyonu
    void setIsim(string);
    //dogum yili belirleme
    void setIsAdi(string);
    // kilo belirleme
    void setYil(int);
    //Kisinin yasini dönürüyor
    string getIsim();
    //Kisinin ismini döndürüyor
    string getIsAdi();
    //Kisinin Kilosunu döndürüyor
    int getYil();
    // kisninin dohgum yilini donen
    
};

#endif
