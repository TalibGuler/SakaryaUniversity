/**
* @file AVLTree
* @description avl a�ac�m buras� s�ralama i�in
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef AVLTREE_HPP
#define AVLTREE_HPP
#include "Dugum.hpp"
#include <cmath>
class AVLTree {
	
private:
	 Dugum *kok;
    // arama ve ekleme
    // ilk parametre alt dugum
    //ikinci parametre yeni nesne
    Dugum *AraVeEkle(Dugum *, Kisi *);
    // alt dugumu parametre alıyor
    Dugum *SolCocukIleDegistir(Dugum *);
    // alt dugumu parametre alıyor
    Dugum *SagCocukIleDegistir(Dugum *);
    //Inorder okuma
    //Parametre alt_dugum
    void Postorder(Dugum *);
    // seviyeyi yazdirma  ilk parametre alt_dugum ikincisi seviye
    int Yukseklik(Dugum *);
    //Dugum silme
    bool DugumSil(Dugum *&);
    //arama yapma
    bool Arama(Dugum *, Kisi *);

public:
    //Kurucu
    AVLTree();
    //Bos mu kontorlu
    bool BosMu();
    //Ekleme Fonksiyonu
    void Ekle(Kisi*);
    //Inorder okuma
    //Parametre alt_dugum
  
    //Parametre alt_dugum
    void Postorder();
    //Levelorder okuma
    //Parametre alt_dugum
    bool Arama(Kisi*);
    //Temizleme
    void Temizleme();
    //Yukseklik
    int Yukseklik();
    //Yikici
    ~AVLTree();


};

#endif
