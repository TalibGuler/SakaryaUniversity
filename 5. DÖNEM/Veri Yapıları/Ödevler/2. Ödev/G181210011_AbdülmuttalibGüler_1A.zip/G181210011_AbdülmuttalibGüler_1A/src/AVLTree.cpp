/**
* @file AVLTree
* @description avl a�ac�m buras� s�ralama i�in
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#include "AVLTree.hpp"
#include "Kisi.hpp"

Dugum* AVLTree::AraVeEkle(Dugum* AltDugum, Kisi* kisi) {

		if (AltDugum == NULL)
			AltDugum = new Dugum(kisi,NULL,NULL); 

		else if (kisi->getYil() < AltDugum->kisi->getYil()) { 
			AltDugum->sol = AraVeEkle(AltDugum->sol, kisi); 
			if (Yukseklik(AltDugum->sol) - Yukseklik(AltDugum->sag) == 2) {
				if (kisi->getYil()< AltDugum->sol->kisi->getYil())
					AltDugum = SolCocukIleDegistir(AltDugum);
				else {
					AltDugum->sol = SagCocukIleDegistir(AltDugum->sol);
					AltDugum = SolCocukIleDegistir(AltDugum);
				}
			}
		}

		else if (kisi->getYil() > AltDugum->kisi->getYil()) { 
			AltDugum->sag = AraVeEkle(AltDugum->sag, kisi);

			if (Yukseklik(AltDugum->sag) - Yukseklik(AltDugum->sol) == 2) {
				if (kisi->getYil() > AltDugum->sag->kisi->getYil())
					AltDugum = SagCocukIleDegistir(AltDugum);
				else {
					AltDugum->sag = SolCocukIleDegistir(AltDugum->sag);
					AltDugum = SagCocukIleDegistir(AltDugum);
				}
			}
		}
	}

Dugum* AVLTree::SolCocukIleDegistir(Dugum* AltDugum) {
		Dugum* tmp = AltDugum->sol;
		AltDugum->sol = tmp->sag;
		tmp->sag = AltDugum;

		AltDugum->yukseklik = Yukseklik(AltDugum);
		tmp->yukseklik = max(Yukseklik(tmp->sol), AltDugum->yukseklik) + 1;

		return tmp;
	}

Dugum* AVLTree::SagCocukIleDegistir(Dugum* AltDugum) {
		Dugum* tmp = AltDugum->sag;
		AltDugum->sag = tmp->sol;
		tmp->sol = AltDugum;

		AltDugum->yukseklik = Yukseklik(AltDugum);
		tmp->yukseklik = max(Yukseklik(tmp->sag), AltDugum->yukseklik) + 1;

		return tmp;
	}

int AVLTree::Yukseklik(Dugum* AltDugum) {
		if (AltDugum == NULL)
			return -1; // Ortada d���m yoksa y�kseklik anlams�zd�r. Kodun �al��mas� ad�na -1 verilmektedir.
		return 1 + max(Yukseklik(AltDugum->sol), Yukseklik(AltDugum->sag));
	}

void AVLTree::Postorder(Dugum* AltDugum) {
		if (AltDugum != NULL) {
			Postorder(AltDugum->sol);//SOL
			Postorder(AltDugum->sag);//SA�
			cout << AltDugum->kisi->getYil() << " ";//K�K
		}
	}


