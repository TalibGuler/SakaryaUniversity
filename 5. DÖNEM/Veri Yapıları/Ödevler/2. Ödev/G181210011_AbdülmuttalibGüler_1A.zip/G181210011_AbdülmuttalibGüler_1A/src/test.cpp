/**
* @file test
* @description program�n �al�st�g� yer
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#include <cmath>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "AVLTree.hpp"
#include "Kisi.hpp"
#include "Dugum.hpp"
#include <Windows.h> 

using namespace std;

int main() {

		SetConsoleOutputCP(65001);
	ifstream dosyaOku("Veri.txt");
	string satir, sayi;
	if (dosyaOku.is_open()) {

		while (getline(dosyaOku, satir)) {
			//cout << satir << endl;
			stringstream stream(satir);
			while (getline(stream, sayi, '#')) {
				
				cout << sayi << endl;

			}
			cout << endl;
		}
		dosyaOku.close();
		return 0;
	}
}
