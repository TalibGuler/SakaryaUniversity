/**
* @file Dugum
* @description saga sola ekleme
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#include "Dugum.hpp"


Dugum::Dugum(Kisi  *kisi, Dugum *right, Dugum *left)
{
	this->kisi=kisi;
    this->sag=sag;
    this->sol=sol;
}

