/**
* @file Kisi
* @description kisi �zelliklerini bar�nd�r�yor
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 20/12/2020
* @author Abd�lmuttalib G�LER
*/
#include "Kisi.hpp"

Kisi::Kisi(string isim, string isAdi, int yil)
{
    this->isim = isim;
    this->isAdi = isAdi;
    this->yil = yil;
}

int Kisi::getYil() { return this->yil; }
string Kisi::getIsim() { return this->isim; }
string Kisi::getIsAdi() { return this->isAdi; }
void Kisi::setIsim(string isim) { this->isim = isim; }
void Kisi::setIsAdi(string isAdi) { this->isAdi = isAdi; }
void Kisi::setYil(int yil) { this->yil = yil; }
