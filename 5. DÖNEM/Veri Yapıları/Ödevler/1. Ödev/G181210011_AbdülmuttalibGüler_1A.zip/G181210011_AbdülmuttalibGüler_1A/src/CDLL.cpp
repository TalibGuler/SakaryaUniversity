/**
*  @file CDLL.cpp
*  @description CircularDoublyLinkedList icin fonksiyon iclerinin oldugu derlenen cpp dosyası
*  @course 1. öğretim A grubu
*  @assignment 1.Odev
*  @date 28.11.2020
*  @author Abdülmuttalib Güler (G181210011) <abdulmuttalib.guler@ogr.sakarya.edu.tr>
*/

#include "CDLL.hpp"

CDLL::CDLL()
{
    point = new Node(0);
    count = 0;
}
bool CDLL::isEmpty()
{
    return count == 0;
}
bool CDLL::isRange(int index)
{
    return index < 0 || index > count;
}
int CDLL::Count()
{
    return count;
}

void CDLL::insertRight(int value)
{
    if (isEmpty())
        return;
    Node *n = new Node(value, n, n);

    if (point->next == point)
    {
        point->next = n;
        n->prev = point;
        Node *start = point->prev;
        while (start->prev != point)
            start = start->prev;
        n->next = start;
        start->prev = n;
        count++;
        return;
    }
    Node *last = point;
    Node *start = point;
    int sp = arraySize / 2;
    for (int i = 0; i < sp; i++)
    {
        start = start->prev;
    }
    // cout << "start : " << start->data << endl;
    last = start->prev;

    n->next = start;
    n->prev = last;
    last->next = n;
    start->prev = n;
    count++;
}
void CDLL::insertLeft(int value)
{
    if (isEmpty())
        return;
    Node *n = new Node(value, n, n);

    if (point->prev == point)
    {
        point->prev = n;
        n->next = point;
        n->prev = point;
        count++;
        return;
    }
    Node *start = point->prev;
    while (start->prev != point)
        start = start->prev;
    n->next = start;
    n->prev = point;
    start->prev = n;

    count++;
}
void CDLL::addArray(int *array, int size)
{
    point = new Node(array[0]);
    point->prev = point;
    point->next = point;
    arraySize = size;
    count++;
    int spit = size / 2;
    for (int i = 1; i < size; i++)
    {

        if (i > spit)
        {
            insertRight(array[i]);
        }
        else
        {
            insertLeft(array[i]);
        }
    }
}

// void CDLL::remove(int data)
// {
// }
void CDLL::removeAt(int index)
{
    Node *start = point;
    for (int i = 0; i < int(arraySize / 2); i++)
    {
        start = start->prev;
    }
    if (start == point)
    {
        arraySize--;
        count--;
        return;
    }
    start->next->prev = start->prev;
    start->prev->next = start->next;

    arraySize--;
    count--;
    free(start);
}

void CDLL::drawList()
{
    if (isEmpty())
    {
        cout << "Liste bos" << endl;
        return;
    }

    int choice = 0;
    if (choice == 0)
    {
        Node *t = point;
        int sp = count / 2;
        for (int i = 0; i < sp; i++)
        {
            t = t->prev;
        }
        for (int j = 0; j < count; j++)
        {
            cout << t->data << " ";
            t = t->next;
        }
    }
    else if (choice == 1)
    {
        Node *t = point;
        int sp = count / 2;
        for (int i = 0; i < count; i++)
        {
            cout << t->data << " ";
            t = t->next;
        }
    }
    cout << endl;
}

void CDLL::Caprazla(CDLL *list)
{
    //Yeni bir liste oluşturuyoruz paramatere gelen listeyi ona eşitlicez
    CDLL *TEMP_LIST = new CDLL();
    //Temp List bizim yeni listemiz
    TEMP_LIST->point = new Node(list->point->data);
    TEMP_LIST->point->prev = TEMP_LIST->point;
    TEMP_LIST->point->next = TEMP_LIST->point;
    TEMP_LIST->count++;
    TEMP_LIST->arraySize = count;

    Node *iter = point;
    for (int i = 0; i < count; i++)
    {

        if (i == int(count / 2))
        {
            iter = point;
            continue;
        }
        if (i < int(count / 2))
        {
            iter = iter->next;
            TEMP_LIST->insertLeft(iter->data);
        }
        else
        {
            iter = iter->prev;
            TEMP_LIST->insertRight(iter->data);
        }
    }

    CDLL *LIST = new CDLL();
    //Temp List bizim yeni listemiz
    LIST->point = new Node(point->data);
    LIST->point->prev = LIST->point;
    LIST->point->next = LIST->point;
    LIST->count++;
    LIST->arraySize = list->count;

    iter = list->point;
    for (int i = 0; i < list->count; i++)
    {

        if (i == int(list->count / 2))
        {
            iter = list->point;
            continue;
        }
        if (i < int(list->count / 2))
        {
            iter = iter->next;
            LIST->insertLeft(iter->data);
        }
        else
        {
            iter = iter->prev;
            LIST->insertRight(iter->data);
        }
    }

    cout << "En Buyuk Liste Orta Dugum Adres : " << LIST->point << endl;
    cout << "En Buyuk Liste Degerler:" << endl;
    LIST->drawList();
    cout << endl
         << endl;
    cout << "En Kucuk Liste Orta Dugum Adres : " << TEMP_LIST->point << endl;
    cout << "En Kucuk Liste Degerler:" << endl;
    TEMP_LIST->drawList();
    delete TEMP_LIST;
    delete LIST;
}

Node *CDLL::getMidPoint()
{
    return point;
}
void CDLL::clear()
{

    while (!isEmpty())
    {
        removeAt(0);
    }
}
CDLL::~CDLL()
{
    clear();
    delete point;
}