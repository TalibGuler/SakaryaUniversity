/**
*  @file Node.cpp
*  @description Dugum icin fonksiyon iclerinin oldugu derlenen cpp dosyası
*  @course 1. öğretim A grubu
*  @assignment 1.Odev
*  @date 28.11.2020
*  @author Abdülmuttalib Güler (G181210011) <abdulmuttalib.guler@ogr.sakarya.edu.tr>
*/
#include "Node.hpp"

Node::Node(int data) //bos
{
    this->data = data;
    this->next = NULL;
    this->prev = NULL;
}
Node::Node(int data, Node *next, Node *prev) // veri next prev
{
    this->data = data;
    this->next = next;
    this->prev = prev;
}