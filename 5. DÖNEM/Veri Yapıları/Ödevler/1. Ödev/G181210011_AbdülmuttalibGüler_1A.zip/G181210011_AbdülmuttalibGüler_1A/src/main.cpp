/**
*  @file main.cpp
*  @description main foksiyonunun buldundugu ve dosya okuma burada gerceklesir 
*  @course 1. öğretim A grubu
*  @assignment 1.Odev
*  @date 28.11.2020
*  @author Abdülmuttalib Güler (G181210011) <abdulmuttalib.guler@ogr.sakarya.edu.tr>
*/
#include "CDLL.hpp"
#include <algorithm>

int count_underscores(string s, char serach)
{
    int count = 0;
    for (int i = 0; i < s.size(); i++)
        if (s[i] == serach)
            count++;
    return count;
}
int main()
{

    ifstream infile("Sayilar.txt");

    string line = "";

    CDLL **listArray; // Satır Sayısı kadar Elemanı okacak list dizisi pointeri

    int lineCount;
    // dosyada kac satır oldugunu anliyoruz
    lineCount = count(istreambuf_iterator<char>(infile), istreambuf_iterator<char>(), '\n') + 1;

    infile.close();

    ifstream file("Sayilar.txt"); //Sayilar.txt
    listArray = new CDLL *[lineCount];
    int i = 0;
    int bigMid = 0, smallMid = 10000000, bigIndex = 0, smallIndex = 0; // en buyuk listeleri tutmak için 
    while (getline(file, line))
    {
        listArray[i] = new CDLL();
        string key = "";
        stringstream ss(line);
        int *lineArray;
        int numCount = count_underscores(line, ' ') + 1;
        lineArray = new int[numCount];
        int a = 0;
        while (getline(ss, key, ' '))
        {
            lineArray[a] = stoi(key);
            a++;
        }
        listArray[i]->addArray(lineArray, numCount);

        Node *mp = listArray[i]->getMidPoint();

        if (bigMid < mp->data)
        {
            bigMid = mp->data;
            bigIndex = i;
        }
        if (smallMid > mp->data)
        {
            smallMid = mp->data;
            smallIndex = i;
        }

        i++;
    }
    file.close();
    listArray[bigIndex]->Caprazla(listArray[smallIndex]);
    delete[] listArray;
    return 0;
}
