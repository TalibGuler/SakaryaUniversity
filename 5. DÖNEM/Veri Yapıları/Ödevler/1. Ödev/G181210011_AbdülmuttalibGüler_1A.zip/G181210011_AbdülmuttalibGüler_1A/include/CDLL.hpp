/**
*  @file CDLL.hpp
*  @description CircularDoublyLinkedList icin bir header dosyası
*  @course 1. öğretim A grubu
*  @assignment 1.Odev
*  @date 28.11.2020
*  @author Abdülmuttalib Güler (G181210011) <abdulmuttalib.guler@ogr.sakarya.edu.tr>
*/
#ifndef CDLL_HPP
#define CDLL_HPP

#include "Node.hpp"

class CDLL
{
private:
    int arraySize;
    int count;
    Node *point;

public:
    CDLL();            // Kurucu
    bool isEmpty();    // liste dolu bos kontrolu
    bool isRange(int); // index kontrolu
    int Count();       // listedeki eleman sayisi
    // void remove(int);      // Listeden cıkarma
    void removeAt(int); // listeden o indisdeki değeri çıkarma
    void drawList();    // Listeyi ekrana yazdırma

    //Alogirtma Fonksiyonları

    void insertRight(int);     // sagina ekleme
    void insertLeft(int);      //soluna ekleme
    void addArray(int *, int); // dizi ekleme
    Node *getMidPoint();

    void Caprazla(CDLL *); // Caprazlama fonksiyonu parametre gelen Liste ile caprazlama yapıyor
    //----------------------
    void clear(); //temizleme
    ~CDLL();      //Yıkıcı
};

#endif