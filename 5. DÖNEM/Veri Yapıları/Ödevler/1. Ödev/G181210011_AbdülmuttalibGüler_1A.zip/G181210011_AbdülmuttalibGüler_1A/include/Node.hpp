/**
*  @file Node.hpp
*  @description Dugum sınıfı icin bir header dosyası
*  @course 1. öğretim A grubu
*  @assignment 1.Odev
*  @date 28.11.2020
*  @author Abdülmuttalib Güler (G181210011) <abdulmuttalib.guler@ogr.sakarya.edu.tr>
*/
#ifndef NODE_HPP
#define NODE_HPP
//includes burda yapıyoruz çünkü alt sınıflarda zaten geçerli oluyor
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

class Node
{
public:
    int data;                  //veri
    Node *next;                //Sonraki Dugum
    Node *prev;                //Onceki Dugum
    Node();                    //Bos Kurucu
    Node(int);                 // sadece veri olan kurucu
    Node(int, Node *, Node *); //Kurucu
};
#endif