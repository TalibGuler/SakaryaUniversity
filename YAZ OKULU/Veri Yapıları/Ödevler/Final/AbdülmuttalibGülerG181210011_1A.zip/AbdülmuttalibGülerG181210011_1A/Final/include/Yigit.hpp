/**
* @file Yigit
* @description 
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef YIGIT_HPP
#define YIGIT_HPP

class Yigit {
public:
	char* harf;
	int bas;
	int kapasite;
	int uzunluk;

	bool DoluMu();

	void Dondur(int);

	Yigit();

	bool BosMu();

	void Atmak(char);
	void Cikar();

	char IlkDeger();

	void Temizle();

	~Yigit();

};

#endif
