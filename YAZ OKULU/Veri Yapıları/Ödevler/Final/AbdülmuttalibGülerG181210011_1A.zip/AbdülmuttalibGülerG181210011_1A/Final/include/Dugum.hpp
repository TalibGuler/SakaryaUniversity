/**
* @file Dugum
* @description saga sola ekleme
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef DUGUM_HPP
#define DUGUM_HPP
struct Dugum {
public:
	int yas;
	Dugum* sol;
	Dugum* sag;
	int yukseklik;

	Kisi* insan = new Kisi();

	Dugum(int, Dugum* , Dugum* , int);
};
#endif
