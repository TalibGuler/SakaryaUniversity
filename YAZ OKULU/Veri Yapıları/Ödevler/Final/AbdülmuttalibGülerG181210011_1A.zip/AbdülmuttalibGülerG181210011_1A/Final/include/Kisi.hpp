/**
* @file Kisi
* @description kisi �zelliklerini bar�nd�r�yor
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef KISI_HPP
#define KISI_HPP
#include <string>

class Kisi {
public:
	string isim;
	int yas, kilo;

	Kisi(string, int , int);
};

#endif
