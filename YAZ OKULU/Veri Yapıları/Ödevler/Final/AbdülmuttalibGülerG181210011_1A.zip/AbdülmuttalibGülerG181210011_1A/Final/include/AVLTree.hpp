/**
* @file AVLTree
* @description avl a�ac�m buras� s�ralama i�in
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#ifndef AVLTREE_HPP
#define AVLTREE_HPP
#include "Dugum.hpp"
#include "Kisi.hpp"

class AVLTree {
public:
	Dugum* kok;

	Dugum* AraVeEkle(Dugum* , int);

	Dugum* SolCocukIleDegistir(Dugum*);

	Dugum* SagCocukIleDegistir(Dugum*);

	int Yukseklik(Dugum*);

	void Postorder(Dugum*);


};

#endif
