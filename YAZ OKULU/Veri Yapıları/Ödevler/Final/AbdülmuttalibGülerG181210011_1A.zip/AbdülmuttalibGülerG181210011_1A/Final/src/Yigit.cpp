/**
* @file Yigit
* @description 
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#include "Yigit.hpp"
Yigit::Yigit {

	bool DoluMu() {
		return kapasite == uzunluk;
	}

	void Dondur(int kapasite) {
		char* item = new char[kapasite];
		
		int i;
		for (i = 0; i < uzunluk; i++) {
			item[i] = harf[i];
		}
		if (harf != NULL) {
			delete[] harf;
		}
		harf = item;
		this->kapasite = kapasite;
	}

	Yigit() {
		harf = NULL;
		bas = -1;
		uzunluk = 0;
		kapasite = 0;
	}

	bool BosMu() {
		return bas == -1;
	}

	void Atmak(char hrf) {
		if (DoluMu()) {
			Dondur(max(1, 2 * kapasite));
		}
		bas++;
		harf[bas] = hrf;
		uzunluk++;
	}

	void Cikar() {
		if (BosMu()) {
			return;
		}
		bas--;
		uzunluk--;
	}

	char IlkDeger() {
		if (BosMu()) {
			return NULL;
		}
		return harf[bas];
	}

	void Temizle() {
		bas = -1;
		uzunluk = 0;
	}

	~Yigit() {
		if (harf != NULL) {
			delete[] harf;
		}
		harf = NULL;
	}

};
