/**
* @file Kisi
* @description kisi �zelliklerini bar�nd�r�yor
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#include "Kisi.hpp"
Kisi::Kisi(string isim = "", int yas = 0, int kilo = 0) {
		this->isim = isim;
		this->kilo = kilo;
		this->yas = yas;
	}
