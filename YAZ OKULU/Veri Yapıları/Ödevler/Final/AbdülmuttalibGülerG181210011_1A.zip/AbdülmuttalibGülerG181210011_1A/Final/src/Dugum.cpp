/**
* @file Dugum
* @description saga sola ekleme
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#include "Dugum.hpp"
#include "Kisi.hpp"

Dugum::Dugum(int yas=0, Dugum* sag = NULL, Dugum* sol = NULL, int yukseklik = 0) {
		this->yas = yas;
		this->sag = sag;
		this->sol = sol;
		this->yukseklik = yukseklik;
	}
