/**
* @file AVLTree
* @description avl a�ac�m buras� s�ralama i�in
* @course 1.��retim A Grubu
* @assignment 2.�dev
* @date 2/09/2020
* @author Abd�lmuttalib G�LER
*/
#include "AVLTree.hpp"
#include "Kisi.hpp"

Dugum* AVLTree::AraVeEkle(Dugum* AltDugum, int yeniyas) {

		if (AltDugum == NULL)
			AltDugum = new Dugum(yeniyas); //E�er k�k bo� ise yeni k�k olarak eklenecek.

		else if (yeniyas < AltDugum->yas) { //Eklenenin ya�� k���kse sola ekler.
			AltDugum->sol = AraVeEkle(AltDugum->sol, yeniyas); //Sol alt �ocuk yerine yeni bir a�a� olu�turur.

			if (Yukseklik(AltDugum->sol) - Yukseklik(AltDugum->sag) == 2) { //Y�kseklik fark� birden fazlaysa a�ac� dengeler.
				if (yeniyas < AltDugum->sol->yas)
					AltDugum = SolCocukIleDegistir(AltDugum);
				else {
					AltDugum->sol = SagCocukIleDegistir(AltDugum->sol);
					AltDugum = SolCocukIleDegistir(AltDugum);
				}
			}
		}

		else if (yeniyas > AltDugum->yas) { //Eklenenin ya�� b�y�kse sa�a ekler.
			AltDugum->sag = AraVeEkle(AltDugum->sag, yeniyas);

			if (Yukseklik(AltDugum->sag) - Yukseklik(AltDugum->sol) == 2) {
				if (yeniyas > AltDugum->sag->yas)
					AltDugum = SagCocukIleDegistir(AltDugum);
				else {
					AltDugum->sag = SolCocukIleDegistir(AltDugum->sag);
					AltDugum = SagCocukIleDegistir(AltDugum);
				}
			}
		}
	}

Dugum* AVLTree::SolCocukIleDegistir(Dugum* AltDugum) {
		Dugum* tmp = AltDugum->sol;
		AltDugum->sol = tmp->sag;
		tmp->sag = AltDugum;

		AltDugum->yukseklik = Yukseklik(AltDugum);
		tmp->yukseklik = max(Yukseklik(tmp->sol), AltDugum->yukseklik) + 1;

		return tmp;
	}

Dugum* AVLTree::SagCocukIleDegistir(Dugum* AltDugum) {
		Dugum* tmp = AltDugum->sag;
		AltDugum->sag = tmp->sol;
		tmp->sol = AltDugum;

		AltDugum->yukseklik = Yukseklik(AltDugum);
		tmp->yukseklik = max(Yukseklik(tmp->sag), AltDugum->yukseklik) + 1;

		return tmp;
	}

int AVLTree::Yukseklik(Dugum* AltDugum) {
		if (AltDugum == NULL)
			return -1; // Ortada d���m yoksa y�kseklik anlams�zd�r. Kodun �al��mas� ad�na -1 verilmektedir.
		return 1 + max(Yukseklik(AltDugum->sol), Yukseklik(AltDugum->sag));
	}

void AVLTree::Postorder(Dugum* AltDugum) {
		if (AltDugum != NULL) {
			Postorder(AltDugum->sol);//SOL
			Postorder(AltDugum->sag);//SA�
			cout << AltDugum->yas << " ";//K�K
		}
	}


};
