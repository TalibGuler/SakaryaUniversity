#ifndef ARRAYLIST_HPP
#define ARRAYLIST_HPP

#include "ElemanYok.hpp"
#include "ListeBos.hpp"
#include "Tasma.hpp"

template <typename Object>
class ArrayList{
	private:
		Object* items;
		int length;
		int capacity;
		
		void Reserve(int newCapacity){
			if(capacity>=newCapacity) return;
			Object* temp = new Object[newCapacity];//ders sırasında köşeli yerine parantez koymuşum düzelttim
			for(int i=0;i<length;i++)
				temp[i]=items[i];
			if(items!=NULL)
				delete[] items;
			items=temp;
			capacity=newCapacity;
		}
	public:
		ArrayList(){
			length=0;
			capacity=0;
			items=NULL;
		}
		int Size() const{
			return length;
		}
		bool IsEmpty() const{
			return Size()==0;
		}
		int IndexOf(const Object& item) const throw(){
			for(int i=0;i<length;i++){
				if(items[i]==item) return i;
			}
			throw ElemanYok("item bulunamadı");
		}
		const Object& ElementAt(int i) const throw()
		{
			if(i<0 || i>length) throw ElemanYok("item bulunamadı");
			return items[i];
		}
		void Remove(const Object& item)//ders sırasında gereksiz throw kullanmışım kaldırdım
		{
			RemoveAt(IndexOf(item));
			return;
		}
		void RemoveAt(int i) throw(){
			if(i<0 || i>length) throw ElemanYok("item bulunamadı");
			for(int j=i+1;j<length;j++)
				items[j-1]=items[j];
			length--;
		}
		void Add(const Object& yeni){//ders sırasında gereksiz throw kullanmışım kaldırdım
			Insert(length,yeni);
		}
		void Insert(int i, const Object& yeni) throw(){
			if(i<0 || i>length) throw Tasma("item bulunamadı");
			if(length >= capacity)
				Reserve(max(1,2*capacity));
			for(int j=length-1;j>=i;j--)
				items[j+1]=items[j];
			items[i]=yeni;
			length++;
		}
		const Object& First() const throw(){
			if(length==0) throw ListeBos("ListeBos");
			return items[0];
		}
		const Object& Last() const throw(){
			if(length==0) throw ListeBos("ListeBos");
			return items[length-1];
		}
		void Clear(){
			length=0;
		}
		friend ostream& operator<<(ostream& screen, ArrayList<Object>& right){
			screen<<endl;
			for(int i=0;i<right.length;i++){
				screen<<right.items[i];
				if(i+1!=right.length)
					screen<<" || ";
			}
			return screen;
		}
		~ArrayList(){
			if(items != NULL) delete[] items;
		}
};
#endif