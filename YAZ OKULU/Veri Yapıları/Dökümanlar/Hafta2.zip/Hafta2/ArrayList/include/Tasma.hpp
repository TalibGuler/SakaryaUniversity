#ifndef TASMA_HPP
#define TASMA_HPP

#include "Hata.hpp"

class Tasma: public Hata{//ders sırasında private yapıp unutmuşum tekrar public yaptım
	public:
		Tasma(const string& msg):Hata(msg){}
};

#endif