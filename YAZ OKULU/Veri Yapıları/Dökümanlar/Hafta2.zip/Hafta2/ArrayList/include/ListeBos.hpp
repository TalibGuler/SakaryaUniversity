#ifndef LISTEBOS_HPP
#define LISTEBOS_HPP

#include "Hata.hpp"

class ListeBos: public Hata{//ders sırasında private yapıp unutmuşum tekrar public yaptım
	public:
		ListeBos(const string& msg):Hata(msg){}
};

#endif