#include<iostream>
#include <ctime>
using namespace std;

class Kisi{
	private:
		string isim;
	public:
		Kisi(string ism){
			isim = ism;
		}
		friend ostream& operator<<(ostream& ekran, Kisi& k){
			ekran<<k.isim<<endl;
			return ekran;
		}
};

void Yazdir(Kisi** kisiler, int kisiSayisi){
	for(int i=0;i<kisiSayisi;i++){
		cout<<*kisiler[i];
	}
}
void Yoket(Kisi** kisiler, int kisiSayisi){
	for(int i=0;i<kisiSayisi;i++){
		delete kisiler[i];
	}
}
int main(){
	Kisi** kisiler = new Kisi*[3];
	kisiler[0] = new Kisi("ahmet");
	kisiler[1] = new Kisi("mehmet");
	kisiler[2] = new Kisi("ayse");
	Yazdir(kisiler, 3);
	Yoket(kisiler, 3);
	delete[] kisiler;
	return 0;
}