#include<iostream>
#include "Ogrenci.hpp"
#include "Sebze.hpp"
#include "Meyve.hpp"

using namespace std;
int main(){
	Ogrenci o1(19,175,52);
	cout<<o1;
	Sebze fasulye(1200);
	Meyve muz(800);
	o1.YemekYe(fasulye);
	o1.YemekYe(muz);
	cout<<"----------"<<endl;
	cout<<o1;
	return 0;
}