#include "Meyve.hpp"
#include <iostream>
using namespace std;

Meyve::Meyve(double kl){
	kalori=kl;
}
double Meyve::getKalori()const{
	return kalori;
}