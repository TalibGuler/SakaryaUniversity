#ifndef SEBZE_HPP
#define SEBZE_HPP

class Sebze{
	private:
		double kalori;
	public:
		Sebze(double);
		double getKalori()const;
};

#endif