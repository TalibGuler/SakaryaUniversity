#ifndef MEYVE_HPP
#define MEYVE_HPP

class Meyve{
	private:
		double kalori;
	public:
		Meyve(double);
		double getKalori()const;
};
#endif