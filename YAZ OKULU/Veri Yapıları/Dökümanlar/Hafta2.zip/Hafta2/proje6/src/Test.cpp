#include<iostream>
using namespace std;


int FaktoriyelIteratif(int n){//n! hesaplanır 1*2 2*3 6*4 24*5 = 120 iteratif yaklaşım
	int sonuc=1;
	for(int i=2;i<=n;i++)
		sonuc*=i;
	return sonuc;
}

int Faktoriyel(int n){//5!=5*4!, 4!=4*3! rekürsif yaklaşım
	if(n<=1) return 1;
	return n*Faktoriyel(n-1);
}

int FibonacciIteratif(int n){
	int once=0;
	int simdi=1;
	if(n==0) return 0;
	if(n==1) return 1;
	for(int i=2;i<=n;i++){
		int simdi_yeni= once+simdi;
		once=simdi;
		simdi=simdi_yeni;
	}
	return simdi;
}

int Fibonacci(int n){
	if(n==0) return 0;
	if(n==1) return 1;
	return Fibonacci(n-1)+Fibonacci(n-2);
}

bool IkiliArama(int sayilar[], int baslangic, int bitis, int aranan){//rekürsif
	int ortaindis = (baslangic+bitis)/2;
	if(bitis < baslangic) return false;
	if(sayilar[ortaindis]==aranan) return true;
	if(aranan<sayilar[ortaindis])
		return IkiliArama(sayilar, baslangic, ortaindis-1, aranan);
	if(aranan>sayilar[ortaindis])
		return IkiliArama(sayilar, ortaindis+1, bitis, aranan);
}

int main(){
	// int sayi;
	// cout<<"sayi:";
	// cin>>sayi;
	//cout<<sayi<<"!="<<Faktoriyel(sayi)<<endl;
	//cout<<sayi<<"!="<<FaktoriyelIteratif(sayi)<<endl;
	//cout<<"Fib("<<sayi<<"):"<<FibonacciIteratif(sayi)<<endl;
	//cout<<"Fib("<<sayi<<"):"<<Fibonacci(sayi)<<endl;
	
	
	int dizi[]={5, 26, 33, 47, 51, 58, 63, 69, 75, 88, 94, 101};
	int aranan;
	cout<<"aranan:";
	cin>>aranan;
	if(IkiliArama(dizi,0,11,aranan))
		cout<<"Sayi var";
	else
		cout<<"Sayi yok";
	return 0;
}