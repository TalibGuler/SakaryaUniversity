#include<iostream>

using namespace std;


int* DiziOlustur(int uzunluk){
	int* sayilar = new int[uzunluk];
	for(int i=0;i<uzunluk;i++)
		sayilar[i]=i*2;
	return sayilar;
}
int main(){
	// int sayilar[] = {2,8,16};//A+i*c
	// cout<<sizeof(int)<<endl;
	// cout<<sayilar<<endl;
	// cout<<sayilar+1<<endl;
	// cout<<sayilar+2<<endl;
	// int uzunluk;
	// cout<<"uzunluk:";
	// cin>>uzunluk;
	// int sayilar[uzunluk];
	// for(int i=0;i<uzunluk;i++){
		// sayilar[i]=i;
	// }
	// int* p = sayilar;
	// cout<<sayilar<<endl;//ilk elemanın adresi + (bulmak istediğimiz elemanın indisi * dizi türünün bellekte kapladığı alan)
	// cout<<sayilar+2;
	int uzunluk;
	cout<<"uzunluk:";
	cin>>uzunluk;
	int* p=DiziOlustur(uzunluk);
	cout<<p[1];
	delete p;
	return 0;
}