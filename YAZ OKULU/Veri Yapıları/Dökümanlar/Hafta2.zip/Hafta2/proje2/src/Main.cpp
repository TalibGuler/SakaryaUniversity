#include<iostream>

using namespace std;

class Sayi{
	private:
		int* pdeger;
	public:
		Sayi(int dgr){
			pdeger= new int(dgr);
		}
		Sayi(){
			pdeger=new int(0);
		}
		friend ostream& operator<<(ostream& ekran, Sayi& sag){
			ekran<<*sag.pdeger<<endl;
			return ekran;
		}
		~Sayi(){
			delete pdeger;
			cout<<"girdi"<<endl;
		}
};

class Kisi{
	private:
		string isim;
	public:
		Sayi* yas;
		Kisi(string isim, int ys){
			this->isim=isim;
			yas=new Sayi(ys);
		}
		~Kisi(){
			delete yas;
			cout<<"girdi"<<endl;
		}
		friend ostream& operator<<(ostream& ekran, Kisi& sag){
			ekran<<sag.isim<<" "<<*sag.yas<<endl;
			return ekran;
		}
};

int main(){
	Kisi* ahmet = new Kisi("Ahmet", 35);
	Kisi* mehmet = new Kisi("Mehmet", 55);
	cout<<*ahmet;
	cout<<*mehmet;
	Kisi* yedekKisi = ahmet;
	ahmet = mehmet;
	mehmet = yedekKisi;
	cout<<*ahmet;
	cout<<*mehmet;
	delete ahmet;
	delete mehmet;
	return 0;
}