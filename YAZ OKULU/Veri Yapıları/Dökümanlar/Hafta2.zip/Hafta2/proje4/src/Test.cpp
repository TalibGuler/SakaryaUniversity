#include<iostream>
#include <ctime>
using namespace std;

// class Kisi{
	// private:
		// int yas;
	// public:
		// string isim;
		// Kisi(string ism){
			// isim=ism;
			// yas=0;
		// }
// };

// int Uzunluk(char* str){
	// int u=0;
	// for(int i=0;str[i] != '\0';i++)
		// u++;
	// return u;
// }

// bool EsitMi(int d1[], int d2[], int u1, int u2){
	// if(u1!=u2) return false;
	// for(int i=0;i<u1;i++){
		// if(d1[i]!=d2[i]) return false;
	// }
	// return true;
// }
const int sutun=3;

void Yazdir(int dizi[][sutun], int satir){
	for(int i=0;i<satir;i++){
		for(int j=0;j<sutun;j++){
			cout<<dizi[i][j]<<" ";
		}
		cout<<endl;
	}
}

int main(){
	srand(time(NULL)*time(NULL));
	// Kisi** kisiler = new Kisi*[10];
	// for(int i=0;i<10;i++)
		// kisiler[i] = new Kisi("Mehmet");
	
	// cout<<kisiler[5]->isim;
	
	// for(int i=0;i<10;i++)
		// delete kisiler[i];
	// char* str = "veri yapilari";
	// cout<<str;
	// int a[]={3,5,7};
	// int b[3];
	// for(int i=0;i<3;i++){
		// b[i]=a[i];
	// }
	// if(a==b)
		// cout<<"diziler esit";
	// else
		// cout<<"diziler esit degil";
	// if(EsitMi(a,b,3,3))
		// cout<<"diziler esit";
	// else
		// cout<<"diziler esit degil";
	
	int sayilar[3][sutun];
	for(int i=0;i<3;i++)
		for(int j=0;j<sutun;j++)
			sayilar[i][j] = rand()%9+1;
	Yazdir(sayilar,3);
	return 0;
}