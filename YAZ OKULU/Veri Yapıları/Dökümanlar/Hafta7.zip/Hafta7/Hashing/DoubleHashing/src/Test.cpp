#include "DoubleHashing.hpp"

int main(){
	int dizi[] = {76,93,40,47,10,55};
	DoubleHashing *tablo = new DoubleHashing();
	for(int i=0;i<6;i++)
		tablo->Ekle(dizi[i]);
	tablo->Yaz();
	delete tablo;
}