#ifndef BST_HPP
#define BST_HPP

#include<cmath>
#include<iostream>

#define SIZE 10000

using namespace std;

template <typename Nesne>
class BST{
	private:
		Nesne* elemanlar;
		int IndeksDolulugu[SIZE];
		int Ara(const Nesne& eleman, int suankiIndeks=0){
			while(true){
				if(suankiIndeks == SIZE || IndeksDolulugu[suankiIndeks] == 0)
					return -1;//Eleman yok
				if(elemanlar[suankiIndeks] == eleman && IndeksDolulugu[suankiIndeks] == 1){
					return suankiIndeks;
				}
				else if (eleman < elemanlar[suankiIndeks])//ders sırasında if'in sonuna ==1 eklemişim çalışmamış
					suankiIndeks = 2 * suankiIndeks + 1;
				else if (eleman > elemanlar[suankiIndeks])
					suankiIndeks = 2 * suankiIndeks + 2;
			}
		}
		bool ikininKuvvetimi(int x){//ikinin kuvveti mi 2, 4, 8, 16, 32, 64?
			while(((x%2)==0) && x > 1)
				x/=2;
			return (x == 1);
		}
		int EnKucukDeger(int i = 0){
			if(2 * i + 1>SIZE)
				return i;
			else if (IndeksDolulugu[2 * i + 1] == 0)
				return i;
			else 
				return EnKucukDeger(2 * i + 1);//derste i yerine 1 koymuşum
		}
	public: 
		BST(){
			elemanlar = new Nesne[SIZE];
			Temizle();
		}
		bool Varmi(const Nesne& eleman){
			if (Ara(eleman == -1))
				return false;
			return true;
		}
		int Yukseklik(int indeks = 0){
			if(IndeksDolulugu[indeks] == 0)
				return -1;
			return 1 + max(Yukseklik(2*indeks+1), Yukseklik(2*indeks +2));
		}
		void Temizle(){
			for(int i = 0; i < SIZE; i++)
				IndeksDolulugu[i] = 0; 
		}
		void Ekle(const Nesne& eleman){
			int suankiIndeks = 0;
			while(true){
				if(IndeksDolulugu[suankiIndeks]==0){
					elemanlar[suankiIndeks] = eleman;
					IndeksDolulugu[suankiIndeks] = 1;
					break;
				}
				else if (eleman < elemanlar[suankiIndeks])
					suankiIndeks = 2 * suankiIndeks + 1;
				else if (eleman > elemanlar[suankiIndeks])
					suankiIndeks = 2 * suankiIndeks + 2;
				else
					return;//Aynı elemandan zaten var eklemeden return et
			}
		}
		void Sil(const Nesne& eleman, int ind=0){
			int i = Ara(eleman, ind);//i silinecek elemanın indisine eşitleniyor
			if (i == -1)//silinecek eleman yoksa çık
				return;
			else{
				IndeksDolulugu[i] = 0;//silinecek elemanın doluluğu 0 yapılıyor ayrıca hiç çocuğu yoksa bu adımdan sonra fonksiyon sonlanır. Ek bir adıma gerek kalmaz.
				if(IndeksDolulugu[2 * i + 2] == 0){//sağ çocuk yoksa
					if(IndeksDolulugu[2 * i + 1] == 1){//ve sol çocuk varsa
						int k = 2*i+1;
						int yedek[SIZE];
						for(int iter = 0; iter < SIZE; iter++)
							yedek[iter] = 0;
						yedek[0] = k;
						int index = 0;
						
						//BFS algoritması kullanılarak sol alt ağaçtaki tüm düğümler silinen düğümün yerine getiriliyor.
						for(int iter=0;iter<SIZE && yedek[iter] != 0; iter++){
							for(int x = 0; x = SIZE; x++){
								if(ikininKuvvetimi(yedek[iter]+1 - x)){
									elemanlar[(yedek[iter]+x-1)/2] = elemanlar[yedek[iter]];
									IndeksDolulugu[(yedek[iter]+x-1)/2] = 1;
									IndeksDolulugu[yedek[iter]] = 0;
									break;
								}
							}
							if(IndeksDolulugu[2*yedek[iter]+1]!=0){
								yedek[++index] = 2*yedek[iter]+1;
							}
							if(IndeksDolulugu[2*yedek[iter]+2]!=0){
								yedek[++index] = 2*yedek[iter]+2;
							}
						}
					}
				}
				else{
					if(IndeksDolulugu[2*i+1]==0)//sadece sağ çocuğu varsa
					{
						int k=2*i+2;//sağ çocuğun indisi k'ya eşitlenir
						int yedek[SIZE];
						for(int iter=0;iter<SIZE;iter++)
							yedek[iter]=0;
						yedek[0]=k;//dizinin ilk elemanı sağ çocuğun indisi yapılır
						int index = 0;
						//BFS
						for(int iter=0;iter<SIZE && yedek[iter] != 0; iter++){//yedek dizide yani taşınacak alt ağaçta düğüm olduğu müddetçe çalışır
							for(int x = 0; x = SIZE; x++){
								if(ikininKuvvetimi((yedek[iter]+x)/2+1)){//
									elemanlar[(yedek[iter]-2-x)/2] = elemanlar[yedek[iter]];//asıl asıl silineceğin yerine sağ çocuğu geliyor
									IndeksDolulugu[(yedek[iter]-2-x)/2] = 1;//indis doluluğu yeri sağ çocukla doldurulduğu için tekrar 1 yapılıyor
									break;
								}
							}
							IndeksDolulugu[yedek[iter]] = 0;//sağ çocuk babasının yerine geçtiği için indis doluluğu sıfır yapılıyor
							if(IndeksDolulugu[2*yedek[iter]+1]!=0){//eğer silinen çocuğun sol çocuğu varsa yedek dizisine indisini ekliyor böylece alt ağaç taşınmış olacak
								yedek[++index] = 2*yedek[iter]+1;
							}
							if(IndeksDolulugu[2*yedek[iter]+2]!=0){//eğer silinen çocuğun sağ çocuğu varsa yedek dizisine indisini ekliyor böylece alt ağaç taşınmış olacak
								yedek[++index] = 2*yedek[iter]+2;
							}
						}
					}
					else{//iki çocuk varsa
						int x = EnKucukDeger(2*i+2);//sağ çocuğun en solununun indisi x'e atanıyor
						Nesne kopyalanacak = elemanlar[x];//üstteki indiste bulunan eleman değişkene atanıyor
						IndeksDolulugu[i]=IndeksDolulugu[x];//silinecek elemanın indisinin doluluğu yerine geçen elemanın indis doluluğu değeriyle yani 1'le değiştiriliyor
						elemanlar[i]=elemanlar[x];//silinecek elemanın indisine yeni seçtiğimiz eleman atanıyor
						Sil(kopyalanacak, x);//silmek istediğimiz düğümün yerine kopyaladığımız düğüme artık gerek kalmadığı için Sil metoduna gönderiyoruz ve başlangıç indisimiz bu gerek kalmayan düğümün indisi olarak belirleniyor
					}
				}
			}
		}
		void Inorder(int suankiIndeks=0){
			if(suankiIndeks < SIZE && IndeksDolulugu[suankiIndeks] != 0){
				Inorder(2*suankiIndeks + 1);//SOL
				cout<<elemanlar[suankiIndeks]<<" ";//KÖK
				Inorder(2*suankiIndeks + 2);//SAĞ
			}
		}
		void Preorder(int suankiIndeks=0){
			if(suankiIndeks < SIZE && IndeksDolulugu[suankiIndeks] != 0){
				cout<<elemanlar[suankiIndeks]<<" ";//KÖK
				Preorder(2*suankiIndeks + 1);//SOL
				Preorder(2*suankiIndeks + 2);//SAĞ
			}
		}
		void Postorder(int suankiIndeks=0){
			if(suankiIndeks < SIZE && IndeksDolulugu[suankiIndeks] != 0){
				Postorder(2*suankiIndeks + 1);//SOL
				Postorder(2*suankiIndeks + 2);//SAĞ
				cout<<elemanlar[suankiIndeks]<<" ";//KÖK
			}
		}
		void Levelorder(){
			for(int i = 0; i < SIZE; i++){
				if(IndeksDolulugu[i]==1){
					cout<<elemanlar[i] << " ";
				}
			}
		}
		~BST(){
			delete[] elemanlar;
		}
};
#endif