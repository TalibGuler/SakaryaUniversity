#ifndef OGRENCI_HPP
#define OGRENCI_HPP
#include <iostream>
#include "Sebze.hpp"
#include "Meyve.hpp"
using namespace std;

class Ogrenci{
	private:
		int yas;
		double boy;
		double kilo;
	public:
		Ogrenci(int ys, double by, double kl){
			yas=ys;
			boy=by;
			kilo=kl;
		}
		void YasIlerle(int ys){
			yas+=ys;
		}
		void BoyUza(double by){
			boy+=by;
		}
		template <typename YIYECEK>
		void YemekYe(YIYECEK yemek){
			kilo+=yemek.getKalori()/1000;
		}
		int getYas(){
			return yas;
		}
		double getBoy(){
			return boy;
		}
		double getKilo(){
			return kilo;
		}
		~Ogrenci(){
			cout<<"cagrildi"<<endl;
		}
		friend ostream& operator<<(ostream& ekran, Ogrenci& sag){
			ekran<<"Ogrenci o:"<<endl;
			ekran<<"Yas: "<<sag.getYas()<<endl;
			ekran<<"Boy: "<<sag.getBoy()<<endl;
			ekran<<"Kilo: "<<sag.getKilo()<<endl;
		return ekran;
		}
};

#endif