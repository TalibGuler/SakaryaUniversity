#include "Sebze.hpp"
#include <iostream>
using namespace std;

Sebze::Sebze(double kl){
	kalori=kl;
}
double Sebze::getKalori()const{
	return kalori;
}