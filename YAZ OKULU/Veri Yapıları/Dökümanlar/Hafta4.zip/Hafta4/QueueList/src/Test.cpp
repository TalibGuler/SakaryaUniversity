#include "Queue.hpp"
#include <iostream>
using namespace std;

int main(){
	Queue<int>* kuyruk = new Queue<int>();
	kuyruk->enqueue(15); //35,45
	kuyruk->enqueue(25);
	kuyruk->enqueue(35);
	kuyruk->enqueue(45);
	kuyruk->dequeue();
	kuyruk->dequeue();
	cout<<kuyruk->peek()<<endl<<endl;
	delete kuyruk;
	return 0;
}