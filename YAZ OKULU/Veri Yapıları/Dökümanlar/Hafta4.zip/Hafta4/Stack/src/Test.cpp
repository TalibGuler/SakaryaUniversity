#include "Stack.hpp"

int main(){
	Stack<string>* s1 = new Stack<string>();
	s1->Push("ali");
	s1->Push("ahmet");
	s1->Push("ayse");
	s1->Pop();
	s1->Pop();
	cout<<s1->Top();
	return 0;
}