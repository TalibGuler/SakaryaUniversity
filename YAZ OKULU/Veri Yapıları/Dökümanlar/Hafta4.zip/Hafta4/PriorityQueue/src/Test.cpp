#include "Queue.hpp"
#include <iostream>
using namespace std;

int main(){
	Queue<int>* kuyruk = new Queue<int>();
	kuyruk->enqueue(724);
	kuyruk->enqueue(1225);
	kuyruk->enqueue(531);
	kuyruk->enqueue(850);
	//kuyruk->dequeueMax();
	cout<<kuyruk->peek()<<endl<<endl;//724
	cout<<kuyruk->peekMax()<<endl<<endl;//1225
	delete kuyruk;
	return 0;
}