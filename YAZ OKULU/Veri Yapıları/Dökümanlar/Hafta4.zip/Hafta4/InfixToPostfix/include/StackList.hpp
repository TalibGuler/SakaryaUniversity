#ifndef STACKLIST_HPP
#define STACKLIST_HPP
#include <iostream>
using namespace std;

template <typename Object>
class Node{
	public:
		Object data;
		Node<Object>* next;
		Node(const Object& data, Node* next = NULL){
			this->data=data;
			this->next=next;
		}
};

template <typename Object>
class Stack{
	private:
		Node<Object>* head;
	public:
		Stack(){
			head=NULL;
		}
		bool IsEmpty() const{
			return head == NULL;
		}
		void Push(const Object& obj){
			head = new Node<Object>(obj, head);
		}
		void Pop(){
			if(IsEmpty())
				return;
			Node<Object>* tmp = head;
			head=head->next;
			delete tmp;
		}
		const Object& Top() const{
			if(IsEmpty())
				return NULL;
			return head->data;
		}
		void Clear(){
			while(!IsEmpty())
				Pop();
		}
		~Stack(){
			Clear();
		}
};
#endif