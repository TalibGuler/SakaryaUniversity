#include "Postfix.hpp"
bool Postfix::OncelikDusukmu(char op1, char op2){
	if(op1=='(')
		return false;
	else if(op2 == '(')
		return false;
	else if(op2 == ')')
		return true;
	else if(op1 == '*' || op1 == '/')
		return true;
	else if(op2 == '*' || op2 == '/')
		return false;
	else 
		return true;
}
void Postfix::PostfixAktar(Stack<char>* yigit, string& postfix){
	postfix += yigit->Top();
	postfix += " ";
	yigit->Pop();
}
string Postfix::infixToPostfix(string infix){
	int uzunluk = infix.length();
	Stack<char>* stack = new Stack<char>();
	string postfix = "";
	for(int i=0;i<uzunluk;i++){
		if(isdigit(infix[i])){
			while(isdigit(infix[i])){
				postfix += infix[i];
				i++;
			}
			postfix += " ";
			i--;
		}
		else if(infix[i] == '('){
			stack->Push(infix[i]);
		}
		else if(infix[i] == '*' ||infix[i] == '+' || infix[i] == '-' || infix[i] == '/'){
			while(!stack->IsEmpty() && stack->Top()!= '('){
				if(OncelikDusukmu(stack->Top(),infix[i])){
					PostfixAktar(stack, postfix);
				}
				else{
					break;
				}
			}
			stack->Push(infix[i]);
		}
		else if(infix[i]==')'){
			while(!stack->IsEmpty() && stack->Top()!='('){
				PostfixAktar(stack, postfix);
			}
			if(!stack->IsEmpty())
				stack->Pop();
		}
	}
	while(!stack->IsEmpty()){
		PostfixAktar(stack, postfix);
	}
	delete stack;
	return postfix;
}
Postfix::Postfix(string infix){
	ifade=infixToPostfix(infix);
}
double Postfix::Hesapla(){
	double sonuc;
	int uzunluk = ifade.length();
	Stack<double>* stack = new Stack<double>();
	for(int i=0;i<uzunluk;i++){
		if(isspace(ifade[i]))
			continue;
		if(isdigit(ifade[i])){
			string sayi = "";
			while(isdigit(ifade[i])){
				sayi+=ifade[i];
				i++;
			}
			double s;
			s = atof(sayi.c_str());
			stack->Push(s);
			i--;
			continue;
		}
		else{
			double sayi2 = stack->Top();
			stack->Pop();
			double sayi1 = stack->Top();
			stack->Pop();
			switch(ifade[i]){
				case'+':
					stack->Push(sayi1+sayi2);
					break;
				case'-':
					stack->Push(sayi1-sayi2);
					break;
				case'*':
					stack->Push(sayi1*sayi2);
					break;
				case'/':
					stack->Push(sayi1/sayi2);
					break;
			}
		}
	}
	if(!stack->IsEmpty()){
		sonuc=stack->Top();
		stack->Pop();
	}
	delete stack;
	return sonuc;
}
string Postfix::postfix() const{
	return ifade;
}
ostream& operator<<(ostream& ekran, Postfix& sag){
	ekran<<sag.ifade<<endl;
	return ekran;
}