#include "Sayi.hpp"

int main(){
	system("cls");
	Sayi* s=new Sayi();
	cout<<*s;
	delete s;
	return 0;
}