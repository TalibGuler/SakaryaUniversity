﻿/****************************************************************************
**          SAKARYA ÜNİVERSİTESİ
**   BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**      BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**        PROGRAMLAMAYA GİRİŞİ DERSİ
**
** ÖDEV NUMARASI…...: 1
** ÖĞRENCİ ADI...............: Abdülmuttalib GÜLER
** ÖĞRENCİ NUMARASI.: G181210011
** DERS GRUBU…………: 1.Öğretim A Grubu
****************************************************************************/
#include"windows.h"
#include<string>
#include<iostream>
#include<stdio.h>
#include<fstream>
#include <sstream>
#include <conio.h>
#include<vector>
#include<locale.h>
#include<iomanip>
using namespace std;

string hakkedisNo[100];
string urunNo[100];
string urunAdi[100];
string birim[100];
string birimFiyati[100];
string marka[100];

string projeNo[100];
string projeAdi[100];
string firma[100];
string projeSorumlusu[100];
string projeKontroloru[100];
string hakkedisUrunler[100][100];
string hakkedisDonem[100][100];
string hakFazlaAdet[100][100];
string toplamlar[100];
string hakAdetFiyat[100];
int donAdet[100];
int hakUrun[100];
int projeadet = 0;
int urunadet = 0;
int hakkedisadet = 0;
int donemSay = 0;
int fazlaadet = 0;
int hakadet = 0;
int donem = 0;

int main()
{
    for (int e = 0; e < 100; e++)
    {
        for (int l = 0; l < 100; l++) {
            hakkedisDonem[e][l] = "0";
        }

    }
    void urunOku();
    void projeOku();
    void baslangic();
    urunOku();
    projeOku();
    baslangic();

    return 0;

}
void baskaIslem()
{
    void baslangic();
    string sonuc;
    cout << "\nBASKA ISLEM YAPMAK ISTER MISINIZ?\n(E/H) : ";
    cin.ignore();
    getline(cin, sonuc);
    while (sonuc != "e" && sonuc != "h" && sonuc != "E" && sonuc != "H")
    {
        cout << "HATALI GIRDI TEKRAR GIRIN\nE/H : ";
        getline(cin, sonuc);
    }
    if (sonuc == "e" || sonuc == "E")
    {
        baslangic();
    }
    else
    {
        system("CLS");
        cout << "<<<PROGRAM KAPATILIYOR..>>";
        Sleep(100);
        exit(0);
    }

}

void baslangic()
{
    system("CLS");
    void urunEkle();
    void urunOku();
    void projeOku();
    void projeEkle();
    void projeAra();
    void urunAra();
    void urunRaporla();
    void projeRaporla();
    void baskaIslem();
    void baslangic();
    void urunSil();
    void projeSil();
    void hakkedisVer();
    void hakkedisOku();
    void hakUrunislem();
    void hakkedisRaporla();
    int islem;
    do
    {
        system("CLS");
        cout << "#########################\n# 1-)Proje islemleri\t#\n# 2-)Urun islemleri\t#\n# 3-)Hakkedis islemleri\t#\n#########################\nISLEM SECIN : ";
        cin >> islem;
    } while (islem != 1 && islem != 2 && islem != 3);

    if (islem == 1)
    {
        do {
            system("CLS");
            cout << "#################\n# 1-)Proje Ekle\t#\n# 2-)Proje sil\t#\n# 3-)Proje ara\t#\n# 4-)Raporla\t#\n#################\nISLEM SECIN : ";
            cin >> islem;
        } while (islem != 1 && islem != 2 && islem != 3 && islem != 4);
        if (islem == 1) {
            projeOku();
            projeEkle();

        }
        if (islem == 3) {
            projeAra();
        }
        if (islem == 2)
        {
            projeSil();
            projeOku();
        }
        if (islem == 4)
        {
            projeRaporla();

        }
    }
    else if (islem == 2)
    {
        do {
            system("CLS");
            cout << "*****************\n* 1-)Urun Ekle\t*\n* 2-)Urun sil\t*\n* 3-)Urun ara\t*\n* 4-)Raporla\t*\n*****************\nISLEM SECIN : ";
            cin >> islem;
        } while (islem != 1 && islem != 2 && islem != 3 && islem != 4);
        if (islem == 1) {
            urunOku();
            urunEkle();

        }
        if (islem == 2)
        {
            urunSil();
        }
        if (islem == 3) {
            urunAra();
        }
        if (islem == 4) {
            urunRaporla();
        }
    }
    else if (islem == 3)
    {
        do
        {
            system("CLS");
            cout << "=================================================\n=\tYAPILICAK ISLEMI SECIN\t\t\t=\n=\t1-)Projeye Hakkedis Verme\t\t=\n=    2-)Urun Listele, Ara, Guncelle\t\t=\n=   3-)Secili Bir Proje Icin Hakkedis Raporla   =\n=================================================\nISLEM SECIN : ";
            cin >> islem;
        } while (islem != 1 && islem != 2 && islem != 3);
        if (islem == 1)
        {
            hakkedisVer();
        }
        if (islem == 2)
        {
            system("CLS");
            hakkedisOku();
            cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n~ 1-)Hakkedis Verilmis Urunleri Listele ~\n~ 2-)Hakkedis Urunlerinde Islemler\t~\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nISLEM : ";
            cin >> islem;
            if (islem == 1)
            {
                if (hakadet == 0) { cout << "\nHAKKEDIS VERILMIS PROJE YOK..\n"; baskaIslem(); }
                for (int j = 0; j < hakadet; j++) {
                    cout << "*********************\n";
                    cout << "Hakkedis No:" << hakkedisNo[j];
                    for (int a = 0; a < hakUrun[j]; a++)
                    {
                        cout << "\n" << a + 1 << ". Urun Adi   : " << hakkedisUrunler[j][a] << "\n" << a + 1 << ". Urun Adedi : " << hakFazlaAdet[j][a];
                    }
                    cout << "\n*********************\n";
                }
                baskaIslem();
            }
            else if (islem == 2)
            {
                hakUrunislem();
            }
            else { cout << "HATALI GIRDI.."; baskaIslem(); }
        }
        if (islem == 3)
        {
            hakkedisRaporla();
        }
    }

}

void urunOku()
{
    int a = 0;
    int birimfiyati = 0;
    int markaNo = 0;
    int urunadi = 0;
    int urunno = 0;
    int birimNo = 0;
    urunadet = 0;
    ifstream dosyaOku("urunler.txt");
    string satir;

    if (dosyaOku.is_open()) {

        while (getline(dosyaOku, satir))
        {


            if ((a + 5) % 5 == 0)
            {
                urunNo[urunno] = satir;
                urunno++;
            }
            else if ((a + 5) % 5 == 1)
            {
                urunAdi[urunadi] = satir;
                urunadi++;
            }
            else if ((a + 5) % 5 == 2)
            {
                birim[birimNo] = satir;
                birimNo++;
            }
            else if ((a + 5) % 5 == 3)
            {
                birimFiyati[birimfiyati] = satir;
                birimfiyati++;
            }
            else if ((a + 5) % 5 == 4)
            {
                marka[markaNo] = satir;
                markaNo++;
                urunadet++;
            }
            a++;
        }

        dosyaOku.close();
    }



}


void projeOku()
{

    int a = 0;
    int projeno = 0;
    int projeadi = 0;
    int firmaNo = 0;
    int projesorumlusu = 0;
    int projekontroloru = 0;
    projeadet = 0;
    ifstream dosyaOku("projeler.txt");
    string satir;

    if (dosyaOku.is_open()) {

        while (getline(dosyaOku, satir))
        {


            if ((a + 5) % 5 == 0)
            {
                projeNo[projeno] = satir;
                projeno++;
            }
            else if ((a + 5) % 5 == 1)
            {
                projeAdi[projeadi] = satir;
                projeadi++;
            }
            else if ((a + 5) % 5 == 2)
            {
                firma[firmaNo] = satir;
                firmaNo++;
            }
            else if ((a + 5) % 5 == 3)
            {
                projeSorumlusu[projesorumlusu] = satir;
                projesorumlusu++;
            }
            else
            {
                projeKontroloru[projekontroloru] = satir;
                projekontroloru++;
                projeadet++;
            }
            a++;
        }

        dosyaOku.close();
    }



}

void urunEkle() {
    urunOku();
    string ekurunNum, ekurunAdi, ekBirimi, ekbirimFiyati, ekMarkasi;
    cin.ignore();
    cout << "Urun No    : "; getline(cin, ekurunNum);

A:
    for (int i = 0; i < urunadet; i++)
    {
        if (ekurunNum == urunNo[i])
        {
            cout << "Urun numarasi var tekrar girin : ";
            getline(cin, ekurunNum);
            goto A;
        }
    }


    cout << "Urun Adi: "; getline(cin, ekurunAdi);
    cout << "Birimi	: "; getline(cin, ekBirimi);
    cout << "Birim Fiyati: "; getline(cin, ekbirimFiyati);
    cout << "Markası     : "; getline(cin, ekMarkasi);
    fstream dosya;
    dosya.open("urunler.txt", ios::app | ios::out | ios::in);
    dosya << ekurunNum << "\n" << ekurunAdi << "\n" << ekBirimi << "\n" << ekbirimFiyati << "\n" << ekMarkasi << "\n";

    dosya.close();
    urunOku();
    baskaIslem();
}

void projeEkle() {
    projeOku();
    string ekprojeNum, ekprojeAdi, ekFirma, ekSorumlusu, ekKontrolor;
    cin.ignore();
    cout << "\nLUTFEN TURKCE KARAKTER KULLANMAYINIZ \n\n" << "Proje No : "; getline(cin, ekprojeNum);

A:
    for (int i = 0; i < projeadet; i++)
    {
        if (ekprojeNum == projeNo[i])
        {
            cout << "Proje numarasi var tekrar girin : ";
            getline(cin, ekprojeNum);
            goto A;
        }
    }


    cout << "Proje Adi: "; getline(cin, ekprojeAdi);
    cout << "Proje Yurutucu Firma : "; getline(cin, ekFirma);
    cout << "Proje Sorumlusu : "; getline(cin, ekSorumlusu);
    cout << "Proje Kontroloru  : "; getline(cin, ekKontrolor);
    fstream dosya;
    dosya.open("projeler.txt", ios::app | ios::out | ios::in);
    dosya << ekprojeNum << "\n" << ekprojeAdi << "\n" << ekFirma << "\n" << ekSorumlusu << "\n" << ekKontrolor << "\n";

    dosya.close();
    projeOku();
    baskaIslem();
}

void projeAra()
{
    system("CLS");
    projeOku();
    string projenumarasi, aranacakfirma, projead;
    int sayac1 = 0;
    int sayac2 = 0;
    int sayac3 = 0;
    int arama;
    cout << "Arama Kiriteri Girin\n1-)Proje Numrasina Gore\n2-)Yurutucu Firmaya Gore\n3-)Proje Adina Gore\nISLEM SECIN : ";
    cin >> arama;

    if (arama == 1)
    {
        cout << "Aramak Istediginiz Proje Numarasini Girin : ";
        cin >> projenumarasi;

        for (int k = 0; k < projeadet; k++)
        {

            if (projenumarasi == projeNo[k])
            {
                cout << "Proje Numarasi : " << projeNo[k] << "\nProje Adi : " << projeAdi[k] << "\nYapan Firma : " << firma[k] << "\nSorumlusu : " << projeSorumlusu[k] << "\nProje Kontoroloru : " << projeKontroloru[k];
                sayac1 = 1;
            }


        }
        if (sayac1 == 0)
        {
            cout << "Proje Bulunamadi.";
        }

    }
    if (arama == 2)
    {
        cout << "Aramak Istediginiz Firma Adini Girin : ";
        cin >> aranacakfirma;
        for (int l = 0; l < projeadet; l++)
        {

            if (aranacakfirma == firma[l])
            {
                cout << "Proje Numarasi : " << projeNo[l] << "\nProje Adi : " << projeAdi[l] << "\nYapan Firma : " << firma[l] << "\nSorumlusu : " << projeSorumlusu[l] << "\nProje Kontoroloru : " << projeKontroloru[l];
                sayac2 = 1;
            }

        }
        if (sayac2 == 0)
        {
            cout << "Proje Bulunamadi.";
        }
    }
    if (arama == 3)
    {
        cout << "Aramak Istediginiz Proje Adini Girin : ";
        cin >> projead;
        for (int u = 0; u < projeadet; u++)
        {

            if (projead == projeAdi[u])
            {
                cout << "Proje Numarasi : " << projeNo[u] << "\nProje Adi : " << projeAdi[u] << "\nYapan Firma : " << firma[u] << "\nSorumlusu : " << projeSorumlusu[u] << "\nProje Kontoroloru : " << projeKontroloru[u];
                sayac3 = 1;
            }

        }
        if (sayac3 == 0)
        {
            cout << "Proje Bulunamadi.";
        }
    }
    baskaIslem();
}

void urunAra()
{
    system("CLS");
    urunOku();
    string araNo, araAd, araMarka; int arama;
    int sayac1 = 0;
    int sayac2 = 0;
    int sayac3 = 0;
    cout << "Arama Kiriteri Girin\n1-)Urun Numrasina Gore\n2-)Urun Adina Gore\n3-)Markaya Gore\nISLEM SECIN : ";
    cin >> arama;
    if (arama == 1)
    {
        cout << "Aramak Istediginiz Urun No Girin : ";
        cin >> araNo;
        for (int i = 0; i < urunadet; i++)
        {

            if (araNo == urunNo[i])
            {
                cout << "\nUrun No : " << urunNo[i] << "\nUrun Adi : " << urunAdi[i] << "\nBirimi : " << birim[i] << "\nBirim Fiyati : " << birimFiyati[i] << "\nMarkasi : " << marka[i];
                sayac1 = 1;
            }
        }
        if (sayac1 == 0)
        {
            cout << "Urun Bulunamadi. ";
        }
    }
    if (arama == 2)
    {
        cout << "Aramak Istediginiz Urunun Adini Girin : ";
        cin >> araAd;
        for (int i = 0; i < urunadet; i++)
        {

            if (araAd == urunAdi[i])
            {
                cout << "\nUrun No : " << urunNo[i] << "\nUrun Adi : " << urunAdi[i] << "\nBirimi : " << birim[i] << "\nBirim Fiyati : " << birimFiyati[i] << "\nMarkasi : " << marka[i];
                sayac2 = 1;
            }

        }
        if (sayac2 == 0)
        {
            cout << "Urun Bulunamadi. ";
        }
    }
    if (arama == 3)
    {
        cout << "Aramak Istediginiz Markayi Girin : ";
        cin >> araMarka;
        for (int i = 0; i < urunadet; i++)
        {

            if (araMarka == marka[i])
            {
                cout << "\nUrun No : " << urunNo[i] << "\nUrun Adi : " << urunAdi[i] << "\nBirimi : " << birim[i] << "\nBirim Fiyati : " << birimFiyati[i] << "\nMarkasi : " << marka[i];
                sayac3 = 1;
            }

        }
        if (sayac3 == 0)
        {
            cout << "Urun Bulunamadi. ";
        }
    }
    baskaIslem();
}

void urunRaporla()
{
    system("CLS");
    urunOku();
    int arama;
    int x = 0;
    int y = 0;
    int z = 0;
    int sayac1 = 0;
    int sayac2 = 0;
    int sayac3 = 0;
    cout << "Arama Kiriteri Girin\n1-)Urun Numrasin 5'ten Kucuk Olanlar\n2-)Urun Birimi 100'den Fazla Olanlar\n3-)Urun Birim Fiyati 200'den Az Olanlar\nISLEM SECIN : ";
    cin >> arama;
    if (arama == 1)
    {
        for (int i = 0; i < (urunadet * 5) - 1; i++)
        {
            if ((i + 5) % 5 == 0)
            {
                if (stoi(urunNo[x]) < 5) {
                    cout << "=====BULUNAN URUNLER=====\n"
                        << "Urun No : " << urunNo[x] << "\nUrun Ad : " << urunAdi[x] << "\nUrun Birimi : " << birim[x]
                        << "\nBirim Fiyati : " << birimFiyati[x] << "\nMarkasi : " << marka[x] << "\n=========================\n" << endl;
                    sayac1 = 1;
                }
                x++;
            }
        }
        if (sayac1 == 0)
        {
            cout << "Aranan Kriterlere Uygun Urun Bulunamadi.";
        }
    }
    if (arama == 2)
    {
        for (int i = 0; i < (urunadet * 5) - 1; i++)
        {
            if ((i + 5) % 5 == 2)
            {
                if (stoi(birim[y]) > 100) {
                    cout << "=====BULUNAN URUNLER=====\n"
                        << "Urun No : " << urunNo[y] << "\nUrun Ad : " << urunAdi[y] << "\nUrun Birimi : " << birim[y]
                        << "\nBirim Fiyati : " << birimFiyati[y] << "\nMarkasi : " << marka[y] << "\n=========================\n" << endl;
                    sayac2 = 1;
                }
                y++;
            }
        }
        if (sayac2 == 0)
        {
            cout << "Aranan Kriterlere Uygun Urun Bulunamadi.";
        }
    }
    if (arama == 3)
    {
        for (int i = 0; i < (urunadet * 5) - 1; i++)
        {
            if ((i + 5) % 5 == 3)
            {
                if (stoi(birimFiyati[z]) < 200) {
                    cout << "=====BULUNAN URUNLER=====\n"
                        << "Urun No : " << urunNo[z] << "\nUrun Ad : " << urunAdi[z] << "\nUrun Birimi : " << birim[z]
                        << "\nBirim Fiyati : " << birimFiyati[z] << "\nMarkasi : " << marka[z] << "\n=========================\n" << endl;
                    sayac3 = 1;
                }
                z++;
            }
        }
        if (sayac3 == 0)
        {
            cout << "Aranan Kriterlere Uygun Urun Bulunamadi.";
        }

    }
    baskaIslem();
}

void projeRaporla()
{
    system("CLS");
    projeOku();
    int arama;
    string kopyaFirma[100];

    int z = 0;
    int sayac1 = 0;
    int sayac2 = 0;
    int sayac3 = 0;
    cout << "Arama Kiriteri Girin\n1-)Ilk 5 Proje Goster\n2-)Insaat Firması Olanlar\n3-)Hakkedis Verilmisler\nISLEM SECIN : ";
    cin >> arama;
    if (arama == 1)
    {
        if (projeadet > 4)
        {
            cout << "===" << projeadet << " Projeden Ilk 5 Proje===\n\n";
        }
        else
        {
            cout << "===  PROJE SAYİSİ 5'TEN AZ  ===" << endl;
            cout << "===" << projeadet << " Adet Proje Gosteriliyor===\n\n";
        }
        for (int k = 0; k < projeadet; k++)
        {
            if (k < 5) {
                cout << "======BULUNAN PROJELER======\n"
                    << "Proje No : " << projeNo[k] << "\nProje Adi : " << projeAdi[k] << "\nYurutucu Firma : " << firma[k]
                    << "\nProje Sorumlusu : " << projeSorumlusu[k] << "\nProje Kontroloru : " << projeKontroloru[k] << "\n============================\n" << endl;
                sayac1 = 1;
            }
        }
        if (sayac1 == 0)
        {
            cout << "Proje Bulunamadi";
        }
    }
    if (arama == 2)
    {
        for (int l = 0; l < (projeadet * 5) - 1; l++)
        {
            if ((l + 5) % 5 == 2)
            {
                int y = 0;
                kopyaFirma[z] = firma[z];
                while (kopyaFirma[z] != "insaat")
                {
                    y++;
                    kopyaFirma[z].erase(kopyaFirma[z].begin());
                    if (firma[z].length() == y)
                    {
                        break;
                    }
                }
                if (kopyaFirma[z] == "insaat")
                {
                    cout << "======BULUNAN PROJELER======\n"
                        << "Proje No : " << projeNo[z] << "\nProje Adi : " << projeAdi[z] << "\nYurutucu Firma : " << firma[z]
                        << "\nProje Sorumlusu : " << projeSorumlusu[z] << "\nProje Kontroloru : " << projeKontroloru[z] << "\n============================\n" << endl;
                    sayac2 = 1;
                }
                z++;
            }


        }
        if (sayac2 == 0)
        {
            cout << "Proje Bulunamadi";
        }

    }
    projeOku();
    baskaIslem();
}

void urunSil()
{
    urunOku();
    string araNo;
    int sayac1 = 0;
    if (urunadet > 0) { cout << "|========URUNLER========|\n"; }
    else { cout << "----HIC URUN BULUNAMAMAKTADIR----"; }
    for (int k = 0; k < urunadet; k++)
    {
        cout << "=========================\n" << "Urun No : " << urunNo[k] << "\nUrun Ad : " << urunAdi[k] << "\nUrun Birimi : " << birim[k]
            << "\nBirim Fiyati : " << birimFiyati[k] << "\nMarkasi : " << marka[k] << "\n=========================\n";
    }
    if (urunadet > 0)
    {
        cout << "--SILMEK ISTEDIGINIZ URUN NUMARASINI GIRINIZ--\nURUN NO : ";
        cin >> araNo;
    }
    ofstream dosya("gecici.tmp");
    for (int j = 0; j < urunadet; j++)
    {


        if (araNo == urunNo[j])
        {
            cout << "=========================\n" << "Urun No : " << urunNo[j] << "\nUrun Ad : " << urunAdi[j] << "\nUrun Birimi : " << birim[j]
                << "\nBirim Fiyati : " << birimFiyati[j] << "\nMarkasi : " << marka[j] << "\n=========================\n" << "---URUN SILINIYOR---";
            sayac1 = 1;
        }
        else
        {
            if (dosya.is_open())
                dosya << urunNo[j] << "\n" << urunAdi[j] << "\n" << birim[j] << "\n" << birimFiyati[j] << "\n" << marka[j] << "\n";
        }

    }
    dosya.close();
    remove("urunler.txt");
    rename("gecici.tmp", "urunler.txt");
    if (sayac1 == 0)
    {
        cout << "\nISTEDIGINIZ URUN ZATEN YOK ISLEM YAPILAMIYOR...\n";
    }
    urunOku();
    baskaIslem();

}

void projeSil()
{
    void hakkedisOku();
    projeOku();
    hakkedisOku();
    string araNo;
    int sayac1 = 0;
    int sayac2 = 0;
    int x = 0;
    int y = 0;
    if (projeadet > 0) { cout << "|========PROJELER========|\n"; }
    else { cout << "----HIC PROJE BULUNAMAMAKTADIR----"; }
    for (int k = 0; k < projeadet; k++)
    {
        cout << "=========================\n" << "Proje No : " << projeNo[k] << "\nProje Adi : " << projeAdi[k] << "\nYurutucu Firma : " << firma[k]
            << "\nProje Sorumlusu : " << projeSorumlusu[k] << "\nProje Kontoroloru : " << projeKontroloru[k] << "\n=========================\n";
    }
    if (projeadet > 0)
    {
        cout << "--SILMEK ISTEDIGINIZ PROJENIN NUMARASINI GIRINIZ--\nProje NO : ";
        cin >> araNo;
    }
    do
    {
        if (araNo == hakkedisNo[x])
        {
            if (y == 0)
            {
                cout << "Bu Projeye Hakkedis Verilmis Silinemez..";
                y++;
            }
            sayac1 = 1;
        }
        x++;

    } while (x != hakadet);
    if (sayac1 == 0)
    {
        ofstream dosya("gecici.tmp");
        for (int j = 0; j < projeadet; j++)
        {


            if (araNo == projeNo[j])
            {
                cout << "=========================\n" << "Proje No : " << projeNo[j] << "\nProje Adi : " << projeAdi[j] << "\nYurutucu Firma : " << firma[j]
                    << "\nProje Sorumlusu : " << projeSorumlusu[j] << "\nProje Kontoroloru : " << projeKontroloru[j] << "\n=========================\n" << "---PROJE SILINIYOR---";
                sayac2 = 1;
            }
            else
            {
                if (dosya.is_open())
                    dosya << projeNo[j] << "\n" << projeAdi[j] << "\n" << firma[j] << "\n" << projeSorumlusu[j] << "\n" << projeKontroloru[j] << "\n";
            }

        }
        dosya.close();
        remove("projeler.txt");
        rename("gecici.tmp", "projeler.txt");
        if (sayac2 == 0)
        {
            cout << "\nARADGINIZ PROJE ZATEN YOK ISLEM YAPILAMIYOR...\n";
        }
    }
    projeOku();
    baskaIslem();
}

void hakkedisVer()
{
    void tekrarYaz();
    void hakkedisYaz();
    void hakkedisOku();
    void hakTekrarYaz();
    projeOku();
    urunOku();
    hakkedisOku();
    string araNo;
    string ekleUrun;
    string soru;
    int sayac = 0;
    int sayac2 = 0;
    int urunsay = 0;
    int urunBul = 0;
    int ekleAdet = 0;
    donem = 0;
    int urunnosay = 0;
    hakkedisadet = 0;
    int hakNo = 0;
    for (int d = 0; d < projeadet; d++)
    {
        if (d == 0)
        {
            cout << "HALI HAZIRDA BULUNAN PROJE NUMARALARI --> |" << projeNo[d] << "|";
        }
        else
        {
            cout << "|" << projeNo[d] << "|";
        }
    }
    cout << "\nHakkedis Verilecek Proje Numarasini Giriniz : ";




C:  cin >> araNo;

    for (int d = 0; d < projeadet; d++)
    {



        if (projeNo[d] == araNo)
        {
            hakkedisadet++;
            hakkedisNo[hakNo] = projeNo[d];
            cout << "Proje " << projeNo[d] << " Bulundu.\n";
        K:
            for (int n = 0; n < urunadet; n++)
            {
                cout << n + 1 << ". URUN ADI-->> " << urunAdi[n] << endl;
                cout << n + 1 << ". ADEDI-->" << birim[n] << endl;
                cout << n + 1 << ". URUN FIYATI-->" << birimFiyati[n] << "\n=====================" << endl;
            }


        T:
            cout << "Eklenecek Urun Adini Girin : ";
            cin >> ekleUrun;
            for (int a = 0; a < urunadet; a++)
            {
                if (urunAdi[a] == ekleUrun)
                {
                    if (stoi(birim[a]) != 0) { hakkedisUrunler[urunnosay][fazlaadet] = urunAdi[a]; }

                    cout << "\nURUN BULUNDU";
                    cout << "\nKac Adet Eklensin : ";
                    cin >> ekleAdet;
                    if (stoi(birim[a]) == 0) { cout << "URUN ADETI YOK EKLENEMIYOR.."; }
                    else
                    {
                        if (ekleAdet > stoi(birim[a]))
                        {
                            cout << "\nFazla Adet Girildi Tamami Aliniyor";
                            hakFazlaAdet[urunnosay][fazlaadet] = birim[a];
                            hakAdetFiyat[fazlaadet] = birimFiyati[a];
                            birim[a] = "0";
                            tekrarYaz();
                        }
                        else
                        {
                            cout << "\nYeteri Kadar Urun Bulundu Ekleniyor";
                            hakAdetFiyat[fazlaadet] = birimFiyati[a];
                            hakFazlaAdet[urunnosay][fazlaadet] = to_string(ekleAdet);
                            birim[a] = to_string(stoi(birim[a]) - ekleAdet);
                            tekrarYaz();
                        }
                    }



                    cout << "\nBASKA URUN EKLENICEK MI?(E/H) : ";
                    cin >> soru;
                    if (soru == "e" || soru == "E")
                    {
                        if (stoi(birim[a]) != 0)
                        {
                            fazlaadet++;
                        }
                        goto K;
                    }
                    else if (soru == "h" || soru == "H")
                    {
                        hakUrun[urunsay] = fazlaadet + 1;
                        urunsay++;  fazlaadet = 0;
                        cout << "GECILIYOR..";

                        while (hakkedisDonem[stoi(araNo)][donem] != "0")
                        {
                            donem++;
                        }
                        if (donem > 0)
                        {
                            hakkedisDonem[stoi(araNo)][donem] = to_string(stoi(hakkedisDonem[stoi(araNo)][donem - 1]) + 1);
                        }
                        else
                        {
                            hakkedisDonem[stoi(araNo)][donem] = "1";
                        }
                    }
                    else {
                        hakUrun[hakNo] = fazlaadet + 1; urunsay++;
                        fazlaadet = 0;

                        while (hakkedisDonem[stoi(araNo)][donem] != "0")
                        {
                            donem++;
                        }
                        if (donem > 0)
                        {
                            hakkedisDonem[stoi(araNo)][donem] = to_string(stoi(hakkedisDonem[stoi(araNo)][donem - 1]) + 1);
                        }
                        else
                        {
                            hakkedisDonem[stoi(araNo)][donem] = "1";
                        } cout << "HATALI GIRDI GECILIYOR..";

                    }





                    sayac2 = 1;
                }
                hakNo++;
            }
            if (sayac2 == 0)
            {
                cout << "<<ZATEN VERILMIS VEYA HATALI GIRDI TEKRAR GIRIN>>\n";
                goto T;
            }

            sayac = 1;

        }

    }
    if (sayac == 0)
    {
        cout << "\nGIRILEN NUMARADA BIR PROJE YOK..\nTEKRAR GIRIN : ";
        goto C;
    }




    hakkedisYaz();
    baskaIslem();
}


void tekrarYaz()
{
    ofstream dosya("gecici.tmp");
    for (int j = 0; j < urunadet; j++)
    {
        if (dosya.is_open()) {
            dosya << urunNo[j] << "\n" << urunAdi[j] << "\n" << birim[j] << "\n" << birimFiyati[j] << "\n" << marka[j] << "\n";
        }
    }
    dosya.close();
    remove("urunler.txt");
    rename("gecici.tmp", "urunler.txt");

}

void hakkedisYaz()
{


    int toplam = 0;
    int deger;
    ofstream dosya("hakkedis.txt", ios::app);
    for (int j = 0; j < hakkedisadet; j++)
    {

        if (dosya.is_open()) {
            dosya << "no:" << hakkedisNo[j];
            deger = stoi(hakkedisNo[j]);
            for (int a = 0; a < hakUrun[j]; a++)
            {
                dosya << "\n" << "urunad:" << hakkedisUrunler[j][a] << "\n" << "urunadet:" << hakFazlaAdet[j][a] << "\n" << "adetfiyat:" << hakAdetFiyat[a];
                toplam = toplam + stoi(hakFazlaAdet[j][a]) * stoi(hakAdetFiyat[a]);
            }
            dosya << "\n" << "donem:" << hakkedisNo[j] << "-" << hakkedisDonem[deger][donem] << "\n" << "toplam:" << toplam << endl;
        }
    }
    dosya.close();
}
void hakTekrarYaz()
{
    int toplam = 0;
    int deger[100];
    int deger2[100];
    for (int x = 0; x < 100; x++) { deger2[x] = 0; }
    int kontrol = 0;
    int j = 0;
    int k = 1;
    ofstream dosya("gecici2.tmp");
    for (int l = 0; l < 100; l++)
    {
        for (int y = 0; y < 100; y++)
        {
            if (hakkedisNo[y] == to_string(l))
            {
                deger2[l] = deger2[l] + 1;
            }

        }

    }
    for (int k = 0; k < 100; k++)
    {
        if (k < hakadet) deger[k] = stoi(hakkedisNo[k]);
        else { deger[k] = 0; }
    }
    for (int j = 0; j < hakadet; j++)
    {

        if (dosya.is_open()) {
            dosya << "no:" << hakkedisNo[j];

            for (int a = 0; a < hakUrun[j]; a++)
            {
                dosya << "\n" << "urunad:" << hakkedisUrunler[j][a] << "\n" << "urunadet:" << hakFazlaAdet[j][a] << "\n" << "adetfiyat:" << hakAdetFiyat[a];
                toplam = toplam + stoi(hakFazlaAdet[j][a]) * stoi(hakAdetFiyat[a]);
            }
            dosya << "\n" << "donem:" << hakkedisNo[j] << "-";

            if (hakkedisDonem[deger[j]][kontrol] != "0")
            {
                if (deger[j] != deger[j + 1])
                {
                    dosya << kontrol + 1;
                    kontrol++;
                }
                else
                {

                    dosya << kontrol + 1;
                    kontrol++;

                }
            }

            dosya << "\n" << "toplam:" << toplam << endl;
        }
    }
    dosya.close();
    remove("hakkedis.txt");
    rename("gecici2.tmp", "hakkedis.txt");

}
void hakkedisOku()
{
    for (int e = 0; e < 100; e++)
    {
        for (int l = 0; l < 100; l++) {
            hakkedisDonem[e][l] = "0";
        }

    }
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 0;
    int e = 0;
    int f = 0;
    int donsay = 0;
    int hakkedisno = 0;
    int adetsay = 0;
    string kopSatir;
    int k = 0;
    hakadet = 0;
    for (int j = 0; j < 100; j++)
    {
        hakUrun[j] = 0;
    }
    ifstream dosyaOku("hakkedis.txt");
    string satir;

    if (dosyaOku.is_open()) {

        while (getline(dosyaOku, satir))
        {

            if (!satir.find("no:"))
            {
                satir.erase(0, 3);
                hakkedisNo[hakkedisno] = satir;
                hakkedisno++;
                hakadet++;
            }
            else if (!satir.find("urunad:"))
            {
                satir.erase(0, 7);
                if (hakadet == b + 2)
                {
                    b++;
                    c = 0;
                }
                hakkedisUrunler[b][c] = satir;

                hakUrun[b]++;
                c++;
            }
            else if (!satir.find("urunadet:"))
            {
                satir.erase(0, 9);
                if (hakadet == d + 2)
                {
                    d++;
                    e = 0;
                }
                hakFazlaAdet[d][e] = satir;

                e++;
            }
            else if (!satir.find("donem:"))
            {
                satir.erase(0, 6);
                kopSatir = satir;

                if (satir.find("-"))
                {
                    for (int k = 0; k < satir.length(); k++)
                    {
                        if (satir.at(k) == '-')
                        {
                            satir.erase(satir.begin() + k, satir.end());

                        }
                    }

                    while (kopSatir.find("-")) { kopSatir.erase(kopSatir.begin()); }
                    kopSatir.erase(kopSatir.begin());
                    donsay = 0;
                    while (hakkedisDonem[stoi(satir)][donsay].find("0"))
                    {
                        donsay++;
                    }
                    hakkedisDonem[stoi(satir)][donsay] = kopSatir;

                }


            }
            else if (!satir.find("adetfiyat:"))
            {
                satir.erase(0, 10);
                hakAdetFiyat[adetsay] = satir;
                adetsay++;
            }
            else if (!satir.find("toplam:"))
            {
                satir.erase(0, 7);
                toplamlar[a] = satir;
                a++;
            }



        }

        dosyaOku.close();
    }



}


void hakUrunislem()
{

    hakkedisOku();
    void hakkedisYaz();
    system("CLS");
    int islem;
    int sayac = 0;
    int sayac2 = 0;
    int sayac3 = 0;
    int sayac4 = 0;
    int sayac5 = 0;
    int sayac6 = 0;
    int islem2;
    int y = 0;
    string urAdet;
    string araNo;
    string urunAra;
    string donAra;
    string urAra;
    cout << "*************************************\n1-)Kullanilan Urunlerde Arama Yapma\n2-)Urun Guncelleme\n3-)Urun Silme\n*************************************\nISLEM : ";
    cin >> islem;
    if (islem == 1)
    {
        if (hakadet == 0) { cout << "\nHAKKEDIS VERILMIS PROJE YOK..\n"; baskaIslem(); }


        cout << "Aranancak Urun Adini Girin : ";
        cin >> urunAra;

        for (int k = 0; k < hakadet; k++)
        {




            for (int l = 0; l < hakUrun[k]; l++)
            {

                if (urunAra == hakkedisUrunler[k][l])
                {
                    cout << "~~~~~~~~~~~~~~~~~~~\n" << "Proje No : " << hakkedisNo[k] << "\nUrun Ad   : " << hakkedisUrunler[k][l] << endl << "Urun Adet : " << hakFazlaAdet[k][l] << endl << "~~~~~~~~~~~~~~~~~~~\n";
                    sayac = 1;

                }
            }
        }
        if (sayac == 0)
        {
            cout << "URUN BULUNAMADI..";
            baskaIslem();
        }

    }
    else if (islem == 2)
    {
        if (hakadet == 0) { cout << "\nHAKKEDIS VERILMIS PROJE YOK..\n"; baskaIslem(); }
        for (int d = 0; d < 100; d++)
        {
            for (int l = 0; l < 100; l++)
            {
                if (!hakkedisNo[l].empty() && hakkedisDonem[d][l] != "0") {
                    cout << "HAKKEDIS NO-DONEM : " << d << "-" << hakkedisDonem[d][l] << endl;
                }

            }
        }
        cout << "\nARAMA YAPILACAK HAKKEDIS NO GIRIN : ";
        cin >> araNo;
        cout << "GUNCELLEME YAPILACAK DONEMI GIRIN : ";
        cin >> donAra;
        for (int i = 0; i < 100; i++)
        {
            if (hakkedisNo[i] == araNo) { sayac5++; if (sayac5 == stoi(donAra)) { break; } sayac3++; }
            else { sayac3++; }
        }
        for (int k = 0; k < 100; k++)
        {


            if (hakkedisNo[k] == araNo && sayac6 == 0)
            {
                sayac6 = 1;
                cout << endl << hakkedisNo[k] << " . Numarili Hakkedis Bulundu..\n";

                for (int l = 0; l < hakUrun[sayac3]; l++)
                {
                    if (l == 0) { cout << ">>>HAKKEDISTEKI URUNLER<<<\n"; }

                    cout << "~~~~~~~~~~~~~~~~~~~\n" << "Urun Ad   : " << hakkedisUrunler[sayac3][l] << endl << "Urun Adet : " << hakFazlaAdet[sayac3][l] << endl << "~~~~~~~~~~~~~~~~~~~\n";

                }
                cout << "GUNCELLEMEK ISTEDIGINIZ URUN ADINI GIRIN : ";
                cin >> urAra;

                for (int l = 0; l < hakUrun[sayac3]; l++)
                {

                    if (urAra == hakkedisUrunler[sayac3][l])
                    {
                        cout << "\nURUN BULUNDU..\n" << "~~~~~~~~~~~~~~~~~~~\n" << "Urun Ad   : " << hakkedisUrunler[sayac3][l] << endl << "Urun Adet : " << hakFazlaAdet[sayac3][l] << endl << "~~~~~~~~~~~~~~~~~~~\n";
                        cout << "YENI ADET SAYISINI GIRINIZ : ";
                        cin >> urAdet;
                        for (int x = 0; x < urunadet; x++)
                        {
                            if (urAra == urunAdi[x])
                            {
                                if (birim[x] == "0") { cout << "URUN KALMAMIS GUNCELLEMEYOR..\n"; }
                                else if (stoi(urAdet) > stoi(birim[x]))
                                {
                                    cout << "FAZLA ADET GIRILDI TAMAMI ALINIYOR..\n";
                                    hakFazlaAdet[sayac3][l] = birim[x];
                                    birim[x] = "0";
                                    tekrarYaz();
                                    baskaIslem();
                                }
                                else if (stoi(urAdet) < stoi(birim[x]))
                                {
                                    cout << "YETERI ADET VAR ALINIYOR..\n";
                                    hakFazlaAdet[sayac3][l] = urAdet;
                                    birim[x] = to_string(stoi(birim[x]) - stoi(urAdet));
                                    tekrarYaz();
                                    baskaIslem();
                                }
                            }
                        }
                    }

                }
                sayac4 = 1;
            }


        }
        if (sayac4 == 0)
        {
            cout << "ARANAN NUMARADA HAKKEDIS YOK..";
            baskaIslem();
        }

    }


    baskaIslem();

}
void hakkedisRaporla()
{
    hakkedisOku();
    string araNo;
    string araDon;
    int islem;
    int deger[100];
    for (int x = 0; x < 100; x++) { deger[x] = 0; }

    int y = 0;
    int x = 0;
    int z = 0;
    int j = 0;
    int e = 0;
    cout << "++++++++++++++++++++++++++++++++++++\n+    1-)Doneme Gore Raporla\t   +\n+ 2-)Proje Numarasına Göre Raporla +\n++++++++++++++++++++++++++++++++++++\nISLEM : ";
    cin >> islem;
    if (islem == 1)
    {
        cout << "Aramak Istedıgınız Donem No Girin(1/2/3) : ";
        cin >> araDon;


        ifstream dosyaOku("hakkedis.txt");
        string satir;
        string kopSatir1;
        string kopSatir2;
        if (dosyaOku.is_open())
        {

            while (getline(dosyaOku, satir))
            {

                if (!satir.find("donem:"))
                {
                    j++;
                    satir.erase(0, 6);
                    kopSatir1 = satir;
                    kopSatir2 = satir;
                    if (satir.find("-"))
                    {
                        for (int k = 0; k < satir.length(); k++)
                        {
                            if (satir.at(k) == '-')
                            {
                                kopSatir1.erase(kopSatir1.begin() + k, kopSatir1.end());

                            }
                        }

                        while (kopSatir2.find("-")) { kopSatir2.erase(kopSatir2.begin()); }
                        kopSatir2.erase(kopSatir2.begin());

                        if (kopSatir2 == araDon)
                        {

                            deger[z] = y;
                            y++;
                            z++;
                        }
                        else { y++; }

                    }

                }






            }
        }

        for (int k = 0; k < hakadet + 1; k++)
        {
            for (int g = 0; g < hakadet + 1; g++)
            {
                if (hakkedisDonem[k][g] == araDon) {

                    cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~\nProje No : " << hakkedisNo[deger[e]];

                    for (int l = 0; l < hakUrun[deger[e]]; l++)
                    {
                        cout << "\nurun : " << hakkedisUrunler[deger[e]][l] << "\nUrun Adet : " << hakFazlaAdet[deger[e]][l];

                    }

                    cout << "\nTutar : " << toplamlar[deger[e]] << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
                    e++;
                }
            }
        }
        baskaIslem();
    }
    else if (islem == 2)
    {
        int toplam2 = 0;
        int sayac = 0;
        cout << "\nHakkedisi Aramak Istediginiz Proje Numarasini Girin : ";
        cin >> araNo;
        for (int m = 0; m < hakadet; m++)
        {
            if (araNo == hakkedisNo[m])
            {
                cout << "\n#######################" << "\nDonem: " << hakkedisDonem[stoi(araNo)][e];
                for (int l = 0; l < hakUrun[m]; l++)
                {
                    cout << "\nurun : " << hakkedisUrunler[m][l] << "\nUrun Adet : " << hakFazlaAdet[m][l];

                }
                cout << "\nTutar : " << toplamlar[m] << "\n#######################\n";
                e++;
                toplam2 = toplam2 + stoi(toplamlar[m]);
                sayac = 1;
            }

        }
        if (sayac == 1)
        {
            cout << "\n#########################\n Toplam Tutar : " << toplam2 << "\n#########################\n";
        }
        else if (sayac == 0)
        {
            cout << "Proje Bulunamadi..";
            baskaIslem();
        }
    }
    else
    {
        cout << "HATALI ISLEM";
        baskaIslem();
    }
    baskaIslem();
}