import React, {
  Dispatch,
  SetStateAction,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  Text,
  Modal,
  ModalProps,
  View,
  TouchableOpacity,
  KeyboardAvoidingView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Icon from "react-native-vector-icons/Feather";
import { AuthContext } from "../contexts/AuthContextProvider";
import { db, firestore } from "../firebase";
import Button from "./ui/Button";
import Checkbox from "./ui/Checkbox";
import Input from "./ui/Input";

const colors = ["#2d767f", "#fcb1b1", "#b7bea7", "#a6acec", "#a56cc1"];

interface CreateBookModalProps extends ModalProps {
  setVisible: Dispatch<SetStateAction<boolean>>;
}

export default function CreateBookModal({
  setVisible,
  ...rest
}: CreateBookModalProps) {
  const [opinion, setOpinion] = useState("");
  const [liked, setLiked] = useState(false);
  const [name, setName] = useState("");
  const [author, setAuthor] = useState("");
  const [genre, setGenre] = useState("");
  const [pages, setPages] = useState(0);

  const { authUser } = useContext(AuthContext);

  const handleSaveBook = async () => {
    await firestore.addDoc(firestore.collection(db, "books"), {
      userId: authUser.id,
      liked,
      name,
      author,
      opinion,
      genre,
      pages,
      color: colors[Math.floor(Math.random() * colors.length)],
      isTrash: false,
      createdAt: new Date(),
    });

    setVisible(false);
    setOpinion("");
    setAuthor("");
    setName("");
    setGenre("");
    setLiked(false);
    setPages(0);
  };

  return (
    <Modal animationType="slide" {...rest}>
      <SafeAreaView style={{ padding: 30, height: "100%" }}>
        <KeyboardAvoidingView
          style={{ height: "100%" }}
        >
          <View style={{ marginBottom: 30 }}>
            <TouchableOpacity
              style={{
                position: "absolute",
                right: 0,
                backgroundColor: "#9fbea5",
                padding: 5,
                zIndex: 9999,
                borderRadius: 25,
              }}
              onPress={() => setVisible(false)}
            >
              <Icon name="x" size={30} color="white" />
            </TouchableOpacity>
            <Text style={{ textAlign: "center", fontSize: 20 }}>
              Yeni Kitap Ekle
            </Text>
          </View>
          <Input
            placeholder="Kitap ismi"
            style={{ marginVertical: 10 }}
            value={name}
            onChangeText={(value) => setName(value)}
          />
          <Input
            placeholder="Yazar"
            style={{ marginVertical: 10 }}
            value={author}
            onChangeText={(value) => setAuthor(value)}
          />
          <Input
            placeholder="Türü"
            style={{ marginVertical: 10 }}
            value={genre}
            onChangeText={(value) => setGenre(value)}
          />
          <Input
            placeholder="Sayfa Sayısı"
            style={{ marginVertical: 10 }}
            value={pages.toString()}
            onChangeText={(value) => setPages(Number(value))}
          />
          <Checkbox
            label="Bu kitabı beğendiniz mi?"
            checked={liked}
            style={{ marginVertical: 10 }}
            onPress={() => setLiked(!liked)}
          />
          <Input
            style={{ marginVertical: 10, flex: 1, textAlignVertical: "top" }}
            multiline
            value={opinion}
            placeholder="Kitap hakkında düşüncelerim..."
            onChangeText={(value) => setOpinion(value)}
          />
          <Button label="Ekle" onPress={handleSaveBook} />
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}
