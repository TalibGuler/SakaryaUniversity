import React, {
  Dispatch,
  SetStateAction,
  useContext,
  useEffect,
  useState,
} from "react";
import { Text, Modal, ModalProps, View, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Icon from "react-native-vector-icons/Feather";
import Book from "../models/Book";

interface BookDetailsModalProps extends ModalProps {
  setVisible: Dispatch<SetStateAction<boolean>>;
  data: Book;
}

export default function BookDetailsModal({
  setVisible,
  data,
  ...rest
}: BookDetailsModalProps) {
  const { name, author, pages, genre, opinion, liked } = data;
  return (
    <Modal animationType="slide" {...rest}>
      <SafeAreaView style={{ padding: 30, height: "100%" }}>
        <View style={{ marginBottom: 30 }}>
          <TouchableOpacity
            style={{
              position: "absolute",
              right: 0,
              backgroundColor: "#9fbea5",
              padding: 5,
              zIndex: 9999,
              borderRadius: 25,
            }}
            onPress={() => setVisible(false)}
          >
            <Icon name="x" size={30} color="white" />
          </TouchableOpacity>
          <Text style={{ textAlign: "center", fontSize: 20 }}>{name}</Text>
        </View>

        <View>
          <Text style={{ fontSize: 20, marginVertical: 10 }}>
            Yazar: {author}
          </Text>
          <Text style={{ fontSize: 20, marginVertical: 10 }}>
            Sayfa Sayisi: {pages}
          </Text>
          <Text style={{ fontSize: 20, marginVertical: 10 }}>Tur: {genre}</Text>
          <Text style={{ fontSize: 20, marginVertical: 10 }}>{`${
            liked ? "Begenildi" : "Begenilmedi"
          }`}</Text>
          <View style={{ marginTop: 40 }}>
            <Text style={{ fontSize: 20, marginVertical: 10 }}>Fikrim:</Text>
            <Text>{opinion}</Text>
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}
