import React, { useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import styled from "styled-components/native";
import Note from "../models/Book";
import Icon from "react-native-vector-icons/Feather";
import IonIcon from "react-native-vector-icons/Ionicons";
import { db, firestore } from "../firebase";
import BookDetailsModal from "./BookDetailsModal";

interface NoteCardProps {
  data: Note;
}

const StyledText = styled.Text({
  color: "white",
  marginTop: 5,
  marginBottom: 5,
});

export default function BookCard({ data }: NoteCardProps) {
  const { id, name, author, liked, pages, isTrash, color } = data;
  const [isBookDetailsModalVisible, setIsBookDetailsModalVisible] =
    useState(false);
  const doc = firestore.doc(db, "books", id);

  const StyledTouchableOpacity = styled.TouchableOpacity({
    backgroundColor: color,
    marginTop: 10,
    marginBottom: 10,
    padding: 20,
    borderRadius: 20,
    flexDirection: "row",
    alignItems: "center",
  });

  const handleDelete = () => {
    if (isTrash) {
      firestore.deleteDoc(doc);
    } else {
      firestore.updateDoc(doc, { isTrash: true });
    }
  };

  const handleRestore = () => {
    firestore.updateDoc(doc, { isTrash: false });
  };

  return (
    <>
      <StyledTouchableOpacity
        activeOpacity={1}
        onPress={() => setIsBookDetailsModalVisible(true)}
      >
        <View>
          <StyledText
            style={{ fontSize: 20 }}
          >{`${name.toUpperCase()} (${pages} sf.)`}</StyledText>
          <StyledText>{`Yazar: ${author}`}</StyledText>
          <StyledText>{liked ? "Begenildi" : "Begenilmedi"}</StyledText>
        </View>
        <View style={{ marginLeft: "auto", flexDirection: "row" }}>
          {isTrash ? (
            <TouchableOpacity
              onPress={handleRestore}
              style={{ marginRight: 20 }}
            >
              <IonIcon name="return-down-back" size={30} color={"white"} />
            </TouchableOpacity>
          ) : null}
          <TouchableOpacity onPress={handleDelete}>
            <Icon name="trash-2" size={30} color={"white"} />
          </TouchableOpacity>
        </View>
      </StyledTouchableOpacity>

      <BookDetailsModal
        data={data}
        setVisible={setIsBookDetailsModalVisible}
        visible={isBookDetailsModalVisible}
      />
    </>
  );
}
