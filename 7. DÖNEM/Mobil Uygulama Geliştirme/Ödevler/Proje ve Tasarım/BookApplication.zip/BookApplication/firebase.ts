import { initializeApp, getApps, getApp } from "firebase/app";
import * as auth from "firebase/auth";
import * as firestore from "firebase/firestore";

// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAGLI1pvd4xXnrtgP9szYGD-64RIWzn7Xs",
  authDomain: "book-application-2a7a1.firebaseapp.com",
  projectId: "book-application-2a7a1",
  storageBucket: "book-application-2a7a1.appspot.com",
  messagingSenderId: "609119566767",
  appId: "1:609119566767:web:90b3f4d11d3938004f0d5a"
};
let app;

if (getApps().length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

const db = firestore.getFirestore();

export { auth, firestore, db };
