import { createDrawerNavigator } from "@react-navigation/drawer";
import React from "react";
import { View, Text } from "react-native";
import Disliked from "../../screens/BooksScreen/Disliked";
import Home from "../../screens/BooksScreen/Home";
import Liked from "../../screens/BooksScreen/Liked";
import Trash from "../../screens/BooksScreen/Trash";
import ProfileNavigation from "./ProfileNavigation";

const Drawer = createDrawerNavigator();

export default function BookNavigation() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen
        name="books_home"
        component={Home}
        options={{ title: "Kitaplarım" }}
      />
      <Drawer.Screen
        name="books_liked"
        component={Liked}
        options={{ title: "Beğenilenler" }}
      />
      <Drawer.Screen
        name="books_disliked"
        component={Disliked}
        options={{ title: "Beğenilmeyenler" }}
      />
      <Drawer.Screen
        name="profile"
        component={ProfileNavigation}
        options={{ title: "Profil" }}
      />
      <Drawer.Screen
        name="books_trash"
        component={Trash}
        options={{ title: "Çöp" }}
      />
    </Drawer.Navigator>
  );
}
