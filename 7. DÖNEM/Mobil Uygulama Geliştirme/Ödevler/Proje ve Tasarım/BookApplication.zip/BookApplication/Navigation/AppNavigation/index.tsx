import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import { View, Text } from "react-native";
import NotesNavigation from "./BooksNavigation";
import ProfileNavigation from "./ProfileNavigation";

const AppStackNavigation = createNativeStackNavigator();

export default function AppNavigation() {
  return (
    <AppStackNavigation.Navigator screenOptions={{ headerShown: false }}>
      <AppStackNavigation.Screen
        name="notes_navigation"
        component={NotesNavigation}
      />
      <AppStackNavigation.Screen
        name="profile_navigation"
        component={ProfileNavigation}
      />
    </AppStackNavigation.Navigator>
  );
}
