import {
  BottomTabNavigationProp,
  createBottomTabNavigator,
} from "@react-navigation/bottom-tabs";
import React from "react";
import Profile from "../../screens/ProfileScreen/Profile";
import Settings from "../../screens/ProfileScreen/Settings";
import Icon from "react-native-vector-icons/Feather";

const Tab = createBottomTabNavigator();

export type ProfileTabParamList = {
  profile_home: undefined;
  profile_settings: undefined;
};

export type ProfileTabNavigationProp =
  BottomTabNavigationProp<ProfileTabParamList>;

export default function ProfileNavigation() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen
        name="profile_home"
        component={Profile}
        options={{
          title: "Profil",
          tabBarIcon: () => <Icon name="home" size={20} />,
        }}
      />
      <Tab.Screen
        name="profile_settings"
        component={Settings}
        options={{
          title: "Ayarlar",
          tabBarIcon: () => <Icon name="settings" size={20} />,
        }}
      />
    </Tab.Navigator>
  );
}
