interface User {
  id: string;
  name: string;
  lastName: string;
  email: string;
}
