export default interface Book {
  id: string;
  name: string;
  pages: number;
  author: string;
  genre: string;
  opinion: string;
  liked: boolean;
  isTrash: boolean;
  createdAt: Date;
  userId: string;
  color: string;
}
