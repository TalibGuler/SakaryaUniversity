import 'react-native-gesture-handler';
import React from "react";
import { View } from "react-native";
import AuthContextProvider from "./contexts/AuthContextProvider";
import Navigation from "./Navigation";

export default function App() {
  return (
    <AuthContextProvider>
      <View />
      <Navigation />
    </AuthContextProvider>
  );
}
