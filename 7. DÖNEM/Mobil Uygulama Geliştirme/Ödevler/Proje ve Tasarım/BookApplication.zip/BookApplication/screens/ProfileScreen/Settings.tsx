import { useNavigation } from "@react-navigation/native";
import React, { useContext, useState } from "react";
import { View, Text } from "react-native";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import { AuthContext } from "../../contexts/AuthContextProvider";
import { auth, db, firestore } from "../../firebase";
import { ProfileTabNavigationProp } from "../../Navigation/AppNavigation/ProfileNavigation";

export default function Settings() {
  const { authUser, setAuthUser } = useContext(AuthContext);
  const navigation = useNavigation<ProfileTabNavigationProp>();

  const [email, setEmail] = useState(authUser.email);
  const [name, setName] = useState(authUser.name);
  const [lastName, setLastName] = useState(authUser.lastName);
  const [password, setPassword] = useState("");

  const doc = firestore.doc(db, "users", authUser.id);

  const handleUpdate = async () => {
    if (email !== authUser.email) {
      await auth.updateEmail(auth.getAuth().currentUser, email);
    }

    if (password !== "") {
      await auth.updatePassword(auth.getAuth().currentUser, password);
      setPassword("");
    }

    if (name !== "") {
      await firestore.updateDoc(doc, { name });
    }

    if (lastName !== "") {
      await firestore.updateDoc(doc, { lastName });
    }

    setAuthUser({
      id: auth.getAuth().currentUser.uid,
      email,
      lastName,
      name,
    });

    navigation.navigate("profile_home");
  };

  return (
    <View style={{ padding: 20, height: "100%" }}>
      <Input
        style={{ marginVertical: 10 }}
        placeholder="Email"
        value={email}
        onChangeText={(value) => setEmail(value)}
      />
      <Input
        style={{ marginVertical: 10 }}
        placeholder="Isim"
        value={name}
        onChangeText={(value) => setName(value)}
      />
      <Input
        style={{ marginVertical: 10 }}
        placeholder="Soyisim"
        value={lastName}
        onChangeText={(value) => setLastName(value)}
      />
      <Input
        style={{ marginVertical: 10 }}
        placeholder="Sifre"
        value={password}
        onChangeText={(value) => setPassword(value)}
      />
      <View style={{ flex: 1 }} />
      <Button label="Guncelle" onPress={handleUpdate} />
    </View>
  );
}
