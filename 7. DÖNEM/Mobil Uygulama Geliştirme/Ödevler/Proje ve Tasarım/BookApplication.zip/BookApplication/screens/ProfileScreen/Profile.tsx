import React, { useContext, useEffect, useState } from "react";
import { View, Text, Image } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import Button from "../../components/ui/Button";
import { AuthContext } from "../../contexts/AuthContextProvider";
import { db, firestore } from "../../firebase";

export default function Profile() {
  const { authUser, setAuthUser } = useContext(AuthContext);
  const [numberOfBooks, setNumberOfBooks] = useState(0);

  useEffect(() => {
    const query = firestore.query(
      firestore.collection(db, "books"),
      firestore.where("userId", "==", authUser.id),
      firestore.where("isTrash", "==", false)
    );
    const unsubscribe = firestore.onSnapshot(query, (snapshot) => {
      setNumberOfBooks(snapshot.size);
    });

    return () => {
      unsubscribe();
    };
  }, []);
  return (
    <View
      style={{ justifyContent: "center", alignItems: "center", height: "100%" }}
    >
      <Image
        style={{ width: 150, height: 150, marginBottom: 20 }}
        source={{
          uri: `https://ui-avatars.com/api/?name=${authUser.name}+${authUser.lastName}&background=random&size=512&rounded=true`,
        }}
      />
      <Text
        style={{ fontSize: 30, marginBottom: 10 }}
      >{`${authUser.name} ${authUser.lastName}`}</Text>
      <Text style={{ marginBottom: 10 }}>{`${authUser.email}`}</Text>
      <Text>{`Kitap Sayisi: ${numberOfBooks}`}</Text>
      <Button
        label="Cikis Yap"
        style={{ backgroundColor: "#f54242", marginTop: 20, width: 200 }}
        onPress={() => setAuthUser(null)}
      />
    </View>
  );
}
