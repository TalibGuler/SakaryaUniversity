import React, { useContext, useState } from "react";
import { View, Text } from "react-native";
import Button from "../components/ui/Button";
import Input from "../components/ui/Input";
import { AuthContext } from "../contexts/AuthContextProvider";
import { auth, firestore } from "../firebase";

export default function Register() {
  const [name, setName] = useState("");
  const { setAuthUser } = useContext(AuthContext);
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async () => {
    try {
      const registerData = await auth.createUserWithEmailAndPassword(
        auth.getAuth(),
        email,
        password
      );

      await firestore.setDoc(
        firestore.doc(firestore.getFirestore(), "users", registerData.user.uid),
        {
          name,
          lastName,
        }
      );

      setAuthUser({ id: registerData.user.uid, name, lastName, email });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <View
      style={{
        height: "100%",
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 50,
      }}
    >
      <Text style={{ fontSize: 30, marginBottom: 30 }}>Hoşgeldin</Text>
      <Input
        style={{ width: "100%", marginBottom: 10 }}
        placeholder="Isim"
        value={name}
        onChangeText={(value) => setName(value)}
      />
      <Input
        style={{ width: "100%", marginBottom: 10 }}
        placeholder="Soyisim"
        value={lastName}
        onChangeText={(value) => setLastName(value)}
      />
      <Input
        style={{ width: "100%", marginBottom: 10 }}
        placeholder="E-mail"
        value={email}
        onChangeText={(value) => setEmail(value.toLowerCase())}
      />
      <Input
        secureTextEntry
        style={{ width: "100%" }}
        placeholder="Şifre"
        value={password}
        onChangeText={(value) => setPassword(value.trim())}
      />
      <Button
        label="Kayit Ol"
        style={{ width: "100%", marginTop: 10, marginBottom: 10 }}
        onPress={handleRegister}
      />
    </View>
  );
}
