import React, { useContext, useEffect, useState } from "react";
import { View, Text, FlatList } from "react-native";
import CreateNoteModal from "../../components/CreateBookModal";
import BookCard from "../../components/BookCard";
import { AuthContext } from "../../contexts/AuthContextProvider";
import { db, firestore } from "../../firebase";
import Book from "../../models/Book";

export default function Liked() {
  const { authUser } = useContext(AuthContext);
  const [notes, setNotes] = useState<Book[]>([]);
  const [createNoteModalVisible, setCreateNoteModalVisible] = useState(false);

  useEffect(() => {
    const query = firestore.query(
      firestore.collection(db, "books"),
      firestore.where("userId", "==", authUser.id),
      firestore.where("isTrash", "==", false),
      firestore.where("liked", "==", true),
      firestore.orderBy("createdAt", "desc")
    );

    const unsubscribe = firestore.onSnapshot(query, (snapshot) => {
      const books: Book[] = [];

      for (let i = 0; i < snapshot.size; i++) {}

      snapshot.forEach((doc) => {
        const {
          opinion,
          isTrash,
          userId,
          pages,
          name,
          liked,
          author,
          createdAt,
          genre,
          color,
        } = doc.data();
        books.push({
          author,
          genre,
          id: doc.id,
          isTrash,
          liked,
          name,
          opinion,
          pages,
          userId,
          createdAt,
          color,
        });
      });

      setNotes(books);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  return (
    <View style={{ flex: 1, paddingHorizontal: 30 }}>

      <FlatList
        data={notes}
        renderItem={({ item }) => <BookCard data={item} />}
        keyExtractor={(item) => item.id}
      />

      <CreateNoteModal
        visible={createNoteModalVisible}
        setVisible={setCreateNoteModalVisible}
      />
    </View>
  );
}
