import React from 'react';
import AppContainer from './src/navigations/AppNavigation';

export default function App() {
  return (
     <AppContainer />
  );
}
