import React, { useState, useEffect } from 'react';
import { Button, Image, View, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { ref, uploadBytes } from "firebase/storage";
import { firebaseStorage } from '../../FirebaseConfig'

export default function ImagePickerExample() {
  const [image, setImage] = useState(null);

  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          alert('Sorry, we need camera roll permissions to make this work!');
        }
      }
    })();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
      base64: true
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const onPressSend = async () => {
    const response = await fetch(image); 
    const blob = await response.blob();
    
    const storageRef = ref(firebaseStorage, "uploadedImage/" + Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 10));
    uploadBytes(storageRef, blob).then((snapshot) => {
      console.log('Image has been uploaded!!!');
    });
  }

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Button title="Pick an image from camera roll" onPress={pickImage} />
      {image && <Image source={{ uri: image }} style={{ width: 200, height: 200 }} />}
      {image && <Button
            onPress={onPressSend}
            title="Gönder"
            color="#841584"
            accessibilityLabel="Gönder"
            />}
      
    </View>
  );
}