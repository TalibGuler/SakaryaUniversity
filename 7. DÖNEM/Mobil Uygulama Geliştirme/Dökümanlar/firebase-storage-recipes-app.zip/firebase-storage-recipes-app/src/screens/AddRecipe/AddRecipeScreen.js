import React, { useState } from 'react';
import { Button, TextInput, StyleSheet, SafeAreaView, Text, Image } from 'react-native';
import { firestoreDb } from '../../FirebaseConfig'
import { collection, addDoc } from "firebase/firestore"; 
import * as ImagePicker from 'expo-image-picker';
import { firebaseStorage } from '../../FirebaseConfig'
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

export default function AddRecipeScreen() {
  const [description, setDescription] = useState("");
  const [time, setTime] = useState("");
  const [title, setTitle] = useState("");
  const [image, setImage] = useState(null);

  let recipeId = 300;

  const styles = StyleSheet.create({
    input: {
      height: 40,
      marginTop : 10,
      marginBottom : 10,
      borderWidth: 1,
      padding: 10,
      width : '100%'
    },
    headText : {
      marginTop: 20,
      fontSize : 30,
      width : '100%',
      textAlign : 'center'
    },
    imageButton : {
      marginTop : 10
    }
  });

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
      base64: true
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const onPressSend = async () => {
    recipeId += 1;

    const docRef = await addDoc(collection(firestoreDb, "recipes"), {
      categoryId : "3",
      description : description,
      photo_url : 'https://firebasestorage.googleapis.com/v0/b/recipesapp-22bd1.appspot.com/o/cookie.jpg?alt=media&token=9e9fbf0b-a36d-45dd-a2fd-a4378186dc7c',
      photoArray : ["https://firebasestorage.googleapis.com/v0/b/recipesapp-22bd1.appspot.com/o/cookie.jpg?alt=media&token=9e9fbf0b-a36d-45dd-a2fd-a4378186dc7c"],
      recipeId : recipeId,
      time : time,
      title: title
    });
    console.log("Document written with ID: ", docRef.id);
  }

  const onPressSendWithImage = async () => {
    const response = await fetch(image); 
    const blob = await response.blob();
    
    var name = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 10);
    const storageRef = ref(firebaseStorage, "uploadedImage/" + name);

    uploadBytes(storageRef, blob).then((snapshot) => {
      console.log('Image has been uploaded!!!');
      
      getDownloadURL(ref(firebaseStorage, "uploadedImage/" + name))
      .then(async (url) => {
        recipeId += 1;

        const docRef = await addDoc(collection(firestoreDb, "recipes"), {
          categoryId : "3",
          description : description,
          photo_url : url,
          photoArray : [url],
          recipeId : recipeId,
          time : time,
          title: title
        });
        console.log("Document written with ID: ", docRef.id);
      });
    });
  }

  return (
    <SafeAreaView>
      <Text style= {styles.headText}>Yemek Tarifi Ekle</Text>
        <TextInput  
          style={styles.input}
          onChangeText={setTitle}
          value={title}
          placeholder = 'Başlık girmelisin'
        />
        <TextInput  
          style={styles.input}
          onChangeText={setDescription}
          value={description}
          placeholder = 'Açıklama girmelisin'
        />
        <TextInput  
          style={styles.input}
          onChangeText={setTime}
          value={time}
          placeholder = 'Zaman girmelisin'
        />
        <Button
          onPress={onPressSend}
          title="Ekle"
          color="#841584"
          accessibilityLabel="Ekle"
        />
        <Button title="Resim Ekle" onPress={pickImage} style={styles.imageButton}/>
        {image && <Image source={{ uri: image }} style={{width: 200, height: 200 }} />}
        {image && <Button
          onPress={onPressSendWithImage}
          title="Resimle Ekle"
          color="#841584"
          accessibilityLabel="Resimle Ekle"
        />}
    </SafeAreaView>
  );
}

