#include <iostream>
using namespace std;
int main()
   {
   long A=1234567, B=123, C=2345;
   cout << "A" << A << endl
        << "B" << B << endl
        << "C" << C << endl;
   system ("pause");     
   return 0;
   }
