//=========================================
// Adı				: Programlamaya Giriş 
// Yazar			: Gülüzar ÇİT
// Versiyon			: 1.0
// Telif Hakkı		: @Copyright 2018
//=========================================
// Ekrana "Merhaba Dünya" yazan program
//=========================================

//cout, cin, vs. gibi giriş/çıkış komutları için
#include <iostream>

using namespace std;


int main()
{
	cout<<"!!!!Merhaba Dünya!!!"<<endl;						// cout: ekrana veri yazdırma komutu
	return 0;
}

