//=============================================
// Adı				: Programlamaya Giriş 
// Yazar			: Gülüzar ÇİT
// Versiyon			: 1.0
// Telif Hakkı		: @Copyright 2018
//============================================
// Otomatik Tip Dönüşümü
//============================================

#include <iostream>

using namespace std; 

int main()
{
   int 		tamsayi = 7;
   float 	kayannokta = 155.5F;

   double sonuc = tamsayi * kayannokta;
   cout << "SONUÇ.....: " << sonuc << endl;
  
   system("pause");
   return 0;
}

