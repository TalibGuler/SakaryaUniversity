/****************************************************************************
**					         SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				        B�LG�SAYAR M�HEND�SL��� B�L�M�
**				          PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI:3
**				��RENC� ADI:Abd�lmuttalib G�LER
**				��RENC� NUMARASI:G181210011	
**				DERS GRUBU:B(��)
****************************************************************************/

#include <iostream>
using namespace std;

struct Islem
{
	//giri� matrisinin tan�mlanmas�
	int giris[5][5] = { 3,2,5,1,4,
						6,2,1,0,7,
						3,0,0,2,0,
						1,1,3,2,2,
						0,3,1,0,0 };
	float CekirdekBoyutu; //cekirdek boyutunu �l�mek i�in tan�mlanan de�i�ken.
	int cekirdek[150][150]; //cekirdek de�i�keni
	float sonuc_matris_boyut; //matris boyutunu bulmak i�in tan�mlanan de�i�ken 
    float KaymaMiktari; //kayma miktar�n� float cinsinden almak i�in tan�mlanan de�i�ken 
};

Islem matris;
int giris_boyut = size(matris.giris);
int y_boyut = 0;
int matris_carpim;
int x_boyut = 0;

int islemicarp(int x_boyut, int y_boyut)
{
	for (int i = 0; i < giris_boyut; i++) { //giri� matrisi i�in for d�ng�s�
		for (int j = 0; j < giris_boyut; j++) {

			for (int k = 0; k < matris.CekirdekBoyutu; k++) { //�ekirdek matrisi i�in for d�ng�s�
				for (int l = 0; l < matris.CekirdekBoyutu; l++) {

					if (i == k + y_boyut && j == l + x_boyut) //matrisin kayma �arpmas� durumunu inceler.
					{
						matris_carpim =matris_carpim + (matris.giris[i][j] * matris.cekirdek[k][l]); 
					}
				}
			}
		}
	}
	return matris_carpim;
}



int main()
{

	cout << "Cekridek Boyutunu Yaziniz:";
	cin >> matris.CekirdekBoyutu;
	cout << '\n';
	cout << "Kayma Miktarini Yaziniz:";
	cin >> matris.KaymaMiktari;
	cout << '\n';


	matris.sonuc_matris_boyut = ((giris_boyut - matris.CekirdekBoyutu) / matris.KaymaMiktari) + 1;
	int matris_boyut_tamsayi = matris.sonuc_matris_boyut;

	if (matris.sonuc_matris_boyut == matris_boyut_tamsayi) //matrisin �arp�labilir durumu i�in kayma miktar� �ekirdek boyutu aras�ndaki ba��nt�y� inceler.
	{

		for (int i = 0; i < matris.CekirdekBoyutu; i++) { //matrisin elemanlar�n� alan d�ng�
			for (int j = 0; j < matris.CekirdekBoyutu; j++) {
				cout << "Cekirdek" << "[" << i << "]" << "[" << j << "]" << "=";
				cin >> matris.cekirdek[i][j];
				cout << '\n';
			}
		}

		cout << '\n';

		int i = 0;
		while(i<matris.sonuc_matris_boyut){ //sonuc matrisi i�in d�nen while d�ng�s�
			int j = 0;
			while(j<matris.sonuc_matris_boyut) { //sonuc matrisi i�in d�nen while d�ng�s�.


				cout << islemicarp(x_boyut, y_boyut) << '\t';
				x_boyut = x_boyut + matris.KaymaMiktari;
				matris_carpim = 0;
				j++;

			}

			x_boyut = 0;
			y_boyut = y_boyut+ matris.KaymaMiktari;
			i++;


			cout << '\n';
		}


	}
	else //istenen durumlar d���nda bir �ey girilirse else devreye girer.
	{
		cout << "Bu islem gerceklestirilemez ";
	}
	system("pause");
}


