/**************************************************************
***
***                  SAKARYA �N�VERS�TES�
***         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
***              B�LG�SAYAR M�HEND�SL��� B�L�M�
***                PROGRAMLAMAYA G�R�� DERS�
***
***			�DEV NUMARASI....: 1.1
***			��RENC� ADI......:Abd�lmuttalib G�LER
***			��RENC� NUMARASI.:G181210011
***			DERS GRUBU.......:B Grubu (��)
***
**************************************************************/
#include <iostream>
using namespace std;


int main()
{
	int bosluk, yildiz; //bo�luk ve yildiz de�i�kenlerini main fonksiyonu icinde tanimliyoruz

	bosluk = 1;
	yildiz = 5;

	for (int satir = 0; satir < 5; satir++) //5 sat�r basmas� icin for dongusune calisma araligi belirliyoruz
	{
		for (int a = 0; a < yildiz; a++) //sat�ra  tanimlanan aralik kadar "*" bas�l�yor
		{
			cout << "*";
		}

		for (int a = 0; a < bosluk; a++) //sat�ra tanimlanan bosluk degeri kadar " " bas�l�yor
		{
			cout << " ";
		}

		for (int a = 0; a < yildiz; a++) //sat�ra tanimlamnan  yildiz degeri kadar "*" bas�l�yor
		{
			cout << "*";
		}

		cout << endl;

		bosluk = bosluk + 2;
		yildiz--; //baklava �eklinin ilk yar�s� i�in bo�luk 2 artt�r�l�yor, y�ld�z say�s� birer azalt�l�yor
	}

	cout << endl; //aradaki bo�luk 

	bosluk = 9;
	yildiz = 1;

	for (int satir = 0; satir < 5; satir++) //5 sat�r basmas� icin for dongusune calisma araligi belirliyoruz
	{
		for (int a = 0; a < yildiz; a++) //satira  tanimlanan aralik kadar "*" bas�l�yor
		{
			cout << "*";
		}

		for (int a = 0; a < bosluk; a++) //satira tan�mlanan bosluk de�eri kadar " " bas�l�yor
		{
			cout << " ";
		}

		for (int a = 0; a < yildiz; a++) //satira tanimlanan yildiz de�eri kadar "*" bas�l�yor
		{
			cout << "*";
		}

		cout << endl;

		bosluk = bosluk - 2;
		yildiz++; //baklava �eklinin ikinci yarisi i�in bo�luk 2 azalt�l�yor, y�ld�z sayisi birer artt�r�l�yor
	}

	system("pause");
	return 0;
}
